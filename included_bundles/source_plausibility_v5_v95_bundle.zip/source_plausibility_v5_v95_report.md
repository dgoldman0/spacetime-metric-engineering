# Source Plausibility Screen at V=5 and V=9.5

## Scope

This reruns the source plausibility screen for the locked tuned branch at **V=5** and **V=9.5**.

- **V=5** uses the archived high-resolution V-sweep row for `tuned_w0569_eta200`.
- **V=9.5** is an interpolation from the archived V=5 and V=10 tuned source-ledger rows, because the repo does not contain a separate high-resolution V=9.5 source-ledger row.
- The architecture is held fixed. No tuning is performed.

## Executive result

**V=5:** clearly easier. The live radial-null burden is about **72% of the V=10 value**, while `p_l` is essentially unchanged. The catch-edge absorber remains the formal caveat, but it drops from red to amber/red-amber in practical screening terms.

**V=9.5:** basically a near-design stress case. The live radial-null burden is estimated at about **97% of the V=10 value**. It should remain safe, but source plausibility is almost the same story as V=10: the inner packet-edge catch/rematch absorber remains the principal physics caveat.

## V-scaled source metrics

|    V | source                                             |   max_packet_norm_live |   positive_packet_norm_live |   abs_p_l_live |   neg_Tkk_radial_live |   live_fraction_abs_p_l |   live_fraction_neg_Tkk_radial |   point_peak_abs_p_l |   point_peak_neg_Tkk_radial |   abs_p_l_live_ratio_vs_V10 |   neg_Tkk_radial_live_ratio_vs_V10 |   live_fraction_neg_Tkk_radial_ratio_vs_V10 |   point_peak_neg_Tkk_radial_ratio_vs_V10 |
|-----:|:---------------------------------------------------|-----------------------:|----------------------------:|---------------:|----------------------:|------------------------:|-------------------------------:|---------------------:|----------------------------:|----------------------------:|-----------------------------------:|--------------------------------------------:|-----------------------------------------:|
|  5   | exact archived V-sweep                             |               -251.331 |                           0 |        13.8318 |               52.0568 |                0.270555 |                       0.17752  |            0.0115534 |                    0.100128 |                           1 |                           0.719221 |                                    0.778228 |                                 0.701737 |
|  9.5 | interpolated from archived V=5 and V=10 tuned rows |               -204.166 |                           0 |        13.8318 |               70.3471 |                0.270556 |                       0.223049 |            0.0115534 |                    0.13843  |                           1 |                           0.971922 |                                    0.977823 |                                 0.970174 |
| 10   | exact archived V-sweep                             |               -198.925 |                           0 |        13.8318 |               72.3794 |                0.270556 |                       0.228108 |            0.0115534 |                    0.142686 |                           1 |                           1        |                                    1        |                                 1        |

## Channel screen

|   V | channel        |   live_burden |   ratio_vs_V10 | screen_result   | read                                                                       |
|----:|:---------------|--------------:|---------------:|:----------------|:---------------------------------------------------------------------------|
| 5   | neg_Tkk_radial |       52.0568 |       0.719221 | amber           | substantially softened at V=5                                              |
| 5   | abs_p_l        |       13.8318 |       1        | amber           | nearly V-independent in archived tuned rows; support-edge problem persists |
| 5   | packet safety  |     -251.331  |     nan        | green           | ample margin relative to V=10                                              |
| 9.5 | neg_Tkk_radial |       70.3471 |       0.971922 | red-amber       | near full V=10 catch-edge risk                                             |
| 9.5 | abs_p_l        |       13.8318 |       1        | amber           | nearly V-independent in archived tuned rows; support-edge problem persists |
| 9.5 | packet safety  |     -204.166  |     nan        | green-amber     | safe but close to stressed design point                                    |

## Component risk changes

The important movement is in the dynamic/null-stress sectors. Static support roles barely change. The radial pressure channel is almost V-independent in the archived tuned rows, so lower V does not remove the support-edge pressure question.

| V | main read |
|---:|---|
| 5.0 | Good lower-stress validation case. Source burden is materially easier, especially Tkk. |
| 9.5 | Near full design stress. Good pre-V10 sanity point, but not a different physical regime. |

## Decision

At **V=5**, the model looks source-plausible at the reduced-screen level with fewer caveats. It is the right level for debugging source-family prototypes.

At **V=9.5**, the screen still supports the technical write-up, but it should be described as essentially the same source-risk regime as V=10. It is useful as a safety-margin check, not as a fundamentally easier source case.

## Recommended use

Use **V=5** for first 3+1/constraint prototype scaffolding and source-family debugging. Use **V=9.5** as the near-design stress rehearsal before returning to V=10.
