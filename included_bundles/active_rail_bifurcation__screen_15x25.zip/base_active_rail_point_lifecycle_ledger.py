#!/usr/bin/env python3
"""
active_rail_point_lifecycle_ledger.py

Point-level demanded-source/lifecycle ledger for the active-rail quarantine
candidate family.

This is a prescribed-geometry Einstein-source diagnostic:

    T_munu^demand = G_munu[g] / (8*pi)

It is not a matter model, not an RSET calculation, and not a constraint solve.

The metric implementation is adapted from the repository's older
source_ledger_static_throat_report/code/source_ledger.py, with the later freeze
and quarantine-family choices folded in:

- catch-rematched, throat-gated shift;
- minimum-jerk decompression q(s);
- explicit soft angular jacket C_Omega(s,l);
- widened Rth / ROmega quarantine candidates;
- lifecycle masks that count passengers only through entry/catch/carry/release,
  not through reset/decompression.

Outputs are raw point ledgers plus long-form stage/region/channel summaries.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import zipfile
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import numpy as np
import pandas as pd

try:
    import matplotlib.pyplot as plt
except Exception:  # plotting is optional
    plt = None

PI8 = 8.0 * math.pi
THETA0 = math.pi / 2.0


@dataclass(frozen=True)
class Params:
    # Transport/service sector
    V: float = 10.0
    v_exit: float = 0.5
    p_beta: float = 4.0
    Rpass: float = 0.35

    # Support sector
    C0: float = 100.0
    lam: float = 6.0
    B0: float = 8.0
    eta_N: float = 1.0
    Rth: float = 1.75
    w_th: float = 0.35
    w_pass: float = 0.06
    eps: float = 1e-5

    # Service timing
    x_catch: float = 0.15
    x_beta: float = 0.70
    w_catch: float = 0.16
    w_beta: float = 0.18

    # Minimum-jerk decompression q(s): q=1 at/ before t0, q=0 after t0+Tr
    q_t0: float = -0.40
    q_Tr: float = 3.00

    # Angular jacket: gamma_OmegaOmega=(l^2+Rth^2) C_Omega^2
    aOmega: float = 0.20
    ROmega: float = 1.75
    wOmega: float = 1.40
    xOmega: float = 2.00
    wtOmega: float = 0.60

    # Lifecycle accounting
    live_packet_end_margin_widths: float = 2.0


@dataclass(frozen=True)
class CaseDef:
    name: str
    params: Params
    note: str


def smoothstep_minjerk(t: np.ndarray | float) -> np.ndarray | float:
    """Minimum-jerk smoothstep 10t^3 - 15t^4 + 6t^5, clamped to [0,1]."""
    x = np.clip(np.asarray(t, dtype=float), 0.0, 1.0)
    return 10.0 * x**3 - 15.0 * x**4 + 6.0 * x**5


def minjerk_down(s: np.ndarray | float, t0: float, Tr: float) -> np.ndarray | float:
    t = (np.asarray(s, dtype=float) - t0) / Tr
    return 1.0 - smoothstep_minjerk(t)


def falloff(z: np.ndarray | float, w: float) -> np.ndarray | float:
    return 0.5 * (1.0 - np.tanh(np.asarray(z, dtype=float) / w))


def bump_sq(x2: np.ndarray | float, R: float, w: float) -> np.ndarray | float:
    # Smooth interior indicator for x^2 <= R^2, with transition width w.
    z = (np.asarray(x2, dtype=float) - R * R) / max(2.0 * R * w, 1e-12)
    return 0.5 * (1.0 - np.tanh(z))


def scalars(s: float, l: float, p: Params) -> Dict[str, float]:
    s_arr = np.asarray(s, dtype=float)
    l_arr = np.asarray(l, dtype=float)

    C = falloff(s_arr - p.x_catch, p.w_catch)
    U = p.v_exit + (p.V - p.v_exit) * C
    E = falloff(s_arr - p.x_beta, p.w_beta)
    q = minjerk_down(s_arr, p.q_t0, p.q_Tr)

    W = bump_sq(l_arr * l_arr, p.Rth, p.w_th)
    S = bump_sq((l_arr - s_arr) * (l_arr - s_arr) + p.eps * p.eps, p.Rpass, p.w_pass)

    A = np.exp(q * W * math.log(p.C0))
    T = np.exp(q * W * math.log(p.lam * p.C0))
    B = 1.0 + (p.B0 - 1.0) * W * q

    shoulder = np.exp(-((np.abs(l_arr) - 1.05) / 0.35) ** 2)
    N = np.exp(p.eta_N * 0.18 * q * shoulder)

    Wpower = W ** p.p_beta
    beta = -U * E * Wpower * S / B
    alpha = N * T
    sqrt_gamma_ll = B * A
    gamma_ll = sqrt_gamma_ll * sqrt_gamma_ll
    vcoord = U / B
    gtt = -alpha * alpha + gamma_ll * beta * beta
    packet_norm = -alpha * alpha + gamma_ll * (vcoord + beta) ** 2

    WOmega = bump_sq(l_arr * l_arr, p.ROmega, p.wOmega)
    QOmega = falloff(s_arr - p.xOmega, p.wtOmega)
    COmega = np.exp(p.aOmega * QOmega * WOmega)
    gamma_omega = (l_arr * l_arr + p.Rth * p.Rth) * COmega * COmega

    return {
        "U": float(U),
        "E": float(E),
        "q": float(q),
        "W": float(W),
        "S": float(S),
        "A": float(A),
        "T": float(T),
        "B": float(B),
        "N": float(N),
        "beta": float(beta),
        "alpha": float(alpha),
        "sqrt_gamma_ll": float(sqrt_gamma_ll),
        "gamma_ll": float(gamma_ll),
        "vcoord": float(vcoord),
        "gtt": float(gtt),
        "packet_norm": float(packet_norm),
        "WOmega": float(WOmega),
        "QOmega": float(QOmega),
        "COmega": float(COmega),
        "gamma_omega": float(gamma_omega),
    }


def metric_at(x: np.ndarray, p: Params) -> np.ndarray:
    s, l, theta, _phi = [float(z) for z in x]
    sc = scalars(s, l, p)
    alpha = sc["alpha"]
    beta = sc["beta"]
    gamma_ll = sc["gamma_ll"]
    goo = sc["gamma_omega"]
    sin2 = math.sin(theta) ** 2
    g = np.zeros((4, 4), dtype=float)
    g[0, 0] = -alpha * alpha + gamma_ll * beta * beta
    g[0, 1] = g[1, 0] = gamma_ll * beta
    g[1, 1] = gamma_ll
    g[2, 2] = goo
    g[3, 3] = goo * sin2
    return g


def metric_derivative(x: np.ndarray, coord: int, h: np.ndarray, p: Params) -> np.ndarray:
    if coord == 3:
        return np.zeros((4, 4), dtype=float)
    xp = x.copy(); xm = x.copy()
    xp[coord] += h[coord]
    xm[coord] -= h[coord]
    return (metric_at(xp, p) - metric_at(xm, p)) / (2.0 * h[coord])


def christoffel_at(x: np.ndarray, h: np.ndarray, p: Params) -> np.ndarray:
    g = metric_at(x, p)
    invg = np.linalg.inv(g)
    dg = [metric_derivative(x, a, h, p) for a in range(4)]
    Gamma = np.zeros((4, 4, 4), dtype=float)
    for rho in range(4):
        for mu in range(4):
            for nu in range(4):
                total = 0.0
                for sig in range(4):
                    total += invg[rho, sig] * (dg[mu][nu, sig] + dg[nu][mu, sig] - dg[sig][mu, nu])
                Gamma[rho, mu, nu] = 0.5 * total
    return Gamma


def christoffel_derivative(x: np.ndarray, coord: int, h: np.ndarray, p: Params) -> np.ndarray:
    if coord == 3:
        return np.zeros((4, 4, 4), dtype=float)
    xp = x.copy(); xm = x.copy()
    xp[coord] += h[coord]
    xm[coord] -= h[coord]
    return (christoffel_at(xp, h, p) - christoffel_at(xm, h, p)) / (2.0 * h[coord])


def einstein_tensor_at(s: float, l: float, p: Params, h_s: float, h_l: float, h_theta: float = 1e-4) -> Tuple[np.ndarray, Dict[str, float]]:
    x = np.array([s, l, THETA0, 0.0], dtype=float)
    h = np.array([h_s, h_l, h_theta, 1.0], dtype=float)
    g = metric_at(x, p)
    invg = np.linalg.inv(g)
    Gamma = christoffel_at(x, h, p)
    dGamma = [christoffel_derivative(x, a, h, p) for a in range(4)]

    Ric = np.zeros((4, 4), dtype=float)
    for mu in range(4):
        for nu in range(4):
            term1 = sum(dGamma[rho][rho, mu, nu] for rho in range(4))
            term2 = sum(dGamma[nu][rho, mu, rho] for rho in range(4))
            term3 = 0.0
            term4 = 0.0
            for rho in range(4):
                trace = sum(Gamma[sig, rho, sig] for sig in range(4))
                term3 += Gamma[rho, mu, nu] * trace
                for sig in range(4):
                    term4 += Gamma[sig, mu, rho] * Gamma[rho, nu, sig]
            Ric[mu, nu] = term1 - term2 + term3 - term4
    R = float(np.einsum("ab,ab->", invg, Ric))
    G = Ric - 0.5 * g * R
    diagnostics = {"ricci_scalar": R, "cond_metric": float(np.linalg.cond(g))}
    return G, diagnostics


def projections(s: float, l: float, G: np.ndarray, p: Params) -> Dict[str, float]:
    sc = scalars(s, l, p)
    alpha = sc["alpha"]
    beta = sc["beta"]
    gamma_ll = sc["gamma_ll"]
    sqrt_gamma_ll = math.sqrt(gamma_ll)
    gamma_omega = sc["gamma_omega"]
    T = G / PI8

    n = np.array([1.0 / alpha, -beta / alpha, 0.0, 0.0], dtype=float)
    e_l_unit = np.array([0.0, 1.0 / sqrt_gamma_ll, 0.0, 0.0], dtype=float)
    e_th_unit = np.array([0.0, 0.0, 1.0 / math.sqrt(gamma_omega), 0.0], dtype=float)
    e_phi_unit = np.array([0.0, 0.0, 0.0, 1.0 / math.sqrt(gamma_omega)], dtype=float)  # theta=pi/2

    rho = float(n @ T @ n)
    j_l_unit = float(-e_l_unit @ T @ n)
    p_l = float(e_l_unit @ T @ e_l_unit)
    p_theta = float(e_th_unit @ T @ e_th_unit)
    p_phi = float(e_phi_unit @ T @ e_phi_unit)
    p_omega = 0.5 * (p_theta + p_phi)

    u_raw = np.array([1.0, sc["vcoord"], 0.0, 0.0], dtype=float)
    norm = sc["packet_norm"]
    if norm < 0.0:
        u_pkt = u_raw / math.sqrt(-norm)
        rho_pkt = float(u_pkt @ T @ u_pkt)
    else:
        rho_pkt = float("nan")

    k_plus = np.array([1.0, -beta + alpha / sqrt_gamma_ll, 0.0, 0.0], dtype=float)
    k_minus = np.array([1.0, -beta - alpha / sqrt_gamma_ll, 0.0, 0.0], dtype=float)
    Tkk_plus = float(k_plus @ T @ k_plus)
    Tkk_minus = float(k_minus @ T @ k_minus)
    Tkk_min_radial = min(Tkk_plus, Tkk_minus)

    spatial_volume_density = sqrt_gamma_ll * gamma_omega

    return {
        "rho_euler": rho,
        "j_l_unit": j_l_unit,
        "p_l_unit": p_l,
        "p_theta_unit": p_theta,
        "p_phi_unit": p_phi,
        "p_omega_unit": p_omega,
        "rho_packet": rho_pkt,
        "Tkk_plus": Tkk_plus,
        "Tkk_minus": Tkk_minus,
        "Tkk_min_radial": Tkk_min_radial,
        "packet_norm": norm,
        "gtt": sc["gtt"],
        "spatial_volume_density": spatial_volume_density,
        **{k: sc[k] for k in ["W", "S", "q", "E", "U", "B", "A", "T", "alpha", "beta", "gamma_ll", "gamma_omega", "COmega"]},
    }


def stage_name(s: float, p: Params) -> str:
    if s < p.x_catch - 2.0 * p.w_catch:
        return "entry_precatch"
    if abs(s - p.x_catch) <= 2.0 * p.w_catch:
        return "catch_rematch"
    if p.x_catch + 2.0 * p.w_catch < s < p.x_beta - 2.0 * p.w_beta:
        return "held_carry"
    if abs(s - p.x_beta) <= 2.0 * p.w_beta:
        return "release_shift_fade"
    if p.x_beta + 2.0 * p.w_beta < s < p.x_beta + 4.0 * p.w_beta:
        return "post_release_buffer"
    return "reset_decompression"


def region_name(s: float, l: float, p: Params) -> str:
    al = abs(l)
    if abs(l - s) <= p.Rpass:
        if al <= p.Rth:
            return "packet_in_support"
        return "packet_outer"
    if al <= 0.65 * p.Rth:
        return "core_throat"
    if al <= 1.20 * p.Rth:
        return "support_edge"
    if al <= 1.85 * p.Rth:
        return "outer_quarantine_shell"
    return "far_exterior"


def live_packet_mask(s: float, l: float, p: Params) -> bool:
    inside_geom = abs(l - s) <= p.Rpass
    live_end = p.x_beta + p.live_packet_end_margin_widths * p.w_beta
    return bool(inside_geom and s <= live_end)


def channel_badness(row: pd.Series | Dict[str, float], channel: str) -> float:
    if channel == "neg_rho_euler":
        return max(-float(row["rho_euler"]), 0.0)
    if channel == "neg_rho_packet":
        z = float(row["rho_packet"])
        return max(-z, 0.0) if math.isfinite(z) else 0.0
    if channel == "neg_Tkk_radial":
        return max(-float(row["Tkk_min_radial"]), 0.0)
    if channel == "abs_p_l":
        return abs(float(row["p_l_unit"]))
    if channel == "abs_pOmega":
        return abs(float(row["p_omega_unit"]))
    if channel == "abs_j_l":
        return abs(float(row["j_l_unit"]))
    raise KeyError(channel)


CHANNELS = {
    "neg_rho_euler": "negative Eulerian density",
    "neg_rho_packet": "negative packet-comoving density",
    "neg_Tkk_radial": "negative radial null contraction",
    "abs_p_l": "radial pressure magnitude",
    "abs_pOmega": "angular pressure magnitude",
    "abs_j_l": "radial current magnitude",
}

STAGE_ORDER = [
    "entry_precatch",
    "catch_rematch",
    "held_carry",
    "release_shift_fade",
    "post_release_buffer",
    "reset_decompression",
]


def compute_case(case: CaseDef, ns: int, nl: int, s_min: float, s_max: float, l_min: float, l_max: float,
                 h_s: float, h_l: float, progress: bool = True) -> pd.DataFrame:
    p = case.params
    s_grid = np.linspace(s_min, s_max, ns)
    l_grid = np.linspace(l_min, l_max, nl)
    ds = float((s_max - s_min) / max(ns - 1, 1))
    dl = float((l_max - l_min) / max(nl - 1, 1))
    rows: List[Dict[str, float | str | bool]] = []
    total = ns * nl
    k = 0
    for s in s_grid:
        for l in l_grid:
            k += 1
            try:
                G, diag = einstein_tensor_at(float(s), float(l), p, h_s=h_s, h_l=h_l)
                proj = projections(float(s), float(l), G, p)
                packet_geom = abs(float(l) - float(s)) <= p.Rpass
                packet_live = live_packet_mask(float(s), float(l), p)
                row: Dict[str, float | str | bool] = {
                    "case": case.name,
                    "s": float(s),
                    "l": float(l),
                    "stage": stage_name(float(s), p),
                    "region": region_name(float(s), float(l), p),
                    "inside_packet_geom": packet_geom,
                    "inside_packet_live": packet_live,
                    "cell_area": ds * dl,
                    **proj,
                    **diag,
                }
                # Worldsheet/spatial-volume proxy weights. For fractions, both are diagnostic choices.
                row["point_weight"] = 1.0
                row["volume_weight"] = float(proj["spatial_volume_density"] * ds * dl)
                for ch in CHANNELS:
                    bad = channel_badness(row, ch)  # type: ignore[arg-type]
                    row[f"bad_{ch}"] = bad
                    row[f"point_burden_{ch}"] = bad
                    row[f"volume_burden_{ch}"] = bad * float(row["volume_weight"])
                rows.append(row)
            except Exception as exc:
                rows.append({
                    "case": case.name,
                    "s": float(s),
                    "l": float(l),
                    "stage": stage_name(float(s), p),
                    "region": region_name(float(s), float(l), p),
                    "inside_packet_geom": abs(float(l) - float(s)) <= p.Rpass,
                    "inside_packet_live": live_packet_mask(float(s), float(l), p),
                    "error": repr(exc),
                })
        if progress:
            done = k / total
            if ns <= 10 or abs((done * 10) - round(done * 10)) < (1.0 / max(ns, 1)):
                print(f"{case.name}: {k}/{total} points", flush=True)
    return pd.DataFrame(rows)


def summarize_long(points: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    ok = points[points.get("error", pd.Series(index=points.index, dtype=object)).isna()].copy() if "error" in points.columns else points.copy()
    long_rows: List[Dict[str, object]] = []
    peak_rows: List[Dict[str, object]] = []

    group_sets = [
        ("global", ["case"]),
        ("stage", ["case", "stage"]),
        ("region", ["case", "region"]),
        ("stage_region", ["case", "stage", "region"]),
    ]

    for scope, cols in group_sets:
        for key, g in ok.groupby(cols, dropna=False):
            if not isinstance(key, tuple):
                key = (key,)
            base = {"scope": scope, **{c: v for c, v in zip(cols, key)}, "points": int(len(g))}
            live = g["inside_packet_live"].astype(bool).to_numpy()
            geom = g["inside_packet_geom"].astype(bool).to_numpy()
            for ch, desc in CHANNELS.items():
                for weight_kind in ["point", "volume"]:
                    burden_col = f"{weight_kind}_burden_{ch}"
                    vals = g[burden_col].astype(float).to_numpy()
                    total = float(np.nansum(vals))
                    live_b = float(np.nansum(vals[live]))
                    geom_b = float(np.nansum(vals[geom]))
                    infra_b = total - live_b
                    long_rows.append({
                        **base,
                        "channel": ch,
                        "description": desc,
                        "weight": weight_kind,
                        "total_burden": total,
                        "live_packet_burden": live_b,
                        "geometric_packet_burden": geom_b,
                        "infrastructure_or_reset_burden": infra_b,
                        "live_packet_fraction": live_b / total if total > 0 else float("nan"),
                        "geometric_packet_fraction": geom_b / total if total > 0 else float("nan"),
                        "point_peak": float(g[f"bad_{ch}"].astype(float).max()),
                        "live_packet_point_peak": float(g.loc[g["inside_packet_live"].astype(bool), f"bad_{ch}"].astype(float).max()) if live.any() else 0.0,
                        "geometric_packet_point_peak": float(g.loc[g["inside_packet_geom"].astype(bool), f"bad_{ch}"].astype(float).max()) if geom.any() else 0.0,
                    })

    summary = pd.DataFrame(long_rows)

    # Top bad point list by channel/case.
    top_rows: List[Dict[str, object]] = []
    for case, cg in ok.groupby("case"):
        for ch, desc in CHANNELS.items():
            c = f"volume_burden_{ch}"
            ranked = cg.sort_values(c, ascending=False).head(20)
            for rank, (_, r) in enumerate(ranked.iterrows(), start=1):
                top_rows.append({
                    "case": case,
                    "channel": ch,
                    "description": desc,
                    "rank": rank,
                    "s": float(r["s"]),
                    "l": float(r["l"]),
                    "stage": r["stage"],
                    "region": r["region"],
                    "inside_packet_live": bool(r["inside_packet_live"]),
                    "inside_packet_geom": bool(r["inside_packet_geom"]),
                    "badness": float(r[f"bad_{ch}"]),
                    "volume_weight": float(r["volume_weight"]),
                    "volume_burden": float(r[c]),
                    "point_burden": float(r[f"point_burden_{ch}"]),
                })
    top = pd.DataFrame(top_rows)

    # Compact global for quick comparison.
    compact = summary[(summary["scope"] == "global") & (summary["weight"] == "volume")].copy()
    compact = compact[["case", "channel", "description", "total_burden", "live_packet_burden", "live_packet_fraction", "point_peak", "live_packet_point_peak"]]

    # Stage matrix for volume weighted live packet fraction and live burden.
    stage = summary[(summary["scope"] == "stage") & (summary["weight"] == "volume")].copy()
    stage["stage"] = pd.Categorical(stage["stage"], categories=STAGE_ORDER, ordered=True)
    stage = stage.sort_values(["case", "channel", "stage"])
    return summary, compact, stage, top


def make_plots(points: pd.DataFrame, outdir: Path, cases_to_plot: Iterable[str]) -> None:
    if plt is None:
        return
    ok = points[points.get("error", pd.Series(index=points.index, dtype=object)).isna()].copy() if "error" in points.columns else points.copy()
    for case in cases_to_plot:
        cg = ok[ok["case"] == case].copy()
        if cg.empty:
            continue
        for ch in ["neg_Tkk_radial", "abs_p_l", "abs_pOmega"]:
            pivot = cg.pivot_table(index="l", columns="s", values=f"bad_{ch}", aggfunc="mean")
            fig, ax = plt.subplots(figsize=(8, 5))
            im = ax.imshow(
                pivot.values,
                origin="lower",
                aspect="auto",
                extent=[float(pivot.columns.min()), float(pivot.columns.max()), float(pivot.index.min()), float(pivot.index.max())],
            )
            ax.set_title(f"{case}: {ch} point badness")
            ax.set_xlabel("s")
            ax.set_ylabel("l")
            fig.colorbar(im, ax=ax, label="badness")
            fig.tight_layout()
            fig.savefig(outdir / f"heatmap_{case}_{ch}.png", dpi=160)
            plt.close(fig)


def build_report(outdir: Path, cases: List[CaseDef], compact: pd.DataFrame, stage: pd.DataFrame, top: pd.DataFrame, ns: int, nl: int) -> str:
    lines: List[str] = []
    lines.append("# Point-Level Active Rail Lifecycle Ledger")
    lines.append("")
    lines.append("This report recomputes a raw `(s,l)` demanded-source ledger and then applies lifecycle masks.")
    lines.append("It is a prescribed-geometry Einstein-source diagnostic, not a matter model or physical-source proof.")
    lines.append("")
    lines.append(f"Grid: `{ns} x {nl}` points per case.")
    lines.append("")
    lines.append("## Cases")
    lines.append("")
    case_rows = []
    for c in cases:
        p = c.params
        case_rows.append({
            "case": c.name,
            "V": p.V,
            "Rth": p.Rth,
            "ROmega": p.ROmega,
            "w_th": p.w_th,
            "wOmega": p.wOmega,
            "aOmega": p.aOmega,
            "note": c.note,
        })
    lines.append(pd.DataFrame(case_rows).to_markdown(index=False))
    lines.append("")

    lines.append("## Compact global volume-weighted summary")
    lines.append("")
    tmp = compact.copy()
    tmp["live_packet_fraction"] = tmp["live_packet_fraction"].map(lambda x: f"{100*x:.1f}%" if pd.notna(x) else "nan")
    for col in ["total_burden", "live_packet_burden", "point_peak", "live_packet_point_peak"]:
        tmp[col] = tmp[col].map(lambda x: f"{x:.4g}" if pd.notna(x) else "nan")
    lines.append(tmp.to_markdown(index=False))
    lines.append("")

    lines.append("## Stage reading: live packet burden by stage")
    lines.append("")
    for ch in ["neg_Tkk_radial", "abs_p_l", "abs_pOmega", "abs_j_l"]:
        lines.append(f"### {ch}")
        lines.append("")
        st = stage[stage["channel"] == ch].copy()
        tab = st.pivot_table(index=["case"], columns="stage", values="live_packet_burden", aggfunc="sum")
        tab = tab.reindex(columns=STAGE_ORDER)
        lines.append(tab.fillna(0.0).map(lambda x: f"{x:.4g}").to_markdown())
        lines.append("")

    lines.append("## Top live-packet bad points")
    lines.append("")
    live_top = top[top["inside_packet_live"]].copy()
    if live_top.empty:
        lines.append("No top-ranked bad points landed in the live packet mask.")
    else:
        show = live_top.sort_values(["case", "channel", "rank"]).groupby(["case", "channel"]).head(5)
        cols = ["case", "channel", "rank", "s", "l", "stage", "region", "badness", "volume_burden"]
        show = show[cols].copy()
        for col in ["s", "l", "badness", "volume_burden"]:
            show[col] = show[col].map(lambda x: f"{float(x):.4g}")
        lines.append(show.to_markdown(index=False))
    lines.append("")

    lines.append("## Outputs")
    lines.append("")
    for name in [
        "point_lifecycle_ledger.csv",
        "point_lifecycle_summary_long.csv",
        "point_lifecycle_global_compact.csv",
        "point_lifecycle_stage_summary.csv",
        "point_lifecycle_top_bad_points.csv",
    ]:
        lines.append(f"- `{name}`")
    lines.append("")
    return "\n".join(lines)


def default_cases(V: float) -> List[CaseDef]:
    base_freeze = Params(V=V, Rth=1.25, ROmega=1.25, w_th=0.12, wOmega=0.70, aOmega=0.35)
    r175 = Params(V=V, Rth=1.75, ROmega=1.75, w_th=0.35, wOmega=1.40, aOmega=0.20)
    r200 = Params(V=V, Rth=2.00, ROmega=2.00, w_th=0.35, wOmega=1.60, aOmega=0.20)
    return [
        CaseDef("freeze_like_minjerk", base_freeze, "v1 freeze-like soft angular jacket with minimum-jerk q"),
        CaseDef("R1p75_quarantine", r175, "default quarantined active rail v2 candidate"),
        CaseDef("R2p0_quarantine", r200, "higher-quarantine stress branch"),
    ]


def parse_case_list(case_arg: str, V: float) -> List[CaseDef]:
    all_cases = {c.name: c for c in default_cases(V)}
    if case_arg == "all":
        return list(all_cases.values())
    out = []
    for name in case_arg.split(","):
        name = name.strip()
        if name not in all_cases:
            raise ValueError(f"Unknown case {name!r}; choose from all or {sorted(all_cases)}")
        out.append(all_cases[name])
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--cases", default="all", help="all or comma-separated names")
    ap.add_argument("--V", type=float, default=10.0)
    ap.add_argument("--ns", type=int, default=31)
    ap.add_argument("--nl", type=int, default=51)
    ap.add_argument("--s-min", type=float, default=-0.35)
    ap.add_argument("--s-max", type=float, default=1.65)
    ap.add_argument("--l-min", type=float, default=-2.80)
    ap.add_argument("--l-max", type=float, default=2.80)
    ap.add_argument("--h-s", type=float, default=2.5e-3)
    ap.add_argument("--h-l", type=float, default=2.5e-3)
    ap.add_argument("--outdir", type=Path, default=Path("active_rail_point_lifecycle_ledger_report"))
    ap.add_argument("--no-plots", action="store_true")
    args = ap.parse_args()

    args.outdir.mkdir(parents=True, exist_ok=True)
    cases = parse_case_list(args.cases, args.V)

    point_frames = []
    for c in cases:
        print(f"Running {c.name}", flush=True)
        point_frames.append(compute_case(c, args.ns, args.nl, args.s_min, args.s_max, args.l_min, args.l_max, args.h_s, args.h_l))
    points = pd.concat(point_frames, ignore_index=True)

    points.to_csv(args.outdir / "point_lifecycle_ledger.csv", index=False)
    summary, compact, stage, top = summarize_long(points)
    summary.to_csv(args.outdir / "point_lifecycle_summary_long.csv", index=False)
    compact.to_csv(args.outdir / "point_lifecycle_global_compact.csv", index=False)
    stage.to_csv(args.outdir / "point_lifecycle_stage_summary.csv", index=False)
    top.to_csv(args.outdir / "point_lifecycle_top_bad_points.csv", index=False)

    metadata = {
        "status": "ok",
        "grid": {"ns": args.ns, "nl": args.nl, "s_min": args.s_min, "s_max": args.s_max, "l_min": args.l_min, "l_max": args.l_max},
        "finite_difference": {"h_s": args.h_s, "h_l": args.h_l, "h_theta": 1e-4},
        "cases": [{"name": c.name, "note": c.note, "params": asdict(c.params)} for c in cases],
        "caveat": "Finite-difference prescribed-geometry demanded-source diagnostic; not a matter model, not RSET, not a constraint solve.",
    }
    (args.outdir / "point_lifecycle_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    if not args.no_plots:
        make_plots(points, args.outdir, [c.name for c in cases])

    report = build_report(args.outdir, cases, compact, stage, top, args.ns, args.nl)
    (args.outdir / "POINT_LIFECYCLE_LEDGER_REPORT.md").write_text(report, encoding="utf-8")

    # Zip bundle
    zip_path = args.outdir.with_suffix(".zip")
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(args.outdir.iterdir()):
            zf.write(p, arcname=p.name)
        zf.write(Path(__file__), arcname=Path(__file__).name)

    print(json.dumps({"ok": True, "outdir": str(args.outdir), "zip": str(zip_path), "rows": int(points.shape[0])}, indent=2))


if __name__ == "__main__":
    main()
