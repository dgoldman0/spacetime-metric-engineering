# Catch/Rematch Bifurcation Probe

This is a point-level demanded-source diagnostic for deciding whether the catch/rematch problem behaves like a one-component shaping problem or a two-component split problem.

Grid: `15 x 25` per case.  Run kind: `screen`.

## Cases

| case                       | note                                                                        |
|:---------------------------|:----------------------------------------------------------------------------|
| base_R1p75                 | baseline R1.75 quarantine candidate                                         |
| shape_tanh_w20             | one-component tanh catch widened to 0.2                                     |
| shape_tanh_w24             | one-component tanh catch widened to 0.24                                    |
| shape_tanh_w32             | one-component tanh catch widened to 0.32                                    |
| shape_tanh_w40             | one-component tanh catch widened to 0.4                                     |
| shape_minjerk_w24          | one-component minimum-jerk catch over about 4w=0.96                         |
| shape_minjerk_w32          | one-component minimum-jerk catch over about 4w=1.28                         |
| shape_minjerk_w40          | one-component minimum-jerk catch over about 4w=1.6                          |
| shape_early_tanh_w24       | one-component catch shifted earlier and moderately widened                  |
| shape_early_minjerk_w32    | one-component minimum-jerk catch shifted earlier                            |
| split_spatial_broad25      | spatial split: 25% broad packet-centered support component                  |
| split_spatial_broad50      | spatial split: 50% broad packet-centered support component                  |
| split_spatial_broad75      | spatial split: 75% broad packet-centered support component                  |
| split_spatial_broad90      | spatial split: 90% broad packet-centered support component                  |
| split_spatial_broad100     | spatial split: 100% broad packet-centered support component                 |
| split_spatial_broad75_R120 | spatial split with wider broad component                                    |
| split_broad50_minjerk_w24  | spatial split plus smoothed catch                                           |
| split_broad75_minjerk_w32  | strong spatial split plus wider minjerk catch                               |
| split_temporal_beta_early  | temporal split: support beta catches earlier/wider, packet rematch baseline |
| split_temporal_packet_late | temporal split: support beta baseline, packet frame rematches later         |

## Decision table

| case                       |   decision_score |   radial_live_burden_score_ratio | live_packet_fraction__neg_Tkk_radial   | live_packet_fraction__abs_p_l   |   live_packet_burden__neg_Tkk_radial_ratio_vs_base |   live_packet_burden__abs_p_l_ratio_vs_base |   point_peak__neg_Tkk_radial_ratio_vs_base |   point_peak__abs_p_l_ratio_vs_base |   max_packet_norm_live |   positive_packet_norm_live |
|:---------------------------|-----------------:|---------------------------------:|:---------------------------------------|:--------------------------------|---------------------------------------------------:|--------------------------------------------:|-------------------------------------------:|------------------------------------:|-----------------------:|----------------------------:|
| split_temporal_beta_early  |           0.9098 |                           0.9098 | 24.39%                                 | 25.06%                          |                                             0.8197 |                                           1 |                                     0.8641 |                                   1 |                 -988.7 |                           0 |
| shape_early_minjerk_w32    |           0.9303 |                           0.9303 | 25.20%                                 | 25.06%                          |                                             0.8607 |                                           1 |                                     0.9078 |                                   1 |                 -988.7 |                           0 |
| shape_early_tanh_w24       |           0.9329 |                           0.9329 | 25.30%                                 | 25.06%                          |                                             0.8659 |                                           1 |                                     0.9425 |                                   1 |                 -988.5 |                           0 |
| split_broad75_minjerk_w32  |           0.9825 |                           0.9825 | 21.77%                                 | 25.06%                          |                                             0.965  |                                           1 |                                     1.145  |                                   1 |                 -988.7 |                           0 |
| shape_tanh_w40             |           0.9836 |                           0.9836 | 27.19%                                 | 25.06%                          |                                             0.9673 |                                           1 |                                     0.9167 |                                   1 |                 -970.6 |                           0 |
| shape_minjerk_w40          |           0.9882 |                           0.9882 | 27.35%                                 | 25.06%                          |                                             0.9763 |                                           1 |                                     0.9444 |                                   1 |                 -988.7 |                           0 |
| shape_tanh_w32             |           0.9892 |                           0.9892 | 27.40%                                 | 25.06%                          |                                             0.9783 |                                           1 |                                     0.9538 |                                   1 |                 -982.9 |                           0 |
| split_spatial_broad75_R120 |           0.9893 |                           0.9893 | 21.01%                                 | 25.06%                          |                                             0.9786 |                                           1 |                                     1.25   |                                   1 |                 -988.7 |                           0 |
| split_spatial_broad100     |           0.9895 |                           0.9895 | 20.46%                                 | 25.06%                          |                                             0.979  |                                           1 |                                     1.258  |                                   1 |                 -988.7 |                           0 |
| split_spatial_broad90      |           0.9912 |                           0.9912 | 21.27%                                 | 25.06%                          |                                             0.9825 |                                           1 |                                     1.165  |                                   1 |                 -988.7 |                           0 |
| shape_minjerk_w32          |           0.9924 |                           0.9924 | 27.50%                                 | 25.06%                          |                                             0.9848 |                                           1 |                                     0.9881 |                                   1 |                 -988.7 |                           0 |
| split_spatial_broad75      |           0.9938 |                           0.9938 | 22.51%                                 | 25.06%                          |                                             0.9876 |                                           1 |                                     1.03   |                                   1 |                 -988.7 |                           0 |
| split_broad50_minjerk_w24  |           0.9946 |                           0.9946 | 24.47%                                 | 25.06%                          |                                             0.9891 |                                           1 |                                     0.8187 |                                   1 |                 -988.7 |                           0 |
| shape_tanh_w24             |           0.9947 |                           0.9947 | 27.60%                                 | 25.06%                          |                                             0.9894 |                                           1 |                                     0.9843 |                                   1 |                 -987.8 |                           0 |
| shape_minjerk_w24          |           0.997  |                           0.997  | 27.68%                                 | 25.06%                          |                                             0.9939 |                                           1 |                                     1.003  |                                   1 |                 -988.7 |                           0 |
| shape_tanh_w20             |           0.9974 |                           0.9974 | 27.70%                                 | 25.06%                          |                                             0.9947 |                                           1 |                                     0.9943 |                                   1 |                 -988.5 |                           0 |
| split_spatial_broad50      |           0.9976 |                           0.9976 | 24.58%                                 | 25.06%                          |                                             0.9952 |                                           1 |                                     0.8187 |                                   1 |                 -988.7 |                           0 |
| base_R1p75                 |           1      |                           1      | 27.80%                                 | 25.06%                          |                                             1      |                                           1 |                                     1      |                                   1 |                 -988.7 |                           0 |
| split_temporal_packet_late |           1      |                           1      | 27.80%                                 | 25.06%                          |                                             1      |                                           1 |                                     1      |                                   1 |                 -988.7 |                           0 |
| split_spatial_broad25      |           1      |                           1      | 26.48%                                 | 25.06%                          |                                             1      |                                           1 |                                     0.7998 |                                   1 |                 -988.7 |                           0 |

## Radial stage burden

### neg_Tkk_radial
| case                       |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:---------------------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| split_temporal_beta_early  |            65.47 |           32.61 |            0 |               20.49  |                     0 |                     0 |
| shape_early_minjerk_w32    |             0    |          115.8  |            0 |                8.681 |                     0 |                     0 |
| shape_early_tanh_w24       |             0    |          110.5  |            0 |               14.78  |                     0 |                     0 |
| split_broad75_minjerk_w32  |             0    |          134.8  |            0 |                4.82  |                     0 |                     0 |
| shape_tanh_w40             |             0    |          138.1  |            0 |                1.771 |                     0 |                     0 |
| shape_minjerk_w40          |             0    |          139.5  |            0 |                1.774 |                     0 |                     0 |
| shape_tanh_w32             |             0    |          136.7  |            0 |                4.818 |                     0 |                     0 |
| split_spatial_broad75_R120 |            71.86 |           49.32 |            0 |               20.38  |                     0 |                     0 |
| split_spatial_broad100     |            72.18 |           49.1  |            0 |               20.34  |                     0 |                     0 |
| split_spatial_broad90      |            72.39 |           49.37 |            0 |               20.36  |                     0 |                     0 |
| shape_minjerk_w32          |             0    |          137.6  |            0 |                4.826 |                     0 |                     0 |
| split_spatial_broad75      |            72.71 |           49.78 |            0 |               20.39  |                     0 |                     0 |
| split_broad50_minjerk_w24  |            24.23 |          110.2  |            0 |                8.683 |                     0 |                     0 |
| shape_tanh_w24             |            25.06 |          109.4  |            0 |                8.654 |                     0 |                     0 |
| shape_minjerk_w24          |            25.06 |          110    |            0 |                8.681 |                     0 |                     0 |
| shape_tanh_w20             |            46.73 |           82.41 |            0 |               14.76  |                     0 |                     0 |
| split_spatial_broad50      |            73.13 |           50.41 |            0 |               20.43  |                     0 |                     0 |
| base_R1p75                 |            72.87 |           51.26 |            0 |               20.52  |                     0 |                     0 |
| split_temporal_packet_late |            72.87 |           51.26 |            0 |               20.52  |                     0 |                     0 |
| split_spatial_broad25      |            73.25 |           50.93 |            0 |               20.48  |                     0 |                     0 |

### abs_p_l
| case                       |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:---------------------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| split_temporal_beta_early  |            8.368 |           8.669 |            0 |               3.149  |                     0 |                     0 |
| shape_early_minjerk_w32    |            0     |          19.07  |            0 |               1.115  |                     0 |                     0 |
| shape_early_tanh_w24       |            0     |          18.24  |            0 |               1.945  |                     0 |                     0 |
| split_broad75_minjerk_w32  |            0     |          19.63  |            0 |               0.5541 |                     0 |                     0 |
| shape_tanh_w40             |            0     |          19.97  |            0 |               0.2134 |                     0 |                     0 |
| shape_minjerk_w40          |            0     |          19.97  |            0 |               0.2135 |                     0 |                     0 |
| shape_tanh_w32             |            0     |          19.63  |            0 |               0.5541 |                     0 |                     0 |
| split_spatial_broad75_R120 |            8.368 |           8.669 |            0 |               3.149  |                     0 |                     0 |
| split_spatial_broad100     |            8.368 |           8.669 |            0 |               3.149  |                     0 |                     0 |
| split_spatial_broad90      |            8.368 |           8.669 |            0 |               3.149  |                     0 |                     0 |
| shape_minjerk_w32          |            0     |          19.63  |            0 |               0.5541 |                     0 |                     0 |
| split_spatial_broad75      |            8.368 |           8.669 |            0 |               3.149  |                     0 |                     0 |
| split_broad50_minjerk_w24  |            2.779 |          16.29  |            0 |               1.115  |                     0 |                     0 |
| shape_tanh_w24             |            2.779 |          16.29  |            0 |               1.114  |                     0 |                     0 |
| shape_minjerk_w24          |            2.779 |          16.29  |            0 |               1.115  |                     0 |                     0 |
| shape_tanh_w20             |            5.597 |          12.64  |            0 |               1.945  |                     0 |                     0 |
| split_spatial_broad50      |            8.368 |           8.669 |            0 |               3.149  |                     0 |                     0 |
| base_R1p75                 |            8.368 |           8.669 |            0 |               3.149  |                     0 |                     0 |
| split_temporal_packet_late |            8.368 |           8.669 |            0 |               3.149  |                     0 |                     0 |
| split_spatial_broad25      |            8.368 |           8.669 |            0 |               3.149  |                     0 |                     0 |

## Initial reading

Best score in this run: `split_temporal_beta_early`.

A shaping diagnosis is supported when widened/smoothed one-component cases improve continuously and remain competitive with split cases. A split diagnosis is supported when split cases produce a discontinuous improvement in live radial burden or peak burden without packet-norm failure.
