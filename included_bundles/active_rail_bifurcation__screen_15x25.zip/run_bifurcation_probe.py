#!/usr/bin/env python3
"""
Bifurcation probe for the active-rail catch/rematch layer.

This script imports the point-level demanded-source evaluator from the previous
bundle and monkeypatches only the scalar schedule/mask layer. It compares:

1. one-component catch shaping variants, and
2. two-component spatial/temporal split variants.

The diagnostic question is whether live packet radial-null and radial-pressure
burden improve smoothly under catch reshaping, or drop qualitatively when the
catch/carry field is split into broad infrastructure support plus a smaller
packet-local correction.
"""
from __future__ import annotations

import json, math, shutil, sys, zipfile
from dataclasses import asdict, dataclass
from pathlib import Path
from types import SimpleNamespace
from typing import Dict, List

import numpy as np
import pandas as pd

BASE_SCRIPT = Path('/mnt/data/active_rail_point_ledger/active_rail_point_lifecycle_ledger.py')
sys.path.insert(0, str(BASE_SCRIPT.parent))
import active_rail_point_lifecycle_ledger as ar  # type: ignore

OUT = Path('/mnt/data/active_rail_bifurcation')


def ns_from_base(**overrides):
    p = ar.Params(V=10.0, Rth=1.75, ROmega=1.75, w_th=0.35, wOmega=1.40, aOmega=0.20)
    d = asdict(p)
    d.update(overrides)
    return SimpleNamespace(**d)


def minjerk_down_local(s, x_center, w):
    # Match ar.stage style: transition lives roughly [x-2w, x+2w].
    t0 = x_center - 2.0*w
    Tr = 4.0*w
    return ar.minjerk_down(s, t0, Tr)


def catch_factor(s, x, w, profile):
    if profile == 'tanh':
        return ar.falloff(np.asarray(s, dtype=float) - x, w)
    if profile == 'minjerk':
        return minjerk_down_local(np.asarray(s, dtype=float), x, w)
    raise ValueError(profile)


def custom_scalars(s: float, l: float, p) -> Dict[str, float]:
    """Extended scalar closure.

    Extra attributes if present:
      catch_profile: tanh|minjerk
      beta_x_catch, beta_w_catch, beta_profile
      packet_x_catch, packet_w_catch, packet_profile
      broad_share: fraction of beta mask supplied by broad infrastructure component
      Rbroad, wbroad: broad packet-centered support width
      broad_center: packet|throat
      local_gain, broad_gain: optional gains before normalization
    """
    s_arr = np.asarray(s, dtype=float)
    l_arr = np.asarray(l, dtype=float)

    catch_profile = getattr(p, 'catch_profile', 'tanh')
    bx = getattr(p, 'beta_x_catch', p.x_catch)
    bw = getattr(p, 'beta_w_catch', p.w_catch)
    bp = getattr(p, 'beta_profile', catch_profile)
    px = getattr(p, 'packet_x_catch', p.x_catch)
    pw = getattr(p, 'packet_w_catch', p.w_catch)
    pp = getattr(p, 'packet_profile', catch_profile)

    C_beta = catch_factor(s_arr, bx, bw, bp)
    C_packet = catch_factor(s_arr, px, pw, pp)
    U_beta = p.v_exit + (p.V - p.v_exit) * C_beta
    U_packet = p.v_exit + (p.V - p.v_exit) * C_packet

    E = ar.falloff(s_arr - p.x_beta, p.w_beta)
    q = ar.minjerk_down(s_arr, p.q_t0, p.q_Tr)

    W = ar.bump_sq(l_arr * l_arr, p.Rth, p.w_th)
    S_local = ar.bump_sq((l_arr - s_arr) * (l_arr - s_arr) + p.eps * p.eps, p.Rpass, p.w_pass)

    broad_share = float(getattr(p, 'broad_share', 0.0))
    Rb = float(getattr(p, 'Rbroad', max(0.90, 2.5*p.Rpass)))
    wb = float(getattr(p, 'wbroad', max(0.18, 3.0*p.w_pass)))
    center = getattr(p, 'broad_center', 'packet')
    if center == 'packet':
        S_broad = ar.bump_sq((l_arr - s_arr) * (l_arr - s_arr) + p.eps*p.eps, Rb, wb)
    elif center == 'throat':
        S_broad = ar.bump_sq(l_arr * l_arr, Rb, wb)
    else:
        raise ValueError(center)

    # Broad infrastructure component plus local packet correction.  At the packet
    # center both components are ~1, preserving cancellation, while gradients are
    # redistributed as broad_share increases.
    local_gain = float(getattr(p, 'local_gain', 1.0))
    broad_gain = float(getattr(p, 'broad_gain', 1.0))
    S_eff = (1.0 - broad_share) * local_gain * S_local + broad_share * broad_gain * S_broad

    A = np.exp(q * W * math.log(p.C0))
    T = np.exp(q * W * math.log(p.lam * p.C0))
    B = 1.0 + (p.B0 - 1.0) * W * q

    shoulder = np.exp(-((np.abs(l_arr) - 1.05) / 0.35) ** 2)
    N = np.exp(p.eta_N * 0.18 * q * shoulder)

    Wpower = W ** p.p_beta
    beta = -U_beta * E * Wpower * S_eff / B
    alpha = N * T
    sqrt_gamma_ll = B * A
    gamma_ll = sqrt_gamma_ll * sqrt_gamma_ll
    vcoord = U_packet / B
    gtt = -alpha * alpha + gamma_ll * beta * beta
    packet_norm = -alpha * alpha + gamma_ll * (vcoord + beta) ** 2

    WOmega = ar.bump_sq(l_arr * l_arr, p.ROmega, p.wOmega)
    QOmega = ar.falloff(s_arr - p.xOmega, p.wtOmega)
    COmega = np.exp(p.aOmega * QOmega * WOmega)
    gamma_omega = (l_arr * l_arr + p.Rth * p.Rth) * COmega * COmega

    return {
        'U': float(U_beta), 'U_beta': float(U_beta), 'U_packet': float(U_packet),
        'C_beta': float(C_beta), 'C_packet': float(C_packet),
        'E': float(E), 'q': float(q), 'W': float(W), 'S': float(S_local), 'S_broad': float(S_broad), 'S_eff': float(S_eff),
        'A': float(A), 'T': float(T), 'B': float(B), 'N': float(N),
        'beta': float(beta), 'alpha': float(alpha), 'sqrt_gamma_ll': float(sqrt_gamma_ll), 'gamma_ll': float(gamma_ll),
        'vcoord': float(vcoord), 'gtt': float(gtt), 'packet_norm': float(packet_norm),
        'WOmega': float(WOmega), 'QOmega': float(QOmega), 'COmega': float(COmega), 'gamma_omega': float(gamma_omega),
    }


ar.scalars = custom_scalars  # monkeypatch all metric/projection calls


def make_cases(kind: str) -> List[ar.CaseDef]:
    cases: List[ar.CaseDef] = []
    def add(name, note, **kw):
        cases.append(ar.CaseDef(name, ns_from_base(**kw), note))

    if kind in ('screen', 'all', 'refine'):
        add('base_R1p75', 'baseline R1.75 quarantine candidate')

    if kind in ('screen', 'all'):
        # One-component shaping: same field, smoother/wider/earlier catch.
        for w in [0.20, 0.24, 0.32, 0.40]:
            add(f'shape_tanh_w{int(w*100):02d}', f'one-component tanh catch widened to {w}', w_catch=w)
        for w in [0.24, 0.32, 0.40]:
            add(f'shape_minjerk_w{int(w*100):02d}', f'one-component minimum-jerk catch over about 4w={4*w}', w_catch=w, catch_profile='minjerk')
        add('shape_early_tanh_w24', 'one-component catch shifted earlier and moderately widened', x_catch=0.00, w_catch=0.24)
        add('shape_early_minjerk_w32', 'one-component minimum-jerk catch shifted earlier', x_catch=0.00, w_catch=0.32, catch_profile='minjerk')

        # Spatial split: broad infrastructure field plus smaller local correction.
        for f in [0.25, 0.50, 0.75, 0.90, 1.00]:
            add(f'split_spatial_broad{int(f*100):02d}', f'spatial split: {f:.0%} broad packet-centered support component', broad_share=f, Rbroad=0.95, wbroad=0.24)
        add('split_spatial_broad75_R120', 'spatial split with wider broad component', broad_share=0.75, Rbroad=1.20, wbroad=0.35)

        # Combined: modest shaping + spatial split.
        add('split_broad50_minjerk_w24', 'spatial split plus smoothed catch', broad_share=0.50, Rbroad=0.95, wbroad=0.24, w_catch=0.24, catch_profile='minjerk')
        add('split_broad75_minjerk_w32', 'strong spatial split plus wider minjerk catch', broad_share=0.75, Rbroad=1.05, wbroad=0.30, w_catch=0.32, catch_profile='minjerk')

        # Temporal split: beta/support catch happens earlier/wider than packet-frame rematch.
        add('split_temporal_beta_early', 'temporal split: support beta catches earlier/wider, packet rematch baseline', beta_x_catch=-0.05, beta_w_catch=0.32, beta_profile='minjerk', packet_x_catch=0.15, packet_w_catch=0.16, packet_profile='tanh')
        add('split_temporal_packet_late', 'temporal split: support beta baseline, packet frame rematches later', beta_x_catch=0.15, beta_w_catch=0.16, beta_profile='tanh', packet_x_catch=0.35, packet_w_catch=0.24, packet_profile='minjerk')

    if kind == 'refine':
        add('shape_minjerk_w40', 'best one-component shaping candidate from screen', w_catch=0.40, catch_profile='minjerk')
        add('split_spatial_broad75_R120', 'spatial split with wider broad component', broad_share=0.75, Rbroad=1.20, wbroad=0.35)
        add('split_broad75_minjerk_w32', 'strong spatial split plus wider minjerk catch', broad_share=0.75, Rbroad=1.05, wbroad=0.30, w_catch=0.32, catch_profile='minjerk')
    return cases


def run(kind: str, ns: int, nl: int, outdir: Path):
    outdir.mkdir(parents=True, exist_ok=True)
    cases = make_cases(kind)
    frames = []
    for c in cases:
        print('RUN', c.name, flush=True)
        frames.append(ar.compute_case(c, ns=ns, nl=nl, s_min=-0.45, s_max=1.40, l_min=-2.80, l_max=2.80, h_s=3.0e-3, h_l=3.0e-3, progress=False))
    points = pd.concat(frames, ignore_index=True)
    summary, compact, stage, top = ar.summarize_long(points)

    points.to_csv(outdir/'bifurcation_point_ledger.csv', index=False)
    summary.to_csv(outdir/'bifurcation_summary_long.csv', index=False)
    compact.to_csv(outdir/'bifurcation_global_compact.csv', index=False)
    stage.to_csv(outdir/'bifurcation_stage_summary.csv', index=False)
    top.to_csv(outdir/'bifurcation_top_bad_points.csv', index=False)

    # Derived table focused on the decision.
    focus = compact[compact['channel'].isin(['neg_Tkk_radial','abs_p_l','abs_pOmega','abs_j_l'])].copy()
    piv = focus.pivot(index='case', columns='channel', values=['live_packet_fraction','live_packet_burden','total_burden','point_peak','live_packet_point_peak'])
    piv.columns = [f'{a}__{b}' for a,b in piv.columns]
    piv = piv.reset_index()
    # Packet safety diagnostics.
    ok = points[points.get('error', pd.Series(index=points.index, dtype=object)).isna()].copy() if 'error' in points.columns else points.copy()
    live = ok[ok['inside_packet_live'].astype(bool)].copy()
    safety = live.groupby('case').agg(
        live_points=('case','size'),
        max_packet_norm_live=('packet_norm','max'),
        positive_packet_norm_live=('packet_norm', lambda x: int((x.astype(float)>0).sum())),
        min_packet_norm_live=('packet_norm','min'),
    ).reset_index()
    decision = piv.merge(safety, on='case', how='left')
    base = decision[decision['case']=='base_R1p75'].iloc[0]
    for metric in ['live_packet_fraction__neg_Tkk_radial','live_packet_fraction__abs_p_l','live_packet_burden__neg_Tkk_radial','live_packet_burden__abs_p_l','point_peak__neg_Tkk_radial','point_peak__abs_p_l']:
        if metric in decision.columns:
            decision[f'{metric}_ratio_vs_base'] = decision[metric] / base[metric]
    # Combined score: lower is better; penalize packet norm failure strongly.
    decision['radial_live_fraction_score'] = 0.5*decision['live_packet_fraction__neg_Tkk_radial'] + 0.5*decision['live_packet_fraction__abs_p_l']
    decision['radial_live_burden_score_ratio'] = 0.5*decision['live_packet_burden__neg_Tkk_radial_ratio_vs_base'] + 0.5*decision['live_packet_burden__abs_p_l_ratio_vs_base']
    decision['unsafe_penalty'] = (decision['positive_packet_norm_live'].fillna(0)>0).astype(float)*100.0
    decision['decision_score'] = decision['radial_live_burden_score_ratio'] + decision['unsafe_penalty']
    decision = decision.sort_values('decision_score')
    decision.to_csv(outdir/'bifurcation_decision_table.csv', index=False)

    # Stage only for radial channels, live burden.
    radial_stage = stage[(stage['channel'].isin(['neg_Tkk_radial','abs_p_l'])) & (stage['weight']=='volume')]
    radial_stage.to_csv(outdir/'bifurcation_radial_stage.csv', index=False)

    md = build_report(kind, ns, nl, cases, decision, radial_stage, top)
    (outdir/'BIFURCATION_FINDINGS.md').write_text(md, encoding='utf-8')

    meta = {'kind':kind, 'ns':ns, 'nl':nl, 'cases':[{'name':c.name,'note':c.note,'params':vars(c.params)} for c in cases]}
    (outdir/'bifurcation_metadata.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')

    zip_path = outdir.with_suffix('.zip')
    if zip_path.exists(): zip_path.unlink()
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(outdir.iterdir()):
            zf.write(p, arcname=p.name)
        zf.write(Path(__file__), arcname=Path(__file__).name)
        zf.write(BASE_SCRIPT, arcname='base_active_rail_point_lifecycle_ledger.py')
    print(json.dumps({'ok':True,'outdir':str(outdir),'zip':str(zip_path),'cases':len(cases),'rows':len(points)}, indent=2))


def fmt(x, pct=False):
    try:
        z=float(x)
        if pct: return f'{100*z:.2f}%'
        return f'{z:.4g}'
    except Exception:
        return 'nan'


def build_report(kind, ns, nl, cases, decision, radial_stage, top) -> str:
    lines=[]
    lines.append('# Catch/Rematch Bifurcation Probe')
    lines.append('')
    lines.append('This is a point-level demanded-source diagnostic for deciding whether the catch/rematch problem behaves like a one-component shaping problem or a two-component split problem.')
    lines.append('')
    lines.append(f'Grid: `{ns} x {nl}` per case.  Run kind: `{kind}`.')
    lines.append('')
    lines.append('## Cases')
    lines.append('')
    lines.append(pd.DataFrame([{'case':c.name,'note':c.note} for c in cases]).to_markdown(index=False))
    lines.append('')
    lines.append('## Decision table')
    lines.append('')
    cols=['case','decision_score','radial_live_burden_score_ratio','live_packet_fraction__neg_Tkk_radial','live_packet_fraction__abs_p_l','live_packet_burden__neg_Tkk_radial_ratio_vs_base','live_packet_burden__abs_p_l_ratio_vs_base','point_peak__neg_Tkk_radial_ratio_vs_base','point_peak__abs_p_l_ratio_vs_base','max_packet_norm_live','positive_packet_norm_live']
    show=decision[[c for c in cols if c in decision.columns]].copy()
    for c in show.columns:
        if c=='case': continue
        if 'fraction' in c:
            show[c]=show[c].map(lambda x: fmt(x, pct=True))
        else:
            show[c]=show[c].map(fmt)
    lines.append(show.to_markdown(index=False))
    lines.append('')
    lines.append('## Radial stage burden')
    lines.append('')
    for ch in ['neg_Tkk_radial','abs_p_l']:
        lines.append(f'### {ch}')
        sub=radial_stage[radial_stage['channel']==ch]
        tab=sub.pivot_table(index='case', columns='stage', values='live_packet_burden', aggfunc='sum')
        tab=tab.reindex(index=decision['case']).fillna(0.0)
        lines.append(tab.map(lambda x: f'{float(x):.4g}').to_markdown())
        lines.append('')
    lines.append('## Initial reading')
    lines.append('')
    best=decision.iloc[0]
    base=decision[decision['case']=='base_R1p75'].iloc[0]
    lines.append(f"Best score in this run: `{best['case']}`.")
    lines.append('')
    lines.append('A shaping diagnosis is supported when widened/smoothed one-component cases improve continuously and remain competitive with split cases. A split diagnosis is supported when split cases produce a discontinuous improvement in live radial burden or peak burden without packet-norm failure.')
    lines.append('')
    return '\n'.join(lines)


if __name__ == '__main__':
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument('--kind', choices=['screen','refine','all'], default='screen')
    ap.add_argument('--ns', type=int, default=25)
    ap.add_argument('--nl', type=int, default=41)
    ap.add_argument('--outdir', type=Path, default=OUT/'screen_25x41')
    args=ap.parse_args()
    run(args.kind, args.ns, args.nl, args.outdir)
