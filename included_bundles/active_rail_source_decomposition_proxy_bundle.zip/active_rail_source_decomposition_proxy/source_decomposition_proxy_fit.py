#!/usr/bin/env python3
"""
source_decomposition_proxy_fit.py

Proxy source decomposition for the active-rail freeze candidate.

Input: point-level demanded source ledger CSV with columns from the active rail
lifecycle evaluator. Output: nonnegative component-shaped proxy fits by channel.

This is a diagnostic source-role fit. It is not a solved matter model.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import nnls

CHANNEL_DEFS = {
    'neg_Tkk_radial': {'bad_col':'bad_neg_Tkk_radial','description':'negative radial null contraction'},
    'abs_p_l': {'bad_col':'bad_abs_p_l','description':'radial pressure magnitude'},
    'abs_pOmega': {'bad_col':'bad_abs_pOmega','description':'angular pressure magnitude'},
    'abs_j_l': {'bad_col':'bad_abs_j_l','description':'radial current magnitude'},
    'neg_rho_euler': {'bad_col':'bad_neg_rho_euler','description':'negative Eulerian density'},
    'neg_rho_packet': {'bad_col':'bad_neg_rho_packet','description':'negative packet-comoving density'},
}

def make_basis(p: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, np.ndarray]:
    p = p.copy().reset_index(drop=True)
    N = p['alpha'] / p['T'].replace(0,np.nan)
    p['N_lapse_cushion'] = (N - 1.0).clip(lower=0).fillna(0.0)
    p['COmega_excess'] = (p['COmega'] - 1.0).clip(lower=0).fillna(0.0)
    p['beta_abs_norm'] = p['beta'].abs()
    stage = p['stage'].astype(str)
    region = p['region'].astype(str)
    p['mask_live_packet'] = p['inside_packet_live'].astype(float)
    p['mask_geom_packet'] = p['inside_packet_geom'].astype(float)
    p['mask_catch'] = (stage=='catch_rematch').astype(float)
    p['mask_release'] = (stage=='release_shift_fade').astype(float)
    p['mask_post'] = (stage=='post_release_buffer').astype(float)
    p['mask_reset'] = (stage=='reset_decompression').astype(float)
    p['mask_core'] = (region=='core_throat').astype(float)
    p['mask_support_edge'] = (region=='support_edge').astype(float)
    p['mask_outer'] = (region=='outer_quarantine_shell').astype(float)
    p['W_edge_proxy'] = (p['W'].clip(0,1) * (1-p['W'].clip(0,1))).fillna(0.0)
    bases = pd.DataFrame(index=p.index)
    bases['cold_core_substrate'] = p['q'].clip(0) * p['W'].clip(0) * (p['mask_core'] + 0.35*p['mask_support_edge'])
    bases['radial_support_edge_shell'] = p['q'].clip(0) * (p['W_edge_proxy'] + 0.15*p['mask_support_edge'])
    bases['outer_quarantine_jacket'] = p['COmega_excess'] * (0.35*p['mask_support_edge'] + p['mask_outer'] + 0.15*p['mask_core'])
    bases['lapse_cushion_sector'] = p['N_lapse_cushion'] * (0.5*p['mask_support_edge'] + p['mask_outer'] + 0.2*p['mask_core'] + 0.2*p['mask_geom_packet'])
    bases['shift_packet_carrier'] = p['E'].clip(0) * p['S'].clip(0) * p['beta_abs_norm']
    bases['catch_rematch_transient'] = p['mask_catch'] * (0.25 + p['S'].clip(0) + 0.5*p['W'].clip(0))
    bases['release_shift_transient'] = p['mask_release'] * (0.25 + p['S'].clip(0) + 0.5*p['E'].clip(0))
    bases['packet_local_residual'] = p['mask_live_packet'] * (0.25 + p['S'].clip(0))
    bases['reset_decompression_infra'] = (p['mask_reset'] + 0.5*p['mask_post']) * (0.25 + p['q'].clip(0) + p['W'].clip(0)) * (1 - p['mask_live_packet'])
    diag=[]
    for col in bases.columns:
        raw=bases[col].to_numpy(dtype=float)
        mx=np.nanmax(raw) if raw.size else 0
        if mx>0: bases[col]=raw/mx
        else: bases[col]=0.0
        diag.append({'component':col,'raw_max':float(mx),'support_points':int((bases[col]>1e-6).sum()),'live_packet_support_points':int(((bases[col]>1e-6)&(p['inside_packet_live'])).sum())})
    vol = p['volume_weight'].to_numpy(dtype=float) if 'volume_weight' in p.columns else p.get('cell_area', pd.Series(1.0, index=p.index)).to_numpy(dtype=float)
    vol = np.where(np.isfinite(vol)&(vol>0), vol, 1.0)
    return bases, pd.DataFrame(diag), vol

def run(input_csv: Path, outdir: Path, case: str | None) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    df=pd.read_csv(input_csv)
    if case and 'case' in df.columns:
        df=df[df['case']==case].copy()
    df=df.reset_index(drop=True)
    bases, basis_diag, vol = make_basis(df)
    X0=bases.to_numpy(dtype=float)
    w=np.sqrt(np.maximum(vol,1e-18))
    Xw=X0*w[:,None]
    live=df['inside_packet_live'].to_numpy(dtype=bool)
    fit_rows=[]; alloc_rows=[]; residual_rows=[]
    for ch,cd in CHANNEL_DEFS.items():
        y=df[cd['bad_col']].to_numpy(dtype=float)
        y=np.where(np.isfinite(y),y,0.0)
        coeff,rnorm=nnls(Xw,y*w,maxiter=5000)
        yhat=np.clip(X0@coeff,0,None)
        actual=y*vol; pred=yhat*vol
        resid=y-yhat; under=np.maximum(resid,0)*vol; absres=np.abs(resid)*vol
        total=float(actual.sum()); live_total=float(actual[live].sum())
        fit_rows.append({'channel':ch,'description':cd['description'],'actual_total_burden':total,'actual_live_packet_burden':live_total,'actual_live_packet_fraction':live_total/total if total else np.nan,'predicted_total_burden':float(pred.sum()),'predicted_live_packet_burden':float(pred[live].sum()),'l1_residual_total_fraction':float(absres.sum()/total) if total else np.nan,'underfit_total_fraction':float(under.sum()/total) if total else np.nan,'live_underfit_fraction_of_live_actual':float(under[live].sum()/live_total) if live_total else 0.0,'rnorm_weighted_l2':float(rnorm)})
        comp_pred=X0*coeff[None,:]*vol[:,None]
        for j,name in enumerate(bases.columns):
            ctot=float(comp_pred[:,j].sum()); clive=float(comp_pred[live,j].sum())
            alloc_rows.append({'channel':ch,'component':name,'coefficient':float(coeff[j]),'allocated_total_burden':ctot,'allocated_total_share_of_actual':ctot/total if total else np.nan,'allocated_live_packet_burden':clive,'allocated_live_share_of_actual_live':clive/live_total if live_total else 0.0,'component_live_fraction':clive/ctot if ctot else 0.0})
        tmp=df[['stage','region','inside_packet_live']].copy()
        tmp['actual_burden']=actual; tmp['predicted_burden']=pred; tmp['underfit_burden']=under; tmp['abs_residual_burden']=absres
        agg=tmp.groupby(['stage','region'],dropna=False).sum(numeric_only=True).reset_index()
        for _,rr in agg.iterrows():
            residual_rows.append({'channel':ch,'stage':rr['stage'],'region':rr['region'],'actual_burden':float(rr['actual_burden']),'predicted_burden':float(rr['predicted_burden']),'underfit_burden':float(rr['underfit_burden']),'abs_residual_burden':float(rr['abs_residual_burden']),'underfit_fraction_of_channel_total':float(rr['underfit_burden']/total) if total else np.nan})
    pd.DataFrame(fit_rows).to_csv(outdir/'source_fit_summary.csv',index=False)
    pd.DataFrame(alloc_rows).to_csv(outdir/'source_component_allocation_by_channel.csv',index=False)
    pd.DataFrame(residual_rows).to_csv(outdir/'source_residual_by_stage_region.csv',index=False)
    basis_diag.to_csv(outdir/'source_component_basis_diagnostics.csv',index=False)
    pd.concat([df,bases.add_prefix('basis__')],axis=1).to_csv(outdir/'source_candidate_point_ledger_with_basis.csv',index=False)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input-csv', type=Path, required=True)
    ap.add_argument('--outdir', type=Path, required=True)
    ap.add_argument('--case', default=None)
    args=ap.parse_args()
    run(args.input_csv,args.outdir,args.case)
if __name__=='__main__': main()
