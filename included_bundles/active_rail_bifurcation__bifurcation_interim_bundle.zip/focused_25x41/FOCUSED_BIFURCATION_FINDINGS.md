# Catch/Rematch Bifurcation Probe

This is a point-level demanded-source diagnostic for deciding whether the catch/rematch problem behaves like a one-component shaping problem or a two-component split problem.

Grid: `25 x 41` per case.  Run kind: `focused`.

## Cases

| case                      | note                                                                        |
|:--------------------------|:----------------------------------------------------------------------------|
| base_R1p75                | baseline R1.75 quarantine candidate                                         |
| shape_early_minjerk_w32   | one-component minimum-jerk catch shifted earlier                            |
| split_temporal_beta_early | temporal split: support beta catches earlier/wider, packet rematch baseline |
| split_spatial_broad100    | spatial split: all broad packet-centered support component                  |
| split_broad75_minjerk_w32 | strong spatial split plus wider minjerk catch                               |

## Decision table

| case                      |   decision_score |   radial_live_burden_score_ratio | live_packet_fraction__neg_Tkk_radial   | live_packet_fraction__abs_p_l   |   live_packet_burden__neg_Tkk_radial_ratio_vs_base |   live_packet_burden__abs_p_l_ratio_vs_base |   point_peak__neg_Tkk_radial_ratio_vs_base |   point_peak__abs_p_l_ratio_vs_base |   max_packet_norm_live |   positive_packet_norm_live |
|:--------------------------|-----------------:|---------------------------------:|:---------------------------------------|:--------------------------------|---------------------------------------------------:|--------------------------------------------:|-------------------------------------------:|------------------------------------:|-----------------------:|----------------------------:|
| shape_early_minjerk_w32   |           0.9295 |                           0.9295 | 25.92%                                 | 25.02%                          |                                             0.8589 |                                           1 |                                     0.9991 |                                   1 |                   -734 |                           0 |
| split_spatial_broad100    |           0.9652 |                           0.9652 | 20.31%                                 | 25.02%                          |                                             0.9305 |                                           1 |                                     1.423  |                                   1 |                   -734 |                           0 |
| split_broad75_minjerk_w32 |           0.9665 |                           0.9665 | 21.93%                                 | 25.02%                          |                                             0.9331 |                                           1 |                                     1.18   |                                   1 |                   -734 |                           0 |
| base_R1p75                |           1      |                           1      | 28.66%                                 | 25.02%                          |                                             1      |                                           1 |                                     1      |                                   1 |                   -734 |                           0 |
| split_temporal_beta_early |         100.9    |                           0.9078 | 25.01%                                 | 25.02%                          |                                             0.8155 |                                           1 |                                     0.9834 |                                   1 |                  72910 |                           1 |

## Radial stage burden

### neg_Tkk_radial
| case                      |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:--------------------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| shape_early_minjerk_w32   |             0    |          116.6  |            0 |                8.936 |                     0 |                     0 |
| split_spatial_broad100    |            55.99 |           62.02 |            0 |               17.97  |                     0 |                     0 |
| split_broad75_minjerk_w32 |             0    |          132.2  |            0 |                4.125 |                     0 |                     0 |
| base_R1p75                |            61.53 |           66.67 |            0 |               17.95  |                     0 |                     0 |
| split_temporal_beta_early |            56.86 |           44.37 |            0 |               17.95  |                     0 |                     0 |

### abs_p_l
| case                      |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:--------------------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| shape_early_minjerk_w32   |            0     |           18.45 |            0 |               1.121  |                     0 |                     0 |
| split_spatial_broad100    |            6.517 |           10.19 |            0 |               2.863  |                     0 |                     0 |
| split_broad75_minjerk_w32 |            0     |           19.09 |            0 |               0.4843 |                     0 |                     0 |
| base_R1p75                |            6.517 |           10.19 |            0 |               2.863  |                     0 |                     0 |
| split_temporal_beta_early |            6.517 |           10.19 |            0 |               2.863  |                     0 |                     0 |

## Initial reading

Best score in this run: `shape_early_minjerk_w32`.

A shaping diagnosis is supported when widened/smoothed one-component cases improve continuously and remain competitive with split cases. A split diagnosis is supported when split cases produce a discontinuous improvement in live radial burden or peak burden without packet-norm failure.
