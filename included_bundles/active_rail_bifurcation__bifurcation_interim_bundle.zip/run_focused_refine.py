from pathlib import Path
import sys, json, zipfile
import pandas as pd
sys.path.insert(0, '/mnt/data/active_rail_bifurcation')
import run_bifurcation_probe as rb
ar=rb.ar
OUT=Path('/mnt/data/active_rail_bifurcation/focused_25x41')
OUT.mkdir(exist_ok=True)

def C(name, note, **kw):
    return ar.CaseDef(name, rb.ns_from_base(**kw), note)

cases=[
    C('base_R1p75','baseline R1.75 quarantine candidate'),
    C('shape_early_minjerk_w32','one-component minimum-jerk catch shifted earlier', x_catch=0.00, w_catch=0.32, catch_profile='minjerk'),
    C('split_temporal_beta_early','temporal split: support beta catches earlier/wider, packet rematch baseline', beta_x_catch=-0.05, beta_w_catch=0.32, beta_profile='minjerk', packet_x_catch=0.15, packet_w_catch=0.16, packet_profile='tanh'),
    C('split_spatial_broad100','spatial split: all broad packet-centered support component', broad_share=1.00, Rbroad=0.95, wbroad=0.24),
    C('split_broad75_minjerk_w32','strong spatial split plus wider minjerk catch', broad_share=0.75, Rbroad=1.05, wbroad=0.30, w_catch=0.32, catch_profile='minjerk'),
]
frames=[]
for c in cases:
    print('RUN',c.name,flush=True)
    frames.append(ar.compute_case(c, ns=25, nl=41, s_min=-0.45, s_max=1.40, l_min=-2.80, l_max=2.80, h_s=2.5e-3, h_l=2.5e-3, progress=False))
points=pd.concat(frames, ignore_index=True)
summary,compact,stage,top=ar.summarize_long(points)
points.to_csv(OUT/'focused_point_ledger.csv',index=False)
summary.to_csv(OUT/'focused_summary_long.csv',index=False)
compact.to_csv(OUT/'focused_global_compact.csv',index=False)
stage.to_csv(OUT/'focused_stage_summary.csv',index=False)
top.to_csv(OUT/'focused_top_bad_points.csv',index=False)
# decision table copied from rb.run
focus=compact[compact['channel'].isin(['neg_Tkk_radial','abs_p_l','abs_pOmega','abs_j_l'])].copy()
piv=focus.pivot(index='case', columns='channel', values=['live_packet_fraction','live_packet_burden','total_burden','point_peak','live_packet_point_peak'])
piv.columns=[f'{a}__{b}' for a,b in piv.columns]
piv=piv.reset_index()
ok=points[points.get('error', pd.Series(index=points.index, dtype=object)).isna()].copy() if 'error' in points.columns else points.copy()
live=ok[ok['inside_packet_live'].astype(bool)].copy()
safety=live.groupby('case').agg(live_points=('case','size'),max_packet_norm_live=('packet_norm','max'),positive_packet_norm_live=('packet_norm',lambda x:int((x.astype(float)>0).sum())),min_packet_norm_live=('packet_norm','min')).reset_index()
decision=piv.merge(safety,on='case',how='left')
base=decision[decision.case=='base_R1p75'].iloc[0]
for metric in ['live_packet_fraction__neg_Tkk_radial','live_packet_fraction__abs_p_l','live_packet_burden__neg_Tkk_radial','live_packet_burden__abs_p_l','point_peak__neg_Tkk_radial','point_peak__abs_p_l']:
    decision[f'{metric}_ratio_vs_base']=decision[metric]/base[metric]
decision['radial_live_fraction_score']=0.5*decision['live_packet_fraction__neg_Tkk_radial']+0.5*decision['live_packet_fraction__abs_p_l']
decision['radial_live_burden_score_ratio']=0.5*decision['live_packet_burden__neg_Tkk_radial_ratio_vs_base']+0.5*decision['live_packet_burden__abs_p_l_ratio_vs_base']
decision['unsafe_penalty']=(decision['positive_packet_norm_live'].fillna(0)>0).astype(float)*100
decision['decision_score']=decision['radial_live_burden_score_ratio']+decision['unsafe_penalty']
decision=decision.sort_values('decision_score')
decision.to_csv(OUT/'focused_decision_table.csv',index=False)
radial_stage=stage[(stage.channel.isin(['neg_Tkk_radial','abs_p_l']))&(stage.weight=='volume')]
radial_stage.to_csv(OUT/'focused_radial_stage.csv',index=False)
# quick report
md=rb.build_report('focused',25,41,cases,decision,radial_stage,top)
OUT.joinpath('FOCUSED_BIFURCATION_FINDINGS.md').write_text(md)
OUT.joinpath('focused_metadata.json').write_text(json.dumps({'cases':[{'name':c.name,'note':c.note,'params':vars(c.params)} for c in cases]},indent=2))
zip_path=OUT.with_suffix('.zip')
if zip_path.exists(): zip_path.unlink()
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as zf:
    for p in sorted(OUT.iterdir()): zf.write(p,arcname=p.name)
    zf.write('/mnt/data/active_rail_bifurcation/run_bifurcation_probe.py',arcname='run_bifurcation_probe.py')
    zf.write('/mnt/data/active_rail_bifurcation/run_focused_refine.py',arcname='run_focused_refine.py')
print(json.dumps({'ok':True,'outdir':str(OUT),'zip':str(zip_path),'rows':len(points)},indent=2))
