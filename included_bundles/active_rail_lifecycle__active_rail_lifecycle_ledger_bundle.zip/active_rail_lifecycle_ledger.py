#!/usr/bin/env python3
"""
active_rail_lifecycle_ledger.py

Lifecycle-resolved packet/source ledger for the active-rail source analysis.

The script intentionally supports two data levels:

1. Point-ledger mode, if a full point-level demanded-source CSV is available.
   This is the preferred mode. It computes volume-weighted burdens, live-packet
   exposure, reset-excluded packet exposure, region/stage tables, and top bad
   points.

2. Region/phase mode, if the committed freeze bundle only has
   region_phase_ledger.csv. This is a peak-diagnostic fallback. It cannot create
   true volume-integrated packet fractions, but it does cleanly separate packet
   lifecycle stages and stops counting decompression/reset as passenger exposure.

This is a prescribed-geometry demanded-source postprocessor. It is not a matter
model, not a constraint solve, and not an RSET calculation.
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd


DEFAULT_SEARCH_DIRS = [
    Path("warp-complex/active_rail_source_analysis/active_rail_full_analysis_report"),
    Path("warp-complex/active_rail_source_analysis/active_rail_source_analysis_freeze_report/data"),
    Path("warp-complex/active_rail_source_analysis"),
]

POINT_FILE_CANDIDATES = [
    "source_quarantine_points.csv",
    "source_ledger_points.csv",
    "freeze_source_points.csv",
    "active_rail_source_points.csv",
    "lifecycle_points_with_masks.csv",
]

REGION_PHASE_CANDIDATES = ["region_phase_ledger.csv"]
TRADEOFF_CANDIDATES = ["candidate_infrastructure_tradeoff.csv"]
SUMMARY_CANDIDATES = ["source_quarantine_summary.csv"]


@dataclass(frozen=True)
class LifecycleParams:
    # Geometry-ish packet/support defaults from the current active-rail reports.
    Rpass: float = 0.35
    Rth: float = 1.75

    # Lifecycle phase centers/widths in the reduced service coordinate.
    # Used only when point-ledger rows have s/l but no explicit phase column.
    x_entry: float = -0.35
    x_catch: float = 0.15
    x_beta: float = 0.70
    x_release: float = 1.06
    x_q: float = 1.25
    w_entry: float = 0.12
    w_catch: float = 0.16
    w_beta: float = 0.18
    w_release: float = 0.16
    w_q: float = 0.18

    # Packet accounting policy.
    include_entry_as_live: bool = True
    include_release_as_live: bool = True
    count_reset_as_packet_exposure: bool = False

    # How to build a geometric packet mask when no packet column exists.
    # diagonal: |l - s| <= Rpass, matching the older scrap convention.
    # zero:     |l| <= Rpass.
    packet_center_mode: str = "diagonal"


# Channel definitions in a unified form.
CHANNELS: Dict[str, Dict[str, object]] = {
    "neg_rho": {
        "kind": "negative",
        "point_columns": ["rho_euler", "rho", "energy_density"],
        "phase_column": "min_rho",
        "description": "negative Eulerian energy density",
    },
    "neg_rho_pkt": {
        "kind": "negative",
        "point_columns": ["rho_packet", "rho_pkt", "rho_euler"],
        "phase_column": "min_rho_pkt",
        "description": "negative packet-frame energy density, when available",
    },
    "neg_Tkk": {
        "kind": "negative_min",
        "point_columns": ["Tkk_min_radial", "Tkk_plus", "Tkk_minus", "Tkk"],
        "phase_column": "min_Tkk",
        "description": "negative radial null contraction",
    },
    "abs_p_l": {
        "kind": "absolute",
        "point_columns": ["p_l_unit", "p_l", "radial_pressure"],
        "phase_column": "max_abs_p_l",
        "description": "radial pressure magnitude",
    },
    "abs_pOmega": {
        "kind": "absolute",
        "point_columns": ["p_omega_unit", "pOmega", "p_omega", "angular_pressure"],
        "phase_column": "max_abs_pOmega",
        "description": "angular pressure magnitude",
    },
    "abs_j_l": {
        "kind": "absolute",
        "point_columns": ["j_l_unit", "j_l", "radial_current"],
        "phase_column": "max_abs_j_l",
        "description": "radial current magnitude",
    },
}

PHASE_TO_STAGE = {
    "precatch": "entry_pre_catch",
    "pre_catch": "entry_pre_catch",
    "pre_catch_support": "entry_pre_catch",
    "entry": "entry_pre_catch",
    "catch": "catch_rematch",
    "catch_rematch": "catch_rematch",
    "hold": "held_transport",
    "held_transport": "held_transport",
    "carry": "held_transport",
    "shift_fade": "shift_fade_release",
    "release": "shift_fade_release",
    "post_shift_pre_relax": "release_margin",
    "decompression": "decompression_reset",
    "minjerk_decompression": "decompression_reset",
    "reset": "decompression_reset",
    "tail": "reset_tail",
    "reset_tail": "reset_tail",
}

STAGE_ORDER = [
    "entry_pre_catch",
    "catch_rematch",
    "held_transport",
    "shift_fade_release",
    "release_margin",
    "decompression_reset",
    "reset_tail",
]

LIVE_STAGES_DEFAULT = {
    "entry_pre_catch",
    "catch_rematch",
    "held_transport",
    "shift_fade_release",
    "release_margin",
}

REGION_ORDER = ["packet", "packet_support", "core", "support_edge", "outer_shoulder", "far_exterior", "all"]


def read_existing(paths: Iterable[Path]) -> Optional[Path]:
    for p in paths:
        if p and p.exists():
            return p
    return None


def find_file(search_dirs: List[Path], names: List[str]) -> Optional[Path]:
    for d in search_dirs:
        for name in names:
            p = d / name
            if p.exists():
                return p
    for d in search_dirs:
        if not d.exists():
            continue
        for p in d.rglob("*.csv"):
            if p.name in names:
                return p
    return None


def safe_fraction(numer: float, denom: float) -> float:
    if denom <= 0 or not math.isfinite(denom):
        return float("nan")
    return numer / denom


def stage_sort_key(stage: str) -> int:
    try:
        return STAGE_ORDER.index(stage)
    except ValueError:
        return len(STAGE_ORDER) + 1


def normalize_phase(phase: object) -> str:
    key = str(phase).strip().lower()
    return PHASE_TO_STAGE.get(key, key)


def live_stages(params: LifecycleParams) -> set[str]:
    stages = set(LIVE_STAGES_DEFAULT)
    if not params.include_entry_as_live:
        stages.discard("entry_pre_catch")
    if not params.include_release_as_live:
        stages.discard("release_margin")
        stages.discard("shift_fade_release")
    if params.count_reset_as_packet_exposure:
        stages.add("decompression_reset")
        stages.add("reset_tail")
    return stages


def phase_name_from_s(s: float, p: LifecycleParams) -> str:
    if s < p.x_catch - 2 * p.w_catch:
        return "entry_pre_catch"
    if abs(s - p.x_catch) <= 2 * p.w_catch:
        return "catch_rematch"
    if p.x_catch + 2 * p.w_catch < s < p.x_beta - 2 * p.w_beta:
        return "held_transport"
    if abs(s - p.x_beta) <= 2 * p.w_beta:
        return "shift_fade_release"
    if p.x_beta + 2 * p.w_beta < s < p.x_release + 2 * p.w_release:
        return "release_margin"
    if abs(s - p.x_q) <= 2 * p.w_q:
        return "decompression_reset"
    return "reset_tail"


def region_name_from_l(l: float, p: LifecycleParams) -> str:
    al = abs(l)
    if al <= p.Rpass:
        return "packet"
    if al <= 0.65 * p.Rth:
        return "core"
    if al <= 1.20 * p.Rth:
        return "support_edge"
    if al <= 1.85 * p.Rth:
        return "outer_shoulder"
    return "far_exterior"


def point_channel_values(df: pd.DataFrame, channel: str) -> Tuple[str, np.ndarray]:
    spec = CHANNELS[channel]
    cols = [c for c in spec["point_columns"] if c in df.columns]
    if not cols:
        raise KeyError(f"Missing point-level channel {channel}; expected one of {spec['point_columns']}")
    if spec["kind"] == "negative_min" and {"Tkk_plus", "Tkk_minus"}.issubset(df.columns):
        return "min(Tkk_plus,Tkk_minus)", np.nanmin(
            np.vstack([df["Tkk_plus"].astype(float), df["Tkk_minus"].astype(float)]), axis=0
        )
    col = cols[0]
    return col, df[col].astype(float).to_numpy()


def badness(values: np.ndarray, channel: str) -> np.ndarray:
    kind = CHANNELS[channel]["kind"]
    if kind in {"negative", "negative_min"}:
        return np.maximum(-values, 0.0)
    if kind == "absolute":
        return np.abs(values)
    raise ValueError(kind)


def add_point_lifecycle_columns(df: pd.DataFrame, params: LifecycleParams) -> pd.DataFrame:
    df = df.copy()
    if "phase" in df.columns:
        df["stage"] = df["phase"].map(normalize_phase)
    elif "phase_lifecycle" in df.columns:
        df["stage"] = df["phase_lifecycle"].map(normalize_phase)
    elif "s" in df.columns:
        df["stage"] = df["s"].astype(float).map(lambda x: phase_name_from_s(x, params))
    else:
        raise ValueError("Point ledger needs 'phase', 'phase_lifecycle', or 's'.")

    if "region" in df.columns:
        df["region_lifecycle"] = df["region"].astype(str)
    elif "region_lifecycle" not in df.columns:
        if "l" not in df.columns:
            raise ValueError("Point ledger needs 'region' or 'l'.")
        df["region_lifecycle"] = df["l"].astype(float).map(lambda x: region_name_from_l(x, params))

    if "inside_packet" in df.columns:
        df["inside_packet_geom"] = df["inside_packet"].astype(bool)
    elif "inside_packet_geom" not in df.columns:
        if "l" not in df.columns:
            raise ValueError("Point ledger needs packet mask or 'l'.")
        if params.packet_center_mode == "zero":
            df["inside_packet_geom"] = df["l"].astype(float).abs() <= params.Rpass
        elif params.packet_center_mode == "diagonal":
            if "s" not in df.columns:
                raise ValueError("diagonal packet-center mode needs 's'.")
            df["inside_packet_geom"] = (df["l"].astype(float) - df["s"].astype(float)).abs() <= params.Rpass
        else:
            raise ValueError("packet_center_mode must be 'diagonal' or 'zero'.")

    live = live_stages(params)
    df["inside_packet_live"] = df["inside_packet_geom"] & df["stage"].isin(live)
    df["inside_packet_accounting"] = df["inside_packet_live"]

    if "volume_density" not in df.columns:
        df["volume_density"] = 1.0
    return df


def summarize_points(df: pd.DataFrame) -> Dict[str, pd.DataFrame]:
    volume = df["volume_density"].astype(float).to_numpy()
    outputs: Dict[str, pd.DataFrame] = {}

    def one_scope(group_cols: List[str]) -> pd.DataFrame:
        groups = [((), df)] if not group_cols else df.groupby(group_cols, dropna=False)
        rows = []
        for key, g in groups:
            if group_cols and not isinstance(key, tuple):
                key = (key,)
            row = {col: val for col, val in zip(group_cols, key)}
            row["points"] = int(len(g))
            gv = g["volume_density"].astype(float).to_numpy()
            geom = g["inside_packet_geom"].to_numpy(dtype=bool)
            live = g["inside_packet_live"].to_numpy(dtype=bool)
            for ch in CHANNELS:
                try:
                    source_col, vals = point_channel_values(g, ch)
                except KeyError:
                    continue
                b = badness(vals, ch) * gv
                total = float(np.nansum(b))
                geom_b = float(np.nansum(b[geom]))
                live_b = float(np.nansum(b[live]))
                row[f"{ch}_source_column"] = source_col
                row[f"{ch}_peak"] = float(np.nanmax(badness(vals, ch)))
                row[f"{ch}_total_burden"] = total
                row[f"{ch}_packet_geom_burden"] = geom_b
                row[f"{ch}_packet_live_burden"] = live_b
                row[f"{ch}_packet_live_fraction"] = safe_fraction(live_b, total)
                row[f"{ch}_reset_removed_burden"] = geom_b - live_b
            rows.append(row)
        out = pd.DataFrame(rows)
        if "stage" in out.columns:
            out = out.sort_values("stage", key=lambda s: s.map(stage_sort_key))
        return out

    outputs["point_global"] = one_scope([])
    outputs["point_by_stage"] = one_scope(["stage"])
    outputs["point_by_region"] = one_scope(["region_lifecycle"])
    outputs["point_by_stage_region"] = one_scope(["stage", "region_lifecycle"])
    return outputs


def phase_peak_value(row: pd.Series, channel: str) -> float:
    col = CHANNELS[channel]["phase_column"]
    if col not in row or pd.isna(row[col]):
        return float("nan")
    val = float(row[col])
    if CHANNELS[channel]["kind"] in {"negative", "negative_min"}:
        return max(-val, 0.0)
    return abs(val)


def summarize_region_phase(df: pd.DataFrame, case: str, params: LifecycleParams) -> Dict[str, pd.DataFrame]:
    if case not in set(df["case"].astype(str)):
        cases = sorted(df["case"].astype(str).unique())
        raise ValueError(f"case={case!r} not found. Available cases: {cases}")
    cdf = df[df["case"].astype(str) == case].copy()
    cdf["stage"] = cdf["phase"].map(normalize_phase)
    live = live_stages(params)
    cdf["packet_live_accounting"] = cdf["stage"].isin(live)
    cdf["passenger_exposure_region"] = cdf["region"].isin(["packet", "packet_support"])
    cdf["counts_as_passenger_exposure"] = cdf["packet_live_accounting"] & cdf["passenger_exposure_region"]

    for ch in CHANNELS:
        if CHANNELS[ch]["phase_column"] in cdf.columns:
            cdf[f"{ch}_peak_badness"] = cdf.apply(lambda r: phase_peak_value(r, ch), axis=1)

    peak_cols = [f"{ch}_peak_badness" for ch in CHANNELS if f"{ch}_peak_badness" in cdf.columns]
    id_cols = ["case", "region", "phase", "stage", "n", "packet_live_accounting", "counts_as_passenger_exposure"]
    stage_peak_diagnostics = cdf[id_cols + peak_cols].copy()
    stage_peak_diagnostics["stage_order"] = stage_peak_diagnostics["stage"].map(stage_sort_key)
    stage_peak_diagnostics["region_order"] = stage_peak_diagnostics["region"].map(
        lambda r: REGION_ORDER.index(r) if r in REGION_ORDER else len(REGION_ORDER)
    )
    stage_peak_diagnostics = stage_peak_diagnostics.sort_values(["stage_order", "region_order"]).drop(
        columns=["stage_order", "region_order"]
    )

    packet = stage_peak_diagnostics[stage_peak_diagnostics["region"].isin(["packet", "packet_support"])].copy()
    packet["accounting_bucket"] = np.where(packet["packet_live_accounting"], "live_packet", "reset_removed")

    all_region = stage_peak_diagnostics[stage_peak_diagnostics["region"] == "all"].copy()
    support = stage_peak_diagnostics[stage_peak_diagnostics["region"].isin(["support_edge", "outer_shoulder"])]

    rows = []
    for stage in STAGE_ORDER:
        prow = packet[packet["stage"] == stage]
        arow = all_region[all_region["stage"] == stage]
        srow = support[support["stage"] == stage]
        if prow.empty and arow.empty and srow.empty:
            continue
        row = {"stage": stage, "packet_live_accounting": stage in live}
        for chcol in peak_cols:
            row[f"packet_{chcol}"] = float(prow[chcol].max()) if not prow.empty else float("nan")
            row[f"all_{chcol}"] = float(arow[chcol].max()) if not arow.empty else float("nan")
            row[f"support_shell_{chcol}"] = float(srow[chcol].max()) if not srow.empty else float("nan")
        rows.append(row)
    lifecycle_rollup = pd.DataFrame(rows)

    removed = packet[~packet["packet_live_accounting"]]
    live_packet = packet[packet["packet_live_accounting"]]
    comparison_rows = []
    for chcol in peak_cols:
        live_peak = float(live_packet[chcol].max()) if not live_packet.empty else float("nan")
        removed_peak = float(removed[chcol].max()) if not removed.empty else float("nan")
        all_packet_peak = float(packet[chcol].max()) if not packet.empty else float("nan")
        comparison_rows.append(
            {
                "channel": chcol.replace("_peak_badness", ""),
                "live_packet_peak": live_peak,
                "reset_removed_peak": removed_peak,
                "geometric_packet_peak": all_packet_peak,
                "live_over_geometric_peak": safe_fraction(live_peak, all_packet_peak),
                "reset_removed_over_geometric_peak": safe_fraction(removed_peak, all_packet_peak),
            }
        )
    live_vs_reset = pd.DataFrame(comparison_rows)
    return {
        "stage_peak_diagnostics": stage_peak_diagnostics,
        "lifecycle_rollup": lifecycle_rollup,
        "live_vs_reset_peak_comparison": live_vs_reset,
    }


def tradeoff_readthrough(path: Optional[Path]) -> Optional[pd.DataFrame]:
    if path is None or not path.exists():
        return None
    df = pd.read_csv(path)
    required = {"candidate", "max_live_Tkk_fraction", "max_live_radial_pressure_fraction", "mean_total_Tkk_burden"}
    if not required.issubset(df.columns):
        return df
    freeze = df[df["candidate"] == "freeze"]
    if not freeze.empty:
        f = freeze.iloc[0]
        df = df.copy()
        df["Tkk_fraction_cut_vs_freeze"] = f["max_live_Tkk_fraction"] - df["max_live_Tkk_fraction"]
        df["radial_pressure_fraction_cut_vs_freeze"] = (
            f["max_live_radial_pressure_fraction"] - df["max_live_radial_pressure_fraction"]
        )
        df["Tkk_burden_ratio_vs_freeze"] = df["mean_total_Tkk_burden"] / f["mean_total_Tkk_burden"]
    return df.sort_values("max_score_lower_better" if "max_score_lower_better" in df.columns else "candidate")


def write_report(out_dir: Path, mode: str, params: LifecycleParams, outputs: Dict[str, pd.DataFrame], tradeoff: Optional[pd.DataFrame], case: Optional[str]) -> None:
    lines = []
    lines.append("# Active Rail Lifecycle Ledger Report")
    lines.append("")
    lines.append(f"Mode: `{mode}`")
    if case:
        lines.append(f"Case: `{case}`")
    lines.append("")
    lines.append("## Lifecycle accounting")
    lines.append("")
    lines.append("Passenger exposure is counted through the live packet stages and stops before decompression/reset unless `count_reset_as_packet_exposure` is enabled.")
    lines.append("")
    lines.append("```json")
    lines.append(json.dumps(asdict(params), indent=2))
    lines.append("```")
    lines.append("")

    if "lifecycle_rollup" in outputs:
        lines.append("## Lifecycle rollup")
        lines.append("")
        lines.append(outputs["lifecycle_rollup"].round(6).to_markdown(index=False))
        lines.append("")
    if "live_vs_reset_peak_comparison" in outputs:
        lines.append("## Live packet vs reset-removed peak comparison")
        lines.append("")
        lines.append(outputs["live_vs_reset_peak_comparison"].round(6).to_markdown(index=False))
        lines.append("")
    if "point_global" in outputs:
        lines.append("## Point-ledger global summary")
        lines.append("")
        lines.append(outputs["point_global"].round(6).to_markdown(index=False))
        lines.append("")
    if tradeoff is not None:
        lines.append("## Candidate tradeoff readthrough")
        lines.append("")
        keep = [c for c in [
            "candidate",
            "max_score_lower_better",
            "max_live_Tkk_fraction",
            "Tkk_fraction_cut_vs_freeze",
            "max_live_radial_pressure_fraction",
            "radial_pressure_fraction_cut_vs_freeze",
            "mean_total_Tkk_burden",
            "Tkk_burden_ratio_vs_freeze",
            "mean_total_pOmega_burden",
            "worst_packet_norm",
        ] if c in tradeoff.columns]
        lines.append(tradeoff[keep].round(6).to_markdown(index=False))
        lines.append("")

    lines.append("## Caveat")
    lines.append("")
    if mode == "region_phase":
        lines.append("This run used region/phase peaks, not the missing point-level tensor ledger. Treat it as a lifecycle-resolved peak diagnostic, not a volume-integrated exposure proof.")
    else:
        lines.append("This run used point-level data and can support volume-weighted exposure fractions, subject to the quality of the point ledger.")
    (out_dir / "LIFECYCLE_LEDGER_REPORT.md").write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--point-ledger", type=Path, default=None)
    ap.add_argument("--region-phase-ledger", type=Path, default=None)
    ap.add_argument("--candidate-tradeoff", type=Path, default=None)
    ap.add_argument("--search-dir", action="append", type=Path, default=[])
    ap.add_argument("--case", default="soft_minjerk_q_t0m04_Tr30")
    ap.add_argument("--out-dir", type=Path, default=Path("active_rail_lifecycle_ledger_report"))

    ap.add_argument("--Rpass", type=float, default=0.35)
    ap.add_argument("--Rth", type=float, default=1.75)
    ap.add_argument("--packet-center-mode", choices=["diagonal", "zero"], default="diagonal")
    ap.add_argument("--exclude-entry", action="store_true")
    ap.add_argument("--exclude-release", action="store_true")
    ap.add_argument("--count-reset-as-packet-exposure", action="store_true")
    args = ap.parse_args()

    params = LifecycleParams(
        Rpass=args.Rpass,
        Rth=args.Rth,
        packet_center_mode=args.packet_center_mode,
        include_entry_as_live=not args.exclude_entry,
        include_release_as_live=not args.exclude_release,
        count_reset_as_packet_exposure=args.count_reset_as_packet_exposure,
    )

    search_dirs = args.search_dir or DEFAULT_SEARCH_DIRS
    point_path = args.point_ledger or find_file(search_dirs, POINT_FILE_CANDIDATES)
    phase_path = args.region_phase_ledger or find_file(search_dirs, REGION_PHASE_CANDIDATES)
    tradeoff_path = args.candidate_tradeoff or find_file(search_dirs, TRADEOFF_CANDIDATES)

    out_dir = args.out_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    if point_path is not None and point_path.exists():
        mode = "point_ledger"
        df = pd.read_csv(point_path)
        df = add_point_lifecycle_columns(df, params)
        df.to_csv(out_dir / "lifecycle_points_with_masks.csv", index=False)
        outputs = summarize_points(df)
    elif phase_path is not None and phase_path.exists():
        mode = "region_phase"
        df = pd.read_csv(phase_path)
        outputs = summarize_region_phase(df, args.case, params)
    else:
        raise SystemExit(
            "No point ledger or region_phase_ledger.csv found. Pass --point-ledger or --region-phase-ledger."
        )

    for name, table in outputs.items():
        table.to_csv(out_dir / f"{name}.csv", index=False)

    tradeoff = tradeoff_readthrough(tradeoff_path)
    if tradeoff is not None:
        tradeoff.to_csv(out_dir / "candidate_tradeoff_readthrough.csv", index=False)

    manifest = {
        "mode": mode,
        "point_ledger": str(point_path) if point_path else None,
        "region_phase_ledger": str(phase_path) if phase_path else None,
        "candidate_tradeoff": str(tradeoff_path) if tradeoff_path else None,
        "case": args.case if mode == "region_phase" else None,
        "params": asdict(params),
        "outputs": sorted(p.name for p in out_dir.iterdir()),
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    write_report(out_dir, mode, params, outputs, tradeoff, args.case if mode == "region_phase" else None)
    print(f"[{mode}] wrote {out_dir}")


if __name__ == "__main__":
    main()
