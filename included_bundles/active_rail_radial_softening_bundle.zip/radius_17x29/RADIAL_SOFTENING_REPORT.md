# Radial-Pressure Softening Probe

Prescribed-geometry point-level source diagnostic. This is a design-screening ledger, not a matter model or constraint solve.

Grid: `17 x 29` per case.

## Cases

| case        |   Rth |   w_th | w_th_inner   | w_th_outer   |   w_pass |   ROmega |   x_beta_catch |   x_packet_catch | note                                                                                      |
|:------------|------:|-------:|:-------------|:-------------|---------:|---------:|---------------:|-----------------:|:------------------------------------------------------------------------------------------|
| shaped_base |  1.75 |   0.35 |              |              |     0.06 |     1.75 |          -0.05 |                0 | R1.75 locked-lead shaped catch baseline: beta catch leads by 0.05; packet follows tightly |
| Rth_1.80    |  1.8  |   0.35 |              |              |     0.06 |     1.8  |          -0.05 |                0 | move support/quarantine shell outward to 1.80                                             |
| Rth_1.85    |  1.85 |   0.35 |              |              |     0.06 |     1.85 |          -0.05 |                0 | move support/quarantine shell outward to 1.85                                             |
| Rth_1.90    |  1.9  |   0.35 |              |              |     0.06 |     1.9  |          -0.05 |                0 | move support/quarantine shell outward to 1.90                                             |
| Rth_2.00    |  2    |   0.35 |              |              |     0.06 |     2    |          -0.05 |                0 | move support/quarantine shell outward to 2.00                                             |

## Decision table

| case        |   score |   pl_live_ratio |   tkk_live_ratio |   pl_peak_ratio |   tkk_peak_ratio |   infra_pressure_ratio |   max_packet_norm_live |   positive_packet_norm_live |   live_packet_fraction__abs_p_l |   live_packet_fraction__neg_Tkk_radial |   live_packet_burden__abs_p_l |   live_packet_burden__neg_Tkk_radial |
|:------------|--------:|----------------:|-----------------:|----------------:|-----------------:|-----------------------:|-----------------------:|----------------------------:|--------------------------------:|---------------------------------------:|------------------------------:|-------------------------------------:|
| shaped_base |   1     |           1     |            1     |          1      |           1      |                  1     |                 -783.8 |                           0 |                          0.2492 |                                 0.2314 |                         18    |                                101.8 |
| Rth_1.80    |   1.013 |           1.007 |            1.008 |          0.9195 |           0.956  |                  1.04  |                 -851.6 |                           0 |                          0.2411 |                                 0.2239 |                         18.12 |                                102.6 |
| Rth_1.85    |   1.026 |           1.013 |            1.016 |          0.8274 |           0.9151 |                  1.081 |                 -911.3 |                           0 |                          0.2334 |                                 0.2168 |                         18.22 |                                103.4 |
| Rth_1.90    |   1.037 |           1.018 |            1.023 |          0.868  |           0.8771 |                  1.121 |                 -963.3 |                           0 |                          0.2262 |                                 0.2101 |                         18.31 |                                104.1 |
| Rth_2.00    |   1.056 |           1.026 |            1.035 |          0.7764 |           0.8085 |                  1.201 |                -1046   |                           0 |                          0.2128 |                                 0.1975 |                         18.46 |                                105.3 |

## Stage live burden for radial channels

### abs_p_l

| case        |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| Rth_1.80    |                0 |           16.41 |            0 |                1.707 |                     0 |                     0 |
| Rth_1.85    |                0 |           16.49 |            0 |                1.728 |                     0 |                     0 |
| Rth_1.90    |                0 |           16.57 |            0 |                1.746 |                     0 |                     0 |
| Rth_2.00    |                0 |           16.68 |            0 |                1.775 |                     0 |                     0 |
| shaped_base |                0 |           16.31 |            0 |                1.682 |                     0 |                     0 |

### neg_Tkk_radial

| case        |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| Rth_1.80    |                0 |           89.41 |            0 |                13.24 |                     0 |                     0 |
| Rth_1.85    |                0 |           90.07 |            0 |                13.35 |                     0 |                     0 |
| Rth_1.90    |                0 |           90.68 |            0 |                13.44 |                     0 |                     0 |
| Rth_2.00    |                0 |           91.76 |            0 |                13.55 |                     0 |                     0 |
| shaped_base |                0 |           88.69 |            0 |                13.1  |                     0 |                     0 |

## Safety table

| case        |   live_points |   max_packet_norm_live |   min_packet_norm_live |   positive_packet_norm_live |
|:------------|--------------:|-----------------------:|-----------------------:|----------------------------:|
| Rth_1.80    |            42 |               -851.572 |                -328466 |                           0 |
| Rth_1.85    |            42 |               -911.347 |                -332371 |                           0 |
| Rth_1.90    |            42 |               -963.346 |                -338727 |                           0 |
| Rth_2.00    |            42 |              -1046.34  |                -348935 |                           0 |
| shaped_base |            42 |               -783.78  |                -324034 |                           0 |
