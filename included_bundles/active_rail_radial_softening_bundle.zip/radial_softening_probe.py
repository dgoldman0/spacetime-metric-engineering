#!/usr/bin/env python3
"""Radial-pressure softening probe for shaped-catch active rail candidates.

This is a point-level prescribed-geometry Einstein-source diagnostic:
T_munu^demand = G_munu[g]/(8*pi). It is not a matter model or constraint solve.

The script starts from the R1.75 locked-lead shaped catch branch and varies
radial support width, packet transition width, support radius, and optional
inner/outer support asymmetry.
"""
from __future__ import annotations

import argparse, json, math, zipfile
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

PI8 = 8.0 * math.pi
THETA0 = math.pi / 2.0

@dataclass(frozen=True)
class Params:
    # transport/service
    V: float = 10.0
    v_exit: float = 0.5
    p_beta: float = 4.0
    Rpass: float = 0.35

    # shaped catch split: beta/support side can lead, packet rematch follows
    x_catch_beta: float = -0.05
    w_catch_beta: float = 0.32
    x_catch_packet: float = 0.00
    w_catch_packet: float = 0.32
    catch_profile: str = "minjerk"

    # support sector
    C0: float = 100.0
    lam: float = 6.0
    B0: float = 8.0
    eta_N: float = 1.0
    Rth: float = 1.75
    w_th: float = 0.35
    w_th_inner: float | None = None  # if set, use asymmetric support width
    w_th_outer: float | None = None
    w_pass: float = 0.06
    eps: float = 1e-5

    # release and decompression
    x_beta: float = 0.70
    w_beta: float = 0.18
    q_t0: float = -0.40
    q_Tr: float = 3.00

    # angular jacket
    aOmega: float = 0.20
    ROmega: float = 1.75
    wOmega: float = 1.40
    xOmega: float = 2.00
    wtOmega: float = 0.60

    # lifecycle accounting
    live_packet_end_margin_widths: float = 2.0

@dataclass(frozen=True)
class CaseDef:
    name: str
    params: Params
    note: str

CHANNELS = {
    "neg_Tkk_radial": "negative radial null contraction",
    "abs_p_l": "radial pressure magnitude",
    "abs_pOmega": "angular pressure magnitude",
    "abs_j_l": "radial current magnitude",
    "neg_rho_euler": "negative Eulerian density",
    "neg_rho_packet": "negative packet-comoving density",
}
STAGE_ORDER = ["entry_precatch","catch_rematch","held_carry","release_shift_fade","post_release_buffer","reset_decompression"]

def smoothstep_minjerk(t):
    x = np.clip(np.asarray(t, dtype=float), 0.0, 1.0)
    return 10*x**3 - 15*x**4 + 6*x**5

def minjerk_down_window(s, x, w):
    # transition centered at x, spanning x-2w to x+2w
    t = (np.asarray(s, dtype=float) - (x - 2*w)) / max(4*w, 1e-12)
    return 1.0 - smoothstep_minjerk(t)

def falloff(z, w):
    return 0.5 * (1.0 - np.tanh(np.asarray(z, dtype=float) / w))

def catch_factor(s, x, w, profile="minjerk"):
    if profile == "tanh":
        return falloff(np.asarray(s, dtype=float) - x, w)
    if profile == "minjerk":
        return minjerk_down_window(s, x, w)
    raise ValueError(profile)

def minjerk_down(s, t0, Tr):
    t = (np.asarray(s, dtype=float) - t0) / max(Tr, 1e-12)
    return 1.0 - smoothstep_minjerk(t)

def bump_sq(x2, R, w):
    z = (np.asarray(x2, dtype=float) - R*R) / max(2*R*w, 1e-12)
    return 0.5 * (1.0 - np.tanh(z))

def support_bump(l, p: Params):
    l_arr = np.asarray(l, dtype=float)
    if p.w_th_inner is None or p.w_th_outer is None:
        return bump_sq(l_arr*l_arr, p.Rth, p.w_th)
    # Smooth asymmetric approximation: broader inner/packet-facing side near |l| < Rth,
    # sharper/stronger outer falloff near |l| > Rth. This tests radial wall placement.
    al = np.abs(l_arr)
    w = np.where(al <= p.Rth, p.w_th_inner, p.w_th_outer)
    return bump_sq(l_arr*l_arr, p.Rth, w)

def scalars(s: float, l: float, p: Params) -> Dict[str, float]:
    s_arr = np.asarray(s, dtype=float)
    l_arr = np.asarray(l, dtype=float)

    Cb = catch_factor(s_arr, p.x_catch_beta, p.w_catch_beta, p.catch_profile)
    Cp = catch_factor(s_arr, p.x_catch_packet, p.w_catch_packet, p.catch_profile)
    U_beta = p.v_exit + (p.V - p.v_exit) * Cb
    U_packet = p.v_exit + (p.V - p.v_exit) * Cp

    E = falloff(s_arr - p.x_beta, p.w_beta)
    q = minjerk_down(s_arr, p.q_t0, p.q_Tr)
    W = support_bump(l_arr, p)
    S = bump_sq((l_arr - s_arr)**2 + p.eps*p.eps, p.Rpass, p.w_pass)

    A = np.exp(q * W * math.log(p.C0))
    T = np.exp(q * W * math.log(p.lam * p.C0))
    B = 1.0 + (p.B0 - 1.0) * W * q
    shoulder = np.exp(-((np.abs(l_arr) - 1.05) / 0.35) ** 2)
    N = np.exp(p.eta_N * 0.18 * q * shoulder)

    Wpower = W ** p.p_beta
    beta = -U_beta * E * Wpower * S / B
    alpha = N * T
    sqrt_gamma_ll = B * A
    gamma_ll = sqrt_gamma_ll * sqrt_gamma_ll
    vcoord = U_packet / B
    gtt = -alpha*alpha + gamma_ll * beta*beta
    packet_norm = -alpha*alpha + gamma_ll * (vcoord + beta)**2

    WOmega = bump_sq(l_arr*l_arr, p.ROmega, p.wOmega)
    QOmega = falloff(s_arr - p.xOmega, p.wtOmega)
    COmega = np.exp(p.aOmega * QOmega * WOmega)
    gamma_omega = (l_arr*l_arr + p.Rth*p.Rth) * COmega*COmega

    return {"U_beta":float(U_beta),"U_packet":float(U_packet),"E":float(E),"q":float(q),"W":float(W),"S":float(S),
            "A":float(A),"T":float(T),"B":float(B),"N":float(N),"beta":float(beta),"alpha":float(alpha),
            "sqrt_gamma_ll":float(sqrt_gamma_ll),"gamma_ll":float(gamma_ll),"vcoord":float(vcoord),"gtt":float(gtt),
            "packet_norm":float(packet_norm),"WOmega":float(WOmega),"QOmega":float(QOmega),"COmega":float(COmega),
            "gamma_omega":float(gamma_omega)}

def metric_at(x: np.ndarray, p: Params) -> np.ndarray:
    s, l, theta, _phi = [float(z) for z in x]
    sc = scalars(s,l,p)
    g = np.zeros((4,4), dtype=float)
    g[0,0] = -sc["alpha"]**2 + sc["gamma_ll"] * sc["beta"]**2
    g[0,1] = g[1,0] = sc["gamma_ll"] * sc["beta"]
    g[1,1] = sc["gamma_ll"]
    g[2,2] = sc["gamma_omega"]
    g[3,3] = sc["gamma_omega"] * math.sin(theta)**2
    return g

def metric_derivative(x, coord, h, p):
    if coord == 3:
        return np.zeros((4,4), dtype=float)
    xp=x.copy(); xm=x.copy(); xp[coord]+=h[coord]; xm[coord]-=h[coord]
    return (metric_at(xp,p)-metric_at(xm,p))/(2*h[coord])

def christoffel_at(x, h, p):
    g=metric_at(x,p); invg=np.linalg.inv(g); dg=[metric_derivative(x,a,h,p) for a in range(4)]
    Gamma=np.zeros((4,4,4), dtype=float)
    for rho in range(4):
        for mu in range(4):
            for nu in range(4):
                total=0.0
                for sig in range(4):
                    total += invg[rho,sig]*(dg[mu][nu,sig]+dg[nu][mu,sig]-dg[sig][mu,nu])
                Gamma[rho,mu,nu]=0.5*total
    return Gamma

def christoffel_derivative(x, coord, h, p):
    if coord == 3:
        return np.zeros((4,4,4), dtype=float)
    xp=x.copy(); xm=x.copy(); xp[coord]+=h[coord]; xm[coord]-=h[coord]
    return (christoffel_at(xp,h,p)-christoffel_at(xm,h,p))/(2*h[coord])

def einstein_tensor_at(s, l, p, h_s, h_l, h_theta=1e-4):
    x=np.array([s,l,THETA0,0.0], dtype=float)
    h=np.array([h_s,h_l,h_theta,1.0], dtype=float)
    g=metric_at(x,p); invg=np.linalg.inv(g); Gamma=christoffel_at(x,h,p); dGamma=[christoffel_derivative(x,a,h,p) for a in range(4)]
    Ric=np.zeros((4,4), dtype=float)
    for mu in range(4):
        for nu in range(4):
            term1=sum(dGamma[rho][rho,mu,nu] for rho in range(4))
            term2=sum(dGamma[nu][rho,mu,rho] for rho in range(4))
            term3=0.0; term4=0.0
            for rho in range(4):
                trace=sum(Gamma[sig,rho,sig] for sig in range(4))
                term3 += Gamma[rho,mu,nu]*trace
                for sig in range(4):
                    term4 += Gamma[sig,mu,rho]*Gamma[rho,nu,sig]
            Ric[mu,nu]=term1-term2+term3-term4
    R=float(np.einsum("ab,ab->", invg, Ric))
    G=Ric-0.5*g*R
    return G,{"ricci_scalar":R,"cond_metric":float(np.linalg.cond(g))}

def projections(s,l,G,p):
    sc=scalars(s,l,p); alpha=sc["alpha"]; beta=sc["beta"]; gamma_ll=sc["gamma_ll"]; sqrtll=math.sqrt(gamma_ll); goo=sc["gamma_omega"]
    T=G/PI8
    n=np.array([1/alpha, -beta/alpha, 0,0], dtype=float)
    e_l=np.array([0,1/sqrtll,0,0], dtype=float)
    e_th=np.array([0,0,1/math.sqrt(goo),0], dtype=float)
    e_ph=np.array([0,0,0,1/math.sqrt(goo)], dtype=float)
    rho=float(n@T@n); j=float(-e_l@T@n); p_l=float(e_l@T@e_l); p_om=0.5*float(e_th@T@e_th+e_ph@T@e_ph)
    u_raw=np.array([1,sc["vcoord"],0,0], dtype=float); norm=sc["packet_norm"]
    rho_pkt=float("nan")
    if norm < 0:
        u=u_raw/math.sqrt(-norm); rho_pkt=float(u@T@u)
    k_plus=np.array([1, -beta + alpha/sqrtll,0,0], dtype=float)
    k_minus=np.array([1, -beta - alpha/sqrtll,0,0], dtype=float)
    Tkkp=float(k_plus@T@k_plus); Tkkm=float(k_minus@T@k_minus)
    return {"rho_euler":rho,"j_l_unit":j,"p_l_unit":p_l,"p_omega_unit":p_om,"rho_packet":rho_pkt,
            "Tkk_plus":Tkkp,"Tkk_minus":Tkkm,"Tkk_min_radial":min(Tkkp,Tkkm),"packet_norm":norm,"gtt":sc["gtt"],
            "spatial_volume_density":sqrtll*goo, **{k:sc[k] for k in ["W","S","q","E","U_beta","U_packet","B","A","T","alpha","beta","gamma_ll","gamma_omega","COmega"]}}

def stage_name(s,p):
    xc=p.x_catch_packet; wc=max(p.w_catch_packet,p.w_catch_beta)
    if s < xc - 2*wc: return "entry_precatch"
    if abs(s-xc) <= 2*wc: return "catch_rematch"
    if xc + 2*wc < s < p.x_beta - 2*p.w_beta: return "held_carry"
    if abs(s-p.x_beta) <= 2*p.w_beta: return "release_shift_fade"
    if p.x_beta + 2*p.w_beta < s < p.x_beta + 4*p.w_beta: return "post_release_buffer"
    return "reset_decompression"

def region_name(s,l,p):
    al=abs(l)
    if abs(l-s) <= p.Rpass:
        return "packet_in_support" if al <= p.Rth else "packet_outer"
    if al <= 0.65*p.Rth: return "core_throat"
    if al <= 1.20*p.Rth: return "support_edge"
    if al <= 1.85*p.Rth: return "outer_quarantine_shell"
    return "far_exterior"

def live_packet_mask(s,l,p):
    return bool(abs(l-s) <= p.Rpass and s <= p.x_beta + p.live_packet_end_margin_widths*p.w_beta)

def channel_badness(row,ch):
    if ch=="neg_Tkk_radial": return max(-float(row["Tkk_min_radial"]),0.0)
    if ch=="abs_p_l": return abs(float(row["p_l_unit"]))
    if ch=="abs_pOmega": return abs(float(row["p_omega_unit"]))
    if ch=="abs_j_l": return abs(float(row["j_l_unit"]))
    if ch=="neg_rho_euler": return max(-float(row["rho_euler"]),0.0)
    if ch=="neg_rho_packet":
        z=float(row["rho_packet"]); return max(-z,0.0) if math.isfinite(z) else 0.0
    raise KeyError(ch)

def compute_case(case, ns,nl,s_min,s_max,l_min,l_max,h_s,h_l, progress=True):
    p=case.params; s_grid=np.linspace(s_min,s_max,ns); l_grid=np.linspace(l_min,l_max,nl)
    ds=(s_max-s_min)/max(ns-1,1); dl=(l_max-l_min)/max(nl-1,1)
    rows=[]; total=ns*nl; k=0
    for si,s in enumerate(s_grid):
        for l in l_grid:
            k+=1
            base={"case":case.name,"s":float(s),"l":float(l),"stage":stage_name(float(s),p),"region":region_name(float(s),float(l),p),
                  "inside_packet_geom":abs(float(l)-float(s))<=p.Rpass,"inside_packet_live":live_packet_mask(float(s),float(l),p),"cell_area":ds*dl}
            try:
                G,diag=einstein_tensor_at(float(s),float(l),p,h_s,h_l); proj=projections(float(s),float(l),G,p)
                row={**base,**proj,**diag}; row["point_weight"]=1.0; row["volume_weight"]=float(proj["spatial_volume_density"]*ds*dl)
                for ch in CHANNELS:
                    bad=channel_badness(row,ch); row[f"bad_{ch}"]=bad; row[f"volume_burden_{ch}"]=bad*row["volume_weight"]; row[f"point_burden_{ch}"]=bad
                rows.append(row)
            except Exception as exc:
                rows.append({**base,"error":repr(exc)})
        if progress and (si+1==ns or (si+1)%max(1,ns//5)==0):
            print(f"{case.name}: row {si+1}/{ns}", flush=True)
    return pd.DataFrame(rows)

def summarize(points):
    ok=points[points.get("error", pd.Series(index=points.index,dtype=object)).isna()].copy() if "error" in points.columns else points.copy()
    long=[]
    for scope,cols in [("global",["case"]),("stage",["case","stage"]),("region",["case","region"]),("stage_region",["case","stage","region"])]:
        for key,g in ok.groupby(cols, dropna=False):
            if not isinstance(key,tuple): key=(key,)
            base={"scope":scope, **{c:v for c,v in zip(cols,key)}, "points":len(g)}
            live=g["inside_packet_live"].astype(bool).to_numpy(); geom=g["inside_packet_geom"].astype(bool).to_numpy()
            for ch,desc in CHANNELS.items():
                for weight in ["point","volume"]:
                    vals=g[f"{weight}_burden_{ch}"].astype(float).to_numpy(); total=float(np.nansum(vals)); live_b=float(np.nansum(vals[live])); geom_b=float(np.nansum(vals[geom]))
                    long.append({**base,"channel":ch,"description":desc,"weight":weight,"total_burden":total,"live_packet_burden":live_b,
                                 "geometric_packet_burden":geom_b,"live_packet_fraction":live_b/total if total>0 else float("nan"),
                                 "geometric_packet_fraction":geom_b/total if total>0 else float("nan"),
                                 "point_peak":float(g[f"bad_{ch}"].astype(float).max()),
                                 "live_packet_point_peak":float(g.loc[g["inside_packet_live"].astype(bool),f"bad_{ch}"].astype(float).max()) if live.any() else 0.0})
    summary=pd.DataFrame(long)
    compact=summary[(summary.scope=="global")&(summary.weight=="volume")][["case","channel","description","total_burden","live_packet_burden","live_packet_fraction","point_peak","live_packet_point_peak"]].copy()
    stage=summary[(summary.scope=="stage")&(summary.weight=="volume")].copy()
    stage["stage"]=pd.Categorical(stage["stage"], categories=STAGE_ORDER, ordered=True); stage=stage.sort_values(["case","channel","stage"])
    # case-level safety
    safety=[]
    for case,g in ok.groupby("case"):
        live=g[g["inside_packet_live"].astype(bool)]
        safety.append({"case":case,"live_points":len(live),"max_packet_norm_live":float(live.packet_norm.astype(float).max()) if len(live) else float("nan"),
                       "min_packet_norm_live":float(live.packet_norm.astype(float).min()) if len(live) else float("nan"),
                       "positive_packet_norm_live":int((live.packet_norm.astype(float)>0).sum()) if len(live) else 0})
    safety=pd.DataFrame(safety)
    decision=build_decision_table(compact, safety)
    return summary, compact, stage, safety, decision

def build_decision_table(compact, safety):
    rows=[]
    piv={}
    for case,g in compact.groupby("case"):
        row={"case":case}
        for _,r in g.iterrows():
            ch=r["channel"]
            for k in ["total_burden","live_packet_burden","live_packet_fraction","point_peak","live_packet_point_peak"]:
                row[f"{k}__{ch}"]=float(r[k])
        piv[case]=row
    base=piv.get("shaped_base") or next(iter(piv.values()))
    for case,row in piv.items():
        b=lambda key: base.get(key,float("nan"))
        for ch in ["neg_Tkk_radial","abs_p_l","abs_pOmega","abs_j_l"]:
            for k in ["live_packet_burden","total_burden","live_packet_fraction","point_peak","live_packet_point_peak"]:
                key=f"{k}__{ch}"; den=b(key); row[f"{key}_ratio_vs_base"]=(row.get(key,float("nan"))/den if den and math.isfinite(den) else float("nan"))
        rows.append(row)
    dec=pd.DataFrame(rows).merge(safety, on="case", how="left")
    # Score: p_l first, keep Tkk not worse, penalize unsafe and global peaks/infrastructure growth
    dec["unsafe_penalty"]=(dec["positive_packet_norm_live"]>0).astype(float)*10.0
    dec["pl_live_ratio"] = dec["live_packet_burden__abs_p_l_ratio_vs_base"]
    dec["tkk_live_ratio"] = dec["live_packet_burden__neg_Tkk_radial_ratio_vs_base"]
    dec["pl_peak_ratio"] = dec["point_peak__abs_p_l_ratio_vs_base"]
    dec["tkk_peak_ratio"] = dec["point_peak__neg_Tkk_radial_ratio_vs_base"]
    dec["infra_pressure_ratio"] = dec["total_burden__abs_p_l_ratio_vs_base"]
    dec["score"] = dec["pl_live_ratio"] + 0.30*np.maximum(dec["tkk_live_ratio"]-1.0,0) + 0.20*np.maximum(dec["pl_peak_ratio"]-1.0,0) + 0.10*np.maximum(dec["infra_pressure_ratio"]-1.0,0) + dec["unsafe_penalty"]
    return dec.sort_values("score")

def make_cases(group="screen"):
    base=Params()
    cases=[CaseDef("shaped_base", base, "R1.75 locked-lead shaped catch baseline: beta catch leads by 0.05; packet follows tightly")]
    if group in ["screen","radial"]:
        for w in [0.40,0.45,0.50,0.55]:
            cases.append(CaseDef(f"wth_{w:.2f}", replace(base,w_th=w), f"widen radial support edge to {w:.2f}"))
    if group in ["screen","packet"]:
        for wp in [0.08,0.10,0.12]:
            cases.append(CaseDef(f"wpass_{wp:.2f}", replace(base,w_pass=wp), f"soften packet/support transition to {wp:.2f}"))
    if group in ["screen","radius"]:
        for R in [1.80,1.85,1.90,2.00]:
            cases.append(CaseDef(f"Rth_{R:.2f}", replace(base,Rth=R,ROmega=R), f"move support/quarantine shell outward to {R:.2f}"))
    if group in ["screen","asym"]:
        cases.append(CaseDef("asym_inner45_outer30", replace(base,w_th_inner=0.45,w_th_outer=0.30), "soft inner shoulder, firmer outer falloff"))
        cases.append(CaseDef("asym_inner50_outer30", replace(base,w_th_inner=0.50,w_th_outer=0.30), "softer inner shoulder, firmer outer falloff"))
        cases.append(CaseDef("asym_inner45_outer25", replace(base,w_th_inner=0.45,w_th_outer=0.25), "soft inner shoulder, sharp outer falloff"))
    if group == "combined":
        cases += [
            CaseDef("wth45_wpass08", replace(base,w_th=0.45,w_pass=0.08), "wider support plus slightly softer packet transition"),
            CaseDef("wth50_wpass08", replace(base,w_th=0.50,w_pass=0.08), "wider support plus slightly softer packet transition"),
            CaseDef("R185_wth45", replace(base,Rth=1.85,ROmega=1.85,w_th=0.45), "moderately outward and wider support"),
            CaseDef("R180_wth45_wpass08", replace(base,Rth=1.80,ROmega=1.80,w_th=0.45,w_pass=0.08), "moderately outward, wider support, soft packet transition"),
            CaseDef("asym_inner45_outer30_wpass08", replace(base,w_th_inner=0.45,w_th_outer=0.30,w_pass=0.08), "asymmetric radial shoulder plus soft packet transition"),
        ]
    return cases

def write_report(outdir, cases, compact, stage, safety, decision, ns,nl, title):
    lines=[f"# {title}","", "Prescribed-geometry point-level source diagnostic. This is a design-screening ledger, not a matter model or constraint solve.","", f"Grid: `{ns} x {nl}` per case.","", "## Cases",""]
    case_rows=[]
    for c in cases:
        p=c.params
        case_rows.append({"case":c.name,"Rth":p.Rth,"w_th":p.w_th,"w_th_inner":p.w_th_inner,"w_th_outer":p.w_th_outer,"w_pass":p.w_pass,"ROmega":p.ROmega,"x_beta_catch":p.x_catch_beta,"x_packet_catch":p.x_catch_packet,"note":c.note})
    lines.append(pd.DataFrame(case_rows).to_markdown(index=False)); lines.append("")
    lines.append("## Decision table"); lines.append("")
    show_cols=["case","score","pl_live_ratio","tkk_live_ratio","pl_peak_ratio","tkk_peak_ratio","infra_pressure_ratio","max_packet_norm_live","positive_packet_norm_live",
               "live_packet_fraction__abs_p_l","live_packet_fraction__neg_Tkk_radial","live_packet_burden__abs_p_l","live_packet_burden__neg_Tkk_radial"]
    show=decision[[c for c in show_cols if c in decision.columns]].copy()
    for col in show.columns:
        if col != "case":
            show[col]=show[col].map(lambda x: f"{x:.4g}" if pd.notna(x) else "nan")
    lines.append(show.to_markdown(index=False)); lines.append("")
    lines.append("## Stage live burden for radial channels"); lines.append("")
    for ch in ["abs_p_l","neg_Tkk_radial"]:
        lines.append(f"### {ch}"); lines.append("")
        tab=stage[stage.channel==ch].pivot_table(index="case",columns="stage",values="live_packet_burden",aggfunc="sum").reindex(columns=STAGE_ORDER).fillna(0)
        lines.append(tab.map(lambda x: f"{x:.4g}").to_markdown()); lines.append("")
    lines.append("## Safety table"); lines.append(""); lines.append(safety.to_markdown(index=False)); lines.append("")
    return "\n".join(lines)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--group", default="screen", choices=["screen","radial","packet","radius","asym","combined"])
    ap.add_argument("--ns", type=int, default=25); ap.add_argument("--nl", type=int, default=41)
    ap.add_argument("--s-min", type=float, default=-0.35); ap.add_argument("--s-max", type=float, default=1.65)
    ap.add_argument("--l-min", type=float, default=-2.80); ap.add_argument("--l-max", type=float, default=2.80)
    ap.add_argument("--h-s", type=float, default=2.5e-3); ap.add_argument("--h-l", type=float, default=2.5e-3)
    ap.add_argument("--outdir", type=Path, required=True); ap.add_argument("--quiet", action="store_true")
    args=ap.parse_args(); args.outdir.mkdir(parents=True, exist_ok=True)
    cases=make_cases(args.group); frames=[]
    for c in cases:
        print(f"Running {c.name}", flush=True)
        frames.append(compute_case(c,args.ns,args.nl,args.s_min,args.s_max,args.l_min,args.l_max,args.h_s,args.h_l, progress=not args.quiet))
    points=pd.concat(frames, ignore_index=True)
    points.to_csv(args.outdir/"radial_softening_point_ledger.csv", index=False)
    summary,compact,stage,safety,decision=summarize(points)
    summary.to_csv(args.outdir/"radial_softening_summary_long.csv", index=False)
    compact.to_csv(args.outdir/"radial_softening_global_compact.csv", index=False)
    stage.to_csv(args.outdir/"radial_softening_stage_summary.csv", index=False)
    safety.to_csv(args.outdir/"radial_softening_safety.csv", index=False)
    decision.to_csv(args.outdir/"radial_softening_decision_table.csv", index=False)
    meta={"grid":{"ns":args.ns,"nl":args.nl,"s_min":args.s_min,"s_max":args.s_max,"l_min":args.l_min,"l_max":args.l_max},"group":args.group,"cases":[{"name":c.name,"note":c.note,"params":asdict(c.params)} for c in cases],"caveat":"finite-difference prescribed geometry source ledger"}
    (args.outdir/"radial_softening_metadata.json").write_text(json.dumps(meta,indent=2), encoding="utf-8")
    report=write_report(args.outdir,cases,compact,stage,safety,decision,args.ns,args.nl,"Radial-Pressure Softening Probe")
    (args.outdir/"RADIAL_SOFTENING_REPORT.md").write_text(report, encoding="utf-8")
    zpath=args.outdir.with_suffix(".zip")
    if zpath.exists(): zpath.unlink()
    with zipfile.ZipFile(zpath,"w",zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(args.outdir.iterdir()): zf.write(p, arcname=p.name)
        zf.write(Path(__file__), arcname=Path(__file__).name)
    print(json.dumps({"ok":True,"outdir":str(args.outdir),"zip":str(zpath),"rows":int(points.shape[0])}, indent=2))
if __name__ == "__main__":
    main()
