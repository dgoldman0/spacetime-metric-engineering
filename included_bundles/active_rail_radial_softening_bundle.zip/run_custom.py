import importlib.util, sys, pandas as pd, zipfile, json
from pathlib import Path
spec=importlib.util.spec_from_file_location('rsp','/mnt/data/active_rail_radial_softening/radial_softening_probe.py')
rsp=importlib.util.module_from_spec(spec); sys.modules['rsp']=rsp; spec.loader.exec_module(rsp)

def run(name, cases, outdir, ns=17, nl=29):
    outdir=Path(outdir); outdir.mkdir(parents=True, exist_ok=True)
    frames=[]
    for c in cases:
        print('Running', c.name, flush=True)
        frames.append(rsp.compute_case(c,ns,nl,-0.35,1.65,-2.80,2.80,2.5e-3,2.5e-3,progress=False))
    points=pd.concat(frames, ignore_index=True)
    points.to_csv(outdir/'radial_softening_point_ledger.csv', index=False)
    summary,compact,stage,safety,decision=rsp.summarize(points)
    summary.to_csv(outdir/'radial_softening_summary_long.csv', index=False)
    compact.to_csv(outdir/'radial_softening_global_compact.csv', index=False)
    stage.to_csv(outdir/'radial_softening_stage_summary.csv', index=False)
    safety.to_csv(outdir/'radial_softening_safety.csv', index=False)
    decision.to_csv(outdir/'radial_softening_decision_table.csv', index=False)
    (outdir/'RADIAL_SOFTENING_REPORT.md').write_text(rsp.write_report(outdir,cases,compact,stage,safety,decision,ns,nl,name), encoding='utf-8')
    zpath=outdir.with_suffix('.zip')
    if zpath.exists(): zpath.unlink()
    with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as zf:
        for p in outdir.iterdir(): zf.write(p, arcname=p.name)
        zf.write('/mnt/data/active_rail_radial_softening/radial_softening_probe.py', arcname='radial_softening_probe.py')
    print(decision[['case','score','pl_live_ratio','tkk_live_ratio','pl_peak_ratio','tkk_peak_ratio','max_packet_norm_live','positive_packet_norm_live','live_packet_burden__abs_p_l','live_packet_burden__neg_Tkk_radial']].to_string(index=False))

base=rsp.Params()
ext=[rsp.CaseDef('shaped_base',base,'baseline'),
     rsp.CaseDef('wth_0.55', rsp.replace(base,w_th=0.55), 'wth .55'),
     rsp.CaseDef('wth_0.60', rsp.replace(base,w_th=0.60), 'wth .60'),
     rsp.CaseDef('wth_0.70', rsp.replace(base,w_th=0.70), 'wth .70'),
     rsp.CaseDef('wth_0.80', rsp.replace(base,w_th=0.80), 'wth .80'),
     rsp.CaseDef('wth55_wpass08', rsp.replace(base,w_th=0.55,w_pass=0.08), 'wth .55 wpass .08'),
     rsp.CaseDef('wth60_wpass08', rsp.replace(base,w_th=0.60,w_pass=0.08), 'wth .60 wpass .08')]
run('Radial Softening Extended Probe', ext, '/mnt/data/active_rail_radial_softening/extended_17x29')
