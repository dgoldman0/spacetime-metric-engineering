# Radial-Pressure Softening Refine Probe

Prescribed-geometry point-level source diagnostic. This is a design-screening ledger, not a matter model or constraint solve.

Grid: `21 x 37` per case.

## Cases

| case          |   Rth |   w_th | w_th_inner   | w_th_outer   |   w_pass |   ROmega |   x_beta_catch |   x_packet_catch | note                                       |
|:--------------|------:|-------:|:-------------|:-------------|---------:|---------:|---------------:|-----------------:|:-------------------------------------------|
| shaped_base   |  1.75 |   0.35 |              |              |     0.06 |     1.75 |          -0.05 |                0 | baseline                                   |
| wth_0.55      |  1.75 |   0.55 |              |              |     0.06 |     1.75 |          -0.05 |                0 | wider radial support edge                  |
| wth55_wpass08 |  1.75 |   0.55 |              |              |     0.08 |     1.75 |          -0.05 |                0 | wider support plus modest packet smoothing |
| wth_0.60      |  1.75 |   0.6  |              |              |     0.06 |     1.75 |          -0.05 |                0 | too-wide candidate/safety boundary         |

## Decision table

| case          |   score |   pl_live_ratio |   tkk_live_ratio |   pl_peak_ratio |   tkk_peak_ratio |   infra_pressure_ratio |   max_packet_norm_live |   positive_packet_norm_live |   live_packet_fraction__abs_p_l |   live_packet_fraction__neg_Tkk_radial |   live_packet_burden__abs_p_l |   live_packet_burden__neg_Tkk_radial |
|:--------------|--------:|----------------:|-----------------:|----------------:|-----------------:|-----------------------:|-----------------------:|----------------------------:|--------------------------------:|---------------------------------------:|------------------------------:|-------------------------------------:|
| wth55_wpass08 |  0.8216 |          0.8216 |           0.7502 |          0.7445 |           0.7607 |                 0.7598 |                 -306.2 |                           0 |                          0.2669 |                                 0.2448 |                         14.44 |                                74.65 |
| wth_0.55      |  0.8216 |          0.8216 |           0.7619 |          0.7445 |           0.9081 |                 0.7598 |                 -306.2 |                           0 |                          0.2669 |                                 0.2479 |                         14.44 |                                75.81 |
| shaped_base   |  1      |          1      |           1      |          1      |           1      |                 1      |                 -584.3 |                           0 |                          0.2468 |                                 0.2286 |                         17.57 |                                99.51 |
| wth_0.60      | 10.77   |          0.7701 |           0.6921 |          0.7226 |           0.8741 |                 0.7069 |                12390   |                           1 |                          0.2689 |                                 0.2483 |                         13.53 |                                68.87 |

## Stage live burden for radial channels

### abs_p_l

| case          |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:--------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| shaped_base   |                0 |           15.91 |            0 |                1.658 |                     0 |                     0 |
| wth55_wpass08 |                0 |           13.11 |            0 |                1.323 |                     0 |                     0 |
| wth_0.55      |                0 |           13.11 |            0 |                1.323 |                     0 |                     0 |
| wth_0.60      |                0 |           12.29 |            0 |                1.242 |                     0 |                     0 |

### neg_Tkk_radial

| case          |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:--------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| shaped_base   |                0 |           87.14 |            0 |               12.37  |                     0 |                     0 |
| wth55_wpass08 |                0 |           65.18 |            0 |                9.463 |                     0 |                     0 |
| wth_0.55      |                0 |           66.35 |            0 |                9.467 |                     0 |                     0 |
| wth_0.60      |                0 |           60.12 |            0 |                8.751 |                     0 |                     0 |

## Safety table

| case          |   live_points |   max_packet_norm_live |   min_packet_norm_live |   positive_packet_norm_live |
|:--------------|--------------:|-----------------------:|-----------------------:|----------------------------:|
| shaped_base   |            67 |               -584.334 |                -323651 |                           0 |
| wth55_wpass08 |            67 |               -306.155 |                -187259 |                           0 |
| wth_0.55      |            67 |               -306.163 |                -189431 |                           0 |
| wth_0.60      |            67 |              12391.9   |                -154935 |                           1 |
