# Radial-Pressure Softening Probe

Prescribed-geometry point-level source diagnostic. This is a design-screening ledger, not a matter model or constraint solve.

Grid: `17 x 29` per case.

## Cases

| case                         |   Rth |   w_th |   w_th_inner |   w_th_outer |   w_pass |   ROmega |   x_beta_catch |   x_packet_catch | note                                                                                      |
|:-----------------------------|------:|-------:|-------------:|-------------:|---------:|---------:|---------------:|-----------------:|:------------------------------------------------------------------------------------------|
| shaped_base                  |  1.75 |   0.35 |       nan    |        nan   |     0.06 |     1.75 |          -0.05 |                0 | R1.75 locked-lead shaped catch baseline: beta catch leads by 0.05; packet follows tightly |
| wth45_wpass08                |  1.75 |   0.45 |       nan    |        nan   |     0.08 |     1.75 |          -0.05 |                0 | wider support plus slightly softer packet transition                                      |
| wth50_wpass08                |  1.75 |   0.5  |       nan    |        nan   |     0.08 |     1.75 |          -0.05 |                0 | wider support plus slightly softer packet transition                                      |
| R185_wth45                   |  1.85 |   0.45 |       nan    |        nan   |     0.06 |     1.85 |          -0.05 |                0 | moderately outward and wider support                                                      |
| R180_wth45_wpass08           |  1.8  |   0.45 |       nan    |        nan   |     0.08 |     1.8  |          -0.05 |                0 | moderately outward, wider support, soft packet transition                                 |
| asym_inner45_outer30_wpass08 |  1.75 |   0.35 |         0.45 |          0.3 |     0.08 |     1.75 |          -0.05 |                0 | asymmetric radial shoulder plus soft packet transition                                    |

## Decision table

| case                         |   score |   pl_live_ratio |   tkk_live_ratio |   pl_peak_ratio |   tkk_peak_ratio |   infra_pressure_ratio |   max_packet_norm_live |   positive_packet_norm_live |   live_packet_fraction__abs_p_l |   live_packet_fraction__neg_Tkk_radial |   live_packet_burden__abs_p_l |   live_packet_burden__neg_Tkk_radial |
|:-----------------------------|--------:|----------------:|-----------------:|----------------:|-----------------:|-----------------------:|-----------------------:|----------------------------:|--------------------------------:|---------------------------------------:|------------------------------:|-------------------------------------:|
| wth50_wpass08                |  0.8724 |          0.8724 |           0.8218 |          0.7917 |           0.798  |                 0.8166 |                 -480   |                           0 |                          0.2662 |                                 0.2463 |                         15.7  |                                83.65 |
| wth45_wpass08                |  0.9211 |          0.9211 |           0.887  |          0.803  |           0.8155 |                 0.8766 |                 -562.3 |                           0 |                          0.2618 |                                 0.2424 |                         16.58 |                                90.28 |
| asym_inner45_outer30_wpass08 |  0.9335 |          0.9211 |           0.887  |          1.062  |           0.9886 |                 0.8737 |                 -562.3 |                           0 |                          0.2627 |                                 0.2423 |                         16.58 |                                90.28 |
| R180_wth45_wpass08           |  0.9342 |          0.9342 |           0.9035 |          0.8095 |           0.7783 |                 0.9171 |                 -626.3 |                           0 |                          0.2538 |                                 0.2348 |                         16.81 |                                91.96 |
| R185_wth45                   |  0.9461 |          0.9461 |           0.9299 |          0.7744 |           0.8884 |                 0.9577 |                 -687.4 |                           0 |                          0.2461 |                                 0.2297 |                         17.02 |                                94.65 |
| shaped_base                  |  1      |          1      |           1      |          1      |           1      |                 1      |                 -783.8 |                           0 |                          0.2492 |                                 0.2314 |                         18    |                               101.8  |

## Stage live burden for radial channels

### abs_p_l

| case                         |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:-----------------------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| R180_wth45_wpass08           |                0 |           15.26 |            0 |                1.548 |                     0 |                     0 |
| R185_wth45                   |                0 |           15.44 |            0 |                1.582 |                     0 |                     0 |
| asym_inner45_outer30_wpass08 |                0 |           15.06 |            0 |                1.511 |                     0 |                     0 |
| shaped_base                  |                0 |           16.31 |            0 |                1.682 |                     0 |                     0 |
| wth45_wpass08                |                0 |           15.06 |            0 |                1.511 |                     0 |                     0 |
| wth50_wpass08                |                0 |           14.28 |            0 |                1.421 |                     0 |                     0 |

### neg_Tkk_radial

| case                         |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:-----------------------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| R180_wth45_wpass08           |                0 |           80.13 |            0 |                11.83 |                     0 |                     0 |
| R185_wth45                   |                0 |           82.56 |            0 |                12.09 |                     0 |                     0 |
| asym_inner45_outer30_wpass08 |                0 |           78.71 |            0 |                11.57 |                     0 |                     0 |
| shaped_base                  |                0 |           88.69 |            0 |                13.1  |                     0 |                     0 |
| wth45_wpass08                |                0 |           78.71 |            0 |                11.57 |                     0 |                     0 |
| wth50_wpass08                |                0 |           72.9  |            0 |                10.75 |                     0 |                     0 |

## Safety table

| case                         |   live_points |   max_packet_norm_live |   min_packet_norm_live |   positive_packet_norm_live |
|:-----------------------------|--------------:|-----------------------:|-----------------------:|----------------------------:|
| R180_wth45_wpass08           |            42 |               -626.302 |                -269588 |                           0 |
| R185_wth45                   |            42 |               -687.448 |                -280905 |                           0 |
| asym_inner45_outer30_wpass08 |            42 |               -562.293 |                -260481 |                           0 |
| shaped_base                  |            42 |               -783.78  |                -324034 |                           0 |
| wth45_wpass08                |            42 |               -562.293 |                -260481 |                           0 |
| wth50_wpass08                |            42 |               -480.017 |                -223247 |                           0 |
