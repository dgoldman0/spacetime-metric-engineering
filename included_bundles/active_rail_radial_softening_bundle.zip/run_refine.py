import importlib.util, sys, pandas as pd, zipfile, json
from pathlib import Path
spec=importlib.util.spec_from_file_location('rsp','/mnt/data/active_rail_radial_softening/radial_softening_probe.py')
rsp=importlib.util.module_from_spec(spec); sys.modules['rsp']=rsp; spec.loader.exec_module(rsp)
base=rsp.Params()
cases=[rsp.CaseDef('shaped_base',base,'baseline'),
       rsp.CaseDef('wth_0.55', rsp.replace(base,w_th=0.55), 'wider radial support edge'),
       rsp.CaseDef('wth55_wpass08', rsp.replace(base,w_th=0.55,w_pass=0.08), 'wider support plus modest packet smoothing'),
       rsp.CaseDef('wth_0.60', rsp.replace(base,w_th=0.60), 'too-wide candidate/safety boundary')]
ns=21; nl=37; outdir=Path('/mnt/data/active_rail_radial_softening/refine_21x37'); outdir.mkdir(exist_ok=True,parents=True)
frames=[]
for c in cases:
    print('Running',c.name, flush=True)
    frames.append(rsp.compute_case(c,ns,nl,-0.35,1.65,-2.80,2.80,2.5e-3,2.5e-3,progress=False))
points=pd.concat(frames,ignore_index=True); points.to_csv(outdir/'radial_softening_point_ledger.csv',index=False)
summary,compact,stage,safety,decision=rsp.summarize(points)
for name,df in [('radial_softening_summary_long.csv',summary),('radial_softening_global_compact.csv',compact),('radial_softening_stage_summary.csv',stage),('radial_softening_safety.csv',safety),('radial_softening_decision_table.csv',decision)]: df.to_csv(outdir/name,index=False)
(outdir/'RADIAL_SOFTENING_REPORT.md').write_text(rsp.write_report(outdir,cases,compact,stage,safety,decision,ns,nl,'Radial-Pressure Softening Refine Probe'),encoding='utf-8')
meta={'grid':{'ns':ns,'nl':nl},'cases':[{'name':c.name,'note':c.note,'params':rsp.asdict(c.params)} for c in cases]}
(outdir/'radial_softening_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
zpath=outdir.with_suffix('.zip')
if zpath.exists(): zpath.unlink()
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as zf:
    for p in outdir.iterdir(): zf.write(p,arcname=p.name)
    zf.write('/mnt/data/active_rail_radial_softening/radial_softening_probe.py', arcname='radial_softening_probe.py')
print(decision[['case','score','pl_live_ratio','tkk_live_ratio','pl_peak_ratio','tkk_peak_ratio','max_packet_norm_live','positive_packet_norm_live','live_packet_burden__abs_p_l','live_packet_burden__neg_Tkk_radial','live_packet_fraction__abs_p_l','live_packet_fraction__neg_Tkk_radial']].to_string(index=False))
