# Radial-Pressure Softening Probe

Prescribed-geometry point-level source diagnostic. This is a design-screening ledger, not a matter model or constraint solve.

Grid: `17 x 29` per case.

## Cases

| case        |   Rth |   w_th | w_th_inner   | w_th_outer   |   w_pass |   ROmega |   x_beta_catch |   x_packet_catch | note                                                                                      |
|:------------|------:|-------:|:-------------|:-------------|---------:|---------:|---------------:|-----------------:|:------------------------------------------------------------------------------------------|
| shaped_base |  1.75 |   0.35 |              |              |     0.06 |     1.75 |          -0.05 |                0 | R1.75 locked-lead shaped catch baseline: beta catch leads by 0.05; packet follows tightly |
| wth_0.40    |  1.75 |   0.4  |              |              |     0.06 |     1.75 |          -0.05 |                0 | widen radial support edge to 0.40                                                         |
| wth_0.45    |  1.75 |   0.45 |              |              |     0.06 |     1.75 |          -0.05 |                0 | widen radial support edge to 0.45                                                         |
| wth_0.50    |  1.75 |   0.5  |              |              |     0.06 |     1.75 |          -0.05 |                0 | widen radial support edge to 0.50                                                         |
| wth_0.55    |  1.75 |   0.55 |              |              |     0.06 |     1.75 |          -0.05 |                0 | widen radial support edge to 0.55                                                         |

## Decision table

| case        |   score |   pl_live_ratio |   tkk_live_ratio |   pl_peak_ratio |   tkk_peak_ratio |   infra_pressure_ratio |   max_packet_norm_live |   positive_packet_norm_live |   live_packet_fraction__abs_p_l |   live_packet_fraction__neg_Tkk_radial |   live_packet_burden__abs_p_l |   live_packet_burden__neg_Tkk_radial |
|:------------|--------:|----------------:|-----------------:|----------------:|-----------------:|-----------------------:|-----------------------:|----------------------------:|--------------------------------:|---------------------------------------:|------------------------------:|-------------------------------------:|
| wth_0.55    |  0.8212 |          0.8212 |           0.7626 |          0.7437 |           0.9084 |                 0.7597 |                 -413.8 |                           0 |                          0.2693 |                                 0.251  |                         14.78 |                                77.62 |
| wth_0.50    |  0.8724 |          0.8724 |           0.8324 |          0.7917 |           0.9392 |                 0.8166 |                 -480   |                           0 |                          0.2662 |                                 0.2488 |                         15.7  |                                84.72 |
| wth_0.45    |  0.9211 |          0.9211 |           0.8982 |          0.803  |           0.9656 |                 0.8766 |                 -562.3 |                           0 |                          0.2618 |                                 0.2448 |                         16.58 |                                91.43 |
| wth_0.40    |  0.9646 |          0.9646 |           0.9555 |          0.8779 |           0.9861 |                 0.9383 |                 -663.3 |                           0 |                          0.2561 |                                 0.239  |                         17.36 |                                97.26 |
| shaped_base |  1      |          1      |           1      |          1      |           1      |                 1      |                 -783.8 |                           0 |                          0.2492 |                                 0.2314 |                         18    |                               101.8  |

## Stage live burden for radial channels

### abs_p_l

| case        |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| shaped_base |                0 |           16.31 |            0 |                1.682 |                     0 |                     0 |
| wth_0.40    |                0 |           15.76 |            0 |                1.6   |                     0 |                     0 |
| wth_0.45    |                0 |           15.06 |            0 |                1.511 |                     0 |                     0 |
| wth_0.50    |                0 |           14.28 |            0 |                1.421 |                     0 |                     0 |
| wth_0.55    |                0 |           13.44 |            0 |                1.333 |                     0 |                     0 |

### neg_Tkk_radial

| case        |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| shaped_base |                0 |           88.69 |            0 |               13.1   |                     0 |                     0 |
| wth_0.40    |                0 |           84.86 |            0 |               12.4   |                     0 |                     0 |
| wth_0.45    |                0 |           79.82 |            0 |               11.61  |                     0 |                     0 |
| wth_0.50    |                0 |           73.94 |            0 |               10.78  |                     0 |                     0 |
| wth_0.55    |                0 |           67.64 |            0 |                9.972 |                     0 |                     0 |

## Safety table

| case        |   live_points |   max_packet_norm_live |   min_packet_norm_live |   positive_packet_norm_live |
|:------------|--------------:|-----------------------:|-----------------------:|----------------------------:|
| shaped_base |            42 |               -783.78  |                -324034 |                           0 |
| wth_0.40    |            42 |               -663.328 |                -297020 |                           0 |
| wth_0.45    |            42 |               -562.31  |                -263643 |                           0 |
| wth_0.50    |            42 |               -480.031 |                -226715 |                           0 |
| wth_0.55    |            42 |               -413.802 |                -189094 |                           0 |
