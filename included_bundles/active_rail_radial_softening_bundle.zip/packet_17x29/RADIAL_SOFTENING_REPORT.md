# Radial-Pressure Softening Probe

Prescribed-geometry point-level source diagnostic. This is a design-screening ledger, not a matter model or constraint solve.

Grid: `17 x 29` per case.

## Cases

| case        |   Rth |   w_th | w_th_inner   | w_th_outer   |   w_pass |   ROmega |   x_beta_catch |   x_packet_catch | note                                                                                      |
|:------------|------:|-------:|:-------------|:-------------|---------:|---------:|---------------:|-----------------:|:------------------------------------------------------------------------------------------|
| shaped_base |  1.75 |   0.35 |              |              |     0.06 |     1.75 |          -0.05 |                0 | R1.75 locked-lead shaped catch baseline: beta catch leads by 0.05; packet follows tightly |
| wpass_0.08  |  1.75 |   0.35 |              |              |     0.08 |     1.75 |          -0.05 |                0 | soften packet/support transition to 0.08                                                  |
| wpass_0.10  |  1.75 |   0.35 |              |              |     0.1  |     1.75 |          -0.05 |                0 | soften packet/support transition to 0.10                                                  |
| wpass_0.12  |  1.75 |   0.35 |              |              |     0.12 |     1.75 |          -0.05 |                0 | soften packet/support transition to 0.12                                                  |

## Decision table

| case        |   score |   pl_live_ratio |   tkk_live_ratio |   pl_peak_ratio |   tkk_peak_ratio |   infra_pressure_ratio |   max_packet_norm_live |   positive_packet_norm_live |   live_packet_fraction__abs_p_l |   live_packet_fraction__neg_Tkk_radial |   live_packet_burden__abs_p_l |   live_packet_burden__neg_Tkk_radial |
|:------------|--------:|----------------:|-----------------:|----------------:|-----------------:|-----------------------:|-----------------------:|----------------------------:|--------------------------------:|---------------------------------------:|------------------------------:|-------------------------------------:|
| wpass_0.12  |       1 |               1 |           0.9473 |               1 |            0.885 |                      1 |                 -783.7 |                           0 |                          0.2492 |                                 0.2213 |                            18 |                                96.42 |
| wpass_0.10  |       1 |               1 |           0.9689 |               1 |            0.885 |                      1 |                 -783.7 |                           0 |                          0.2492 |                                 0.2255 |                            18 |                                98.62 |
| wpass_0.08  |       1 |               1 |           0.9881 |               1 |            0.885 |                      1 |                 -783.8 |                           0 |                          0.2492 |                                 0.2292 |                            18 |                               100.6  |
| shaped_base |       1 |               1 |           1      |               1 |            1     |                      1 |                 -783.8 |                           0 |                          0.2492 |                                 0.2314 |                            18 |                               101.8  |

## Stage live burden for radial channels

### abs_p_l

| case        |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| shaped_base |                0 |           16.31 |            0 |                1.682 |                     0 |                     0 |
| wpass_0.08  |                0 |           16.31 |            0 |                1.682 |                     0 |                     0 |
| wpass_0.10  |                0 |           16.31 |            0 |                1.682 |                     0 |                     0 |
| wpass_0.12  |                0 |           16.31 |            0 |                1.682 |                     0 |                     0 |

### neg_Tkk_radial

| case        |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| shaped_base |                0 |           88.69 |            0 |                13.1  |                     0 |                     0 |
| wpass_0.08  |                0 |           87.51 |            0 |                13.06 |                     0 |                     0 |
| wpass_0.10  |                0 |           85.59 |            0 |                13.03 |                     0 |                     0 |
| wpass_0.12  |                0 |           83.41 |            0 |                13.01 |                     0 |                     0 |

## Safety table

| case        |   live_points |   max_packet_norm_live |   min_packet_norm_live |   positive_packet_norm_live |
|:------------|--------------:|-----------------------:|-----------------------:|----------------------------:|
| shaped_base |            42 |               -783.78  |                -324034 |                           0 |
| wpass_0.08  |            42 |               -783.754 |                -321641 |                           0 |
| wpass_0.10  |            42 |               -783.72  |                -317365 |                           0 |
| wpass_0.12  |            42 |               -783.684 |                -313489 |                           0 |
