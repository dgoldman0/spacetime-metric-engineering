# Radial-Pressure Softening Probe

Prescribed-geometry point-level source diagnostic. This is a design-screening ledger, not a matter model or constraint solve.

Grid: `17 x 29` per case.

## Cases

| case                 |   Rth |   w_th |   w_th_inner |   w_th_outer |   w_pass |   ROmega |   x_beta_catch |   x_packet_catch | note                                                                                      |
|:---------------------|------:|-------:|-------------:|-------------:|---------:|---------:|---------------:|-----------------:|:------------------------------------------------------------------------------------------|
| shaped_base          |  1.75 |   0.35 |       nan    |       nan    |     0.06 |     1.75 |          -0.05 |                0 | R1.75 locked-lead shaped catch baseline: beta catch leads by 0.05; packet follows tightly |
| asym_inner45_outer30 |  1.75 |   0.35 |         0.45 |         0.3  |     0.06 |     1.75 |          -0.05 |                0 | soft inner shoulder, firmer outer falloff                                                 |
| asym_inner50_outer30 |  1.75 |   0.35 |         0.5  |         0.3  |     0.06 |     1.75 |          -0.05 |                0 | softer inner shoulder, firmer outer falloff                                               |
| asym_inner45_outer25 |  1.75 |   0.35 |         0.45 |         0.25 |     0.06 |     1.75 |          -0.05 |                0 | soft inner shoulder, sharp outer falloff                                                  |

## Decision table

| case                 |   score |   pl_live_ratio |   tkk_live_ratio |   pl_peak_ratio |   tkk_peak_ratio |   infra_pressure_ratio |   max_packet_norm_live |   positive_packet_norm_live |   live_packet_fraction__abs_p_l |   live_packet_fraction__neg_Tkk_radial |   live_packet_burden__abs_p_l |   live_packet_burden__neg_Tkk_radial |
|:---------------------|--------:|----------------:|-----------------:|----------------:|-----------------:|-----------------------:|-----------------------:|----------------------------:|--------------------------------:|---------------------------------------:|------------------------------:|-------------------------------------:|
| asym_inner50_outer30 |  0.8847 |          0.8724 |           0.8324 |           1.062 |           0.9886 |                 0.8128 |                 -480   |                           0 |                          0.2674 |                                 0.2488 |                         15.7  |                                84.72 |
| asym_inner45_outer30 |  0.9335 |          0.9211 |           0.8982 |           1.062 |           0.9886 |                 0.8737 |                 -562.3 |                           0 |                          0.2627 |                                 0.2448 |                         16.58 |                                91.43 |
| asym_inner45_outer25 |  0.9488 |          0.9211 |           0.8982 |           1.138 |           1.152  |                 0.8727 |                 -562.3 |                           0 |                          0.263  |                                 0.2448 |                         16.58 |                                91.43 |
| shaped_base          |  1      |          1      |           1      |           1     |           1      |                 1      |                 -783.8 |                           0 |                          0.2492 |                                 0.2314 |                         18    |                               101.8  |

## Stage live burden for radial channels

### abs_p_l

| case                 |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:---------------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| asym_inner45_outer25 |                0 |           15.06 |            0 |                1.511 |                     0 |                     0 |
| asym_inner45_outer30 |                0 |           15.06 |            0 |                1.511 |                     0 |                     0 |
| asym_inner50_outer30 |                0 |           14.28 |            0 |                1.421 |                     0 |                     0 |
| shaped_base          |                0 |           16.31 |            0 |                1.682 |                     0 |                     0 |

### neg_Tkk_radial

| case                 |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:---------------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| asym_inner45_outer25 |                0 |           79.82 |            0 |                11.61 |                     0 |                     0 |
| asym_inner45_outer30 |                0 |           79.82 |            0 |                11.61 |                     0 |                     0 |
| asym_inner50_outer30 |                0 |           73.94 |            0 |                10.78 |                     0 |                     0 |
| shaped_base          |                0 |           88.69 |            0 |                13.1  |                     0 |                     0 |

## Safety table

| case                 |   live_points |   max_packet_norm_live |   min_packet_norm_live |   positive_packet_norm_live |
|:---------------------|--------------:|-----------------------:|-----------------------:|----------------------------:|
| asym_inner45_outer25 |            42 |               -562.31  |                -263643 |                           0 |
| asym_inner45_outer30 |            42 |               -562.31  |                -263643 |                           0 |
| asym_inner50_outer30 |            42 |               -480.031 |                -226715 |                           0 |
| shaped_base          |            42 |               -783.78  |                -324034 |                           0 |
