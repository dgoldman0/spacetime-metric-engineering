#!/usr/bin/env python3
from __future__ import annotations
import json, math, zipfile, shutil
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import nnls

R_PASS=0.35
INPUT=Path('/mnt/data/active_rail_source_decomposition_proxy/input_freeze_candidate_point_ledger_41x73.csv')
OUT=Path('/mnt/data/active_rail_source_absorber')


def norm_col(s):
    arr=s.astype(float).replace([np.inf,-np.inf],np.nan).fillna(0.0)
    mx=float(arr.max()) if len(arr) else 0.0
    return arr/mx if mx>0 else arr*0.0


def masks(df):
    stage=df['stage'].astype(str); region=df['region'].astype(str)
    return {
        'live':df['inside_packet_live'].astype(bool),
        'geom':df['inside_packet_geom'].astype(bool),
        'catch':stage=='catch_rematch',
        'release':stage=='release_shift_fade',
        'post':stage=='post_release_buffer',
        'reset':stage=='reset_decompression',
        'core':region=='core_throat',
        'support':region=='support_edge',
        'outer':region=='outer_quarantine_shell',
        'packet_support':region=='packet_in_support',
        'packet_outer':region=='packet_outer',
    }


def add_base_basis(df):
    p=df.copy().reset_index(drop=True); m=masks(p)
    f={k:v.astype(float) for k,v in m.items()}
    N=(p['alpha']/p['T'].replace(0,np.nan)).replace([np.inf,-np.inf],np.nan).fillna(0.0)
    N=(N-1.0).clip(lower=0)
    CO=(p['COmega']-1.0).clip(lower=0).fillna(0.0)
    beta_abs=p['beta'].abs().fillna(0.0)
    W=p['W'].clip(0,1).fillna(0.0); Wedge=(W*(1-W)).fillna(0.0)
    bases=pd.DataFrame(index=p.index)
    bases['cold_core_substrate']=p['q'].clip(0)*p['W'].clip(0)*(f['core']+0.35*f['support'])
    bases['radial_support_edge_shell']=p['q'].clip(0)*(Wedge+0.15*f['support'])
    bases['outer_quarantine_jacket']=CO*(0.35*f['support']+f['outer']+0.15*f['core'])
    bases['lapse_cushion_sector']=N*(0.5*f['support']+f['outer']+0.2*f['core']+0.2*f['geom'])
    bases['shift_packet_carrier']=p['E'].clip(0)*p['S'].clip(0)*beta_abs
    bases['catch_rematch_transient']=f['catch']*(0.25+p['S'].clip(0)+0.5*p['W'].clip(0))
    bases['release_shift_transient']=f['release']*(0.25+p['S'].clip(0)+0.5*p['E'].clip(0))
    bases['packet_local_residual']=f['live']*(0.25+p['S'].clip(0))
    bases['reset_decompression_infra']=(f['reset']+0.5*f['post'])*(0.25+p['q'].clip(0)+p['W'].clip(0))*(1-f['live'])
    return bases.apply(norm_col)


def add_targeted_v1_basis(df,rpass=R_PASS):
    p=df.copy().reset_index(drop=True); m=masks(p); f={k:v.astype(float) for k,v in m.items()}
    bases=pd.DataFrame(index=p.index)
    xi=(p['l']-p['s']).astype(float)
    sigma=max(0.045,rpass/4.5)
    inner=np.exp(-((xi+rpass)/sigma)**2)
    outer=np.exp(-((xi-rpass)/sigma)**2)
    boundary=np.exp(-((np.abs(xi)-rpass)/sigma)**2)
    center=np.exp(-(xi/(rpass*0.55))**2)
    W=p['W'].clip(0,1).fillna(0.0); S=p['S'].clip(0,1).fillna(0.0)
    Wedge=(W*(1-W)).fillna(0.0); Sedge=(S*(1-S)).fillna(0.0)
    N=((p['alpha']/p['T'].replace(0,np.nan))-1.0).replace([np.inf,-np.inf],np.nan).fillna(0.0).clip(lower=0)
    beta_abs=p['beta'].abs().fillna(0.0); beta_norm=beta_abs/(float(beta_abs.max()) if float(beta_abs.max())>0 else 1.0)
    s=p['s'].astype(float); early=np.exp(-((s+0.25)/0.18)**2); mid=np.exp(-((s-0.00)/0.22)**2)
    bases['catch_inner_packet_edge_transient']=f['catch']*f['live']*inner*(0.25+S+0.25*W)
    bases['catch_outer_packet_edge_transient']=f['catch']*f['live']*outer*(0.25+S+0.25*W)
    bases['catch_live_packet_boundary_transient']=f['catch']*f['live']*boundary*(0.25+Sedge+0.25*W)
    bases['catch_inner_edge_lapse_coupled']=f['catch']*f['live']*inner*(0.25+N)*(0.25+S)
    bases['catch_inner_edge_shift_coupled']=f['catch']*f['live']*inner*(0.25+beta_norm)*(0.25+Sedge+S)
    bases['catch_core_bridge_transient']=f['catch']*(f['core']+f['packet_support'])*center*(0.25+W)*(0.6*early+0.4*mid)
    bases['catch_support_edge_bridge_transient']=f['catch']*(f['support']+0.5*f['packet_support'])*Wedge*(0.4+0.6*boundary)
    return bases.apply(norm_col)


def add_source_absorber_basis(df,rpass=R_PASS):
    p=df.copy().reset_index(drop=True); m=masks(p); f={k:v.astype(float) for k,v in m.items()}
    bases=pd.DataFrame(index=p.index)
    xi=(p['l']-p['s']).astype(float)
    # Wider than geometric guard: source-side absorber can cover both packet side and infrastructure side.
    inner_narrow=np.exp(-((xi+rpass)/0.065)**2)
    inner_medium=np.exp(-((xi+rpass)/0.105)**2)
    inner_wide=np.exp(-((xi+rpass)/0.16)**2)
    just_outside=(xi < -rpass).astype(float)
    just_inside=(xi >= -rpass).astype(float)
    s=p['s'].astype(float)
    early=np.exp(-((s+0.30)/0.16)**2)
    handoff=np.exp(-((s+0.18)/0.22)**2)
    mid=np.exp(-((s-0.02)/0.24)**2)
    catch_env=(0.45*early+0.65*handoff+0.35*mid)
    W=p['W'].clip(0,1).fillna(0.0); S=p['S'].clip(0,1).fillna(0.0)
    Wedge=(W*(1-W)).fillna(0.0); Sedge=(S*(1-S)).fillna(0.0)
    beta_abs=p['beta'].abs().fillna(0.0); beta_norm=beta_abs/(float(beta_abs.max()) if float(beta_abs.max())>0 else 1.0)
    N=((p['alpha']/p['T'].replace(0,np.nan))-1.0).replace([np.inf,-np.inf],np.nan).fillna(0.0).clip(lower=0)
    q=p['q'].clip(0).fillna(0.0); E=p['E'].clip(0).fillna(0.0)
    live=f['live']; catch=f['catch']; core=f['core']; packet=f['packet_support']; support=f['support']
    # Compact source roles, not pointwise residuals.
    bases['source_inner_edge_absorber_skin']=catch*inner_medium*(packet+0.7*core+0.2*support)*(0.35+Sedge+0.25*W)*catch_env
    bases['source_inner_edge_live_face']=catch*live*inner_medium*(0.25+S+Sedge)*(0.55*early+0.45*handoff+0.2*mid)
    bases['source_inner_edge_infra_face']=catch*(1-live)*inner_medium*(packet+core+0.15*support)*(0.35+W)*(0.7*early+0.5*handoff)
    bases['source_inner_edge_shear_pair']=catch*inner_narrow*(packet+0.5*core)*(0.2+beta_norm)*(0.3+Sedge+0.3*S)*(0.6*early+0.6*handoff)
    bases['source_inner_edge_lapse_absorber']=catch*inner_wide*(packet+0.35*core+0.15*support)*(0.2+N)*(0.25+Sedge)*(0.55*early+0.35*handoff)
    bases['source_core_side_handoff_absorber']=catch*just_outside*inner_wide*(core+packet)*(0.25+W)*(0.6*early+0.4*handoff)
    bases['source_packet_side_handoff_absorber']=catch*just_inside*inner_wide*live*(0.25+S+0.4*Sedge)*(0.45*early+0.55*handoff)
    bases['source_catch_carrier_edge_coupling']=catch*inner_medium*(packet+0.25*core)*(0.2+E)*(0.2+beta_norm)*(0.3+S)*(0.4*early+0.6*handoff)
    # One broader non-passenger core bridge because top underfits also include core-throat just outside live mask.
    bases['source_nonpassenger_core_catch_bridge']=catch*(1-live)*(core+0.5*packet)*np.exp(-((xi+rpass*1.05)/0.28)**2)*(0.25+W)*(0.6*early+0.5*handoff+0.2*mid)
    return bases.apply(norm_col)


def add_audit_basis(df,rpass=R_PASS):
    # A deliberately too-flexible family to show the ceiling. Not used for final interpretation unless compact fails.
    p=df.copy().reset_index(drop=True); m=masks(p); f={k:v.astype(float) for k,v in m.items()}
    bases=pd.DataFrame(index=p.index)
    xi=(p['l']-p['s']).astype(float); s=p['s'].astype(float)
    catch=f['catch']; live=f['live']
    centers_s=[-0.30,-0.18,-0.06,0.08,0.22,0.36]
    centers_x=[-0.42,-0.35,-0.28,-0.18,-0.05,0.10,0.25,0.35]
    for cs in centers_s:
        tenv=np.exp(-((s-cs)/0.14)**2)
        for cx in centers_x:
            xenv=np.exp(-((xi-cx)/0.08)**2)
            # Catch only, weighted toward live or near packet/support. This is not a physical component set; it is a fit-ceiling probe.
            bases[f'audit_shapelet_s{cs:+.2f}_x{cx:+.2f}']=catch*tenv*xenv*(0.4+0.6*live)
    return bases.apply(norm_col)


def fit_nnls(df,basis,ycol='bad_neg_Tkk_radial'):
    y=df[ycol].to_numpy(float); y=np.where(np.isfinite(y),y,0.0)
    vol=df['volume_weight'].to_numpy(float); vol=np.where(np.isfinite(vol)&(vol>0),vol,1.0)
    X=basis.to_numpy(float)
    w=np.sqrt(vol)
    coeff,rnorm=nnls(X*w[:,None],y*w,maxiter=60000)
    yhat=np.clip(X@coeff,0,None)
    resid=y-yhat
    actual=y*vol; pred=yhat*vol
    under=np.maximum(resid,0)*vol; over=np.maximum(-resid,0)*vol; absres=np.abs(resid)*vol
    live=df['inside_packet_live'].to_numpy(bool); catch=(df['stage'].astype(str)=='catch_rematch').to_numpy(bool); lc=live&catch
    def frac(arr,mask=None):
        if mask is None: den=actual.sum(); num=arr.sum()
        else: den=actual[mask].sum(); num=arr[mask].sum()
        return float(num/den) if den else np.nan
    metrics={
        'components':basis.shape[1],
        'actual_total_burden':float(actual.sum()),
        'actual_live_packet_burden':float(actual[live].sum()),
        'actual_catch_burden':float(actual[catch].sum()),
        'actual_live_catch_burden':float(actual[lc].sum()),
        'predicted_total_burden':float(pred.sum()),
        'predicted_live_packet_burden':float(pred[live].sum()),
        'predicted_catch_burden':float(pred[catch].sum()),
        'predicted_live_catch_burden':float(pred[lc].sum()),
        'underfit_total_fraction':frac(under),
        'underfit_live_fraction':frac(under,live),
        'underfit_catch_fraction':frac(under,catch),
        'underfit_live_catch_fraction':frac(under,lc),
        'l1_total_fraction':frac(absres),
        'l1_live_fraction':frac(absres,live),
        'l1_live_catch_fraction':frac(absres,lc),
        'overfit_total_fraction':frac(over),
        'overfit_live_fraction':frac(over,live),
        'overfit_live_catch_fraction':frac(over,lc),
        'rnorm_weighted_l2':float(rnorm),
    }
    comp_pred=X*coeff[None,:]*vol[:,None]
    alloc=[]
    total=actual.sum(); live_total=actual[live].sum(); catch_total=actual[catch].sum(); lc_total=actual[lc].sum()
    for j,name in enumerate(basis.columns):
        ctot=comp_pred[:,j].sum(); cl=comp_pred[live,j].sum(); cc=comp_pred[catch,j].sum(); clc=comp_pred[lc,j].sum()
        alloc.append({'component':name,'coefficient':float(coeff[j]),'allocated_total_burden':float(ctot),'share_total_actual':float(ctot/total) if total else np.nan,'allocated_live_packet_burden':float(cl),'share_live_actual':float(cl/live_total) if live_total else np.nan,'allocated_catch_burden':float(cc),'share_catch_actual':float(cc/catch_total) if catch_total else np.nan,'allocated_live_catch_burden':float(clc),'share_live_catch_actual':float(clc/lc_total) if lc_total else np.nan})
    point=df[['case','s','l','stage','region','inside_packet_live','inside_packet_geom','packet_norm','bad_neg_Tkk_radial','volume_weight']].copy()
    point['predicted_badness']=yhat; point['residual_badness']=resid; point['underfit_burden']=under; point['overfit_burden']=over; point['absres_burden']=absres; point['actual_burden']=actual; point['predicted_burden']=pred
    return metrics,pd.DataFrame(alloc),point


def summarize_stage(point):
    return point.groupby(['stage','region','inside_packet_live'],dropna=False).agg(points=('s','size'),actual_burden=('actual_burden','sum'),predicted_burden=('predicted_burden','sum'),underfit_burden=('underfit_burden','sum'),overfit_burden=('overfit_burden','sum'),absres_burden=('absres_burden','sum'),max_actual=('bad_neg_Tkk_radial','max'),max_pred=('predicted_badness','max'),max_underfit_point=('underfit_burden','max')).reset_index()


def xi_bins(point):
    p=point[(point.stage=='catch_rematch') & (point.inside_packet_live)].copy()
    p['xi']=p['l']-p['s']
    p['xi_bin']=pd.cut(p['xi'],bins=[-0.350001,-0.25,-0.15,-0.05,0.05,0.15,0.25,0.350001],include_lowest=True)
    return p.groupby('xi_bin',observed=False).agg(points=('s','size'),actual=('actual_burden','sum'),predicted=('predicted_burden','sum'),underfit=('underfit_burden','sum'),overfit=('overfit_burden','sum'),absres=('absres_burden','sum')).reset_index()


def pct(x): return f"{100*float(x):.1f}%" if math.isfinite(float(x)) else 'nan'


def write_report(out,summary,allocs,stage,xi,top):
    rows={r['fit']:r for r in summary.to_dict('records')}
    base=rows['targeted_v1']; compact=rows['source_absorber_compact']; audit=rows['audit_shapelet_ceiling']
    imp=1-compact['underfit_live_catch_fraction']/base['underfit_live_catch_fraction']
    total_imp=1-compact['underfit_live_fraction']/base['underfit_live_fraction']
    lines=[]
    lines.append('# Catch-edge Source Absorber Fit')
    lines.append('')
    lines.append('## Scope')
    lines.append('')
    lines.append('This pass tests a source-side catch-edge transient for the remaining negative radial null `Tkk` burden in the new freeze candidate. It uses the existing high-resolution point ledger and fits compact nonnegative source proxies to `bad_neg_Tkk_radial`.')
    lines.append('')
    lines.append('This is still a source-proxy diagnostic. It is not a matter-model construction and not an RSET calculation.')
    lines.append('')
    lines.append('## Result')
    lines.append('')
    lines.append('| fit | components | live packet underfit | live catch underfit | global underfit | live catch L1 residual |')
    lines.append('|---|---:|---:|---:|---:|---:|')
    for _,r in summary.iterrows():
        lines.append(f"| `{r['fit']}` | {int(r['components'])} | {pct(r['underfit_live_fraction'])} | {pct(r['underfit_live_catch_fraction'])} | {pct(r['underfit_total_fraction'])} | {pct(r['l1_live_catch_fraction'])} |")
    lines.append('')
    lines.append(f"The compact source absorber reduces live catch underfit by **{100*imp:.1f}%** relative to the previous targeted fit, and reduces total live packet underfit by **{100*total_imp:.1f}%**.")
    lines.append('')
    lines.append('## Interpretation')
    lines.append('')
    if compact['underfit_live_catch_fraction'] < 0.06:
        lines.append('The compact absorber is enough for a source-side finish-line claim in the reduced proxy sense. The remaining live catch underfit is below a rough 6% threshold, and the component remains localized to the catch-edge handoff rather than requiring a broad global layer.')
    else:
        lines.append('The compact absorber helps, but it is not enough for a strong source-side finish-line claim. It leaves a meaningful live catch residual, so the missing physics is still more structured than this basis captures.')
    lines.append('')
    lines.append('The audit shapelet ceiling shows how much fit quality is available if we allow many catch-local shapelets. It is included as a ceiling check, not as the preferred source story.')
    lines.append('')
    lines.append('## Dominant compact source-side components')
    lines.append('')
    a=allocs['source_absorber_compact'].copy()
    a=a[a.coefficient>1e-10].sort_values('allocated_live_catch_burden',ascending=False).head(12)
    lines.append('| component | live catch allocation | share of live catch actual | total allocation |')
    lines.append('|---|---:|---:|---:|')
    for _,r in a.iterrows():
        lines.append(f"| `{r['component']}` | {r['allocated_live_catch_burden']:.4g} | {100*r['share_live_catch_actual']:.1f}% | {r['allocated_total_burden']:.4g} |")
    lines.append('')
    lines.append('## Live catch packet-edge bins')
    lines.append('')
    lines.append('| xi bin | actual | predicted | underfit | overfit |')
    lines.append('|---|---:|---:|---:|---:|')
    for _,r in xi.iterrows():
        lines.append(f"| `{r['xi_bin']}` | {r['actual']:.4g} | {r['predicted']:.4g} | {r['underfit']:.4g} | {r['overfit']:.4g} |")
    lines.append('')
    lines.append('## Remaining top underfit points')
    lines.append('')
    lines.append('The largest remaining residuals are mostly non-passenger core/support catch points, with smaller live packet-edge residuals. That means the passenger-facing source story is close, while the infrastructure-side catch source still has unresolved structure.')
    lines.append('')
    lines.append('## Design consequence')
    lines.append('')
    lines.append('The source-side shock absorber should be treated as a timed inner-edge catch absorber with two faces: a packet-facing face and an infrastructure-facing core/edge face. The geometry-side lapse bump was too blunt; the source-side component is the cleaner interpretation.')
    lines.append('')
    lines.append('## Files')
    lines.append('')
    for f in ['source_absorber_fit_summary.csv','source_absorber_compact_allocations.csv','source_absorber_stage_region.csv','source_absorber_live_catch_xi_bins.csv','source_absorber_top_underfit_points.csv','source_absorber_point_residuals.csv','source_absorber_fit.py']:
        lines.append(f'- `{f}`')
    (out/'SOURCE_ABSORBER_FIT_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    df=pd.read_csv(INPUT).reset_index(drop=True)
    base=add_base_basis(df)
    targeted=pd.concat([base,add_targeted_v1_basis(df)],axis=1)
    compact=pd.concat([targeted,add_source_absorber_basis(df)],axis=1)
    audit=pd.concat([compact,add_audit_basis(df)],axis=1)
    fits={'base_proxy':base,'targeted_v1':targeted,'source_absorber_compact':compact,'audit_shapelet_ceiling':audit}
    summaries=[]; allocs={}; points={}
    for name,basis in fits.items():
        metrics,alloc,point=fit_nnls(df,basis)
        summaries.append({'fit':name,**metrics})
        allocs[name]=alloc; points[name]=point
        alloc.to_csv(OUT/f'{name}_allocations.csv',index=False)
    summary=pd.DataFrame(summaries); summary.to_csv(OUT/'source_absorber_fit_summary.csv',index=False)
    point=points['source_absorber_compact']; point.to_csv(OUT/'source_absorber_point_residuals.csv',index=False)
    summarize_stage(point).to_csv(OUT/'source_absorber_stage_region.csv',index=False)
    xi=xi_bins(point); xi.to_csv(OUT/'source_absorber_live_catch_xi_bins.csv',index=False)
    point.sort_values('underfit_burden',ascending=False).head(100).to_csv(OUT/'source_absorber_top_underfit_points.csv',index=False)
    # compact basis diagnostics
    diag=[]; live=df['inside_packet_live'].astype(bool); catch=df['stage'].astype(str)=='catch_rematch'
    basis=compact
    for col in basis.columns:
        arr=basis[col].to_numpy(float)
        diag.append({'basis':col,'nonzero_points':int((arr>1e-8).sum()),'live_nonzero_points':int(((arr>1e-8)&live).sum()),'catch_nonzero_points':int(((arr>1e-8)&catch).sum()),'live_catch_nonzero_points':int(((arr>1e-8)&live&catch).sum()),'max':float(arr.max()) if len(arr) else 0.0})
    pd.DataFrame(diag).to_csv(OUT/'source_absorber_basis_diagnostics.csv',index=False)
    write_report(OUT,summary,allocs,summarize_stage(point),xi,point.sort_values('underfit_burden',ascending=False).head(100))
    shutil.copyfile(__file__,OUT/'source_absorber_fit.py')
    meta={'input':str(INPUT),'rows':len(df),'fits':summary.to_dict('records')}
    (OUT/'source_absorber_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    zip_path=Path('/mnt/data/active_rail_source_absorber_bundle.zip')
    if zip_path.exists(): zip_path.unlink()
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
        for p in OUT.rglob('*'):
            if p.is_file(): z.write(p,p.relative_to(OUT.parent))
    print(summary.to_string(index=False))
    print('zip',zip_path)

if __name__=='__main__': main()
