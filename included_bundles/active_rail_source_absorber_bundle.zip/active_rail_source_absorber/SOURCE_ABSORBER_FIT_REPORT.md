# Catch-edge Source Absorber Fit

## Scope

This pass tests a source-side catch-edge transient for the remaining negative radial null `Tkk` burden in the new freeze candidate. It uses the existing high-resolution point ledger and fits compact nonnegative source proxies to `bad_neg_Tkk_radial`.

This is still a source-proxy diagnostic. It is not a matter-model construction and not an RSET calculation.

## Result

| fit | components | live packet underfit | live catch underfit | global underfit | live catch L1 residual |
|---|---:|---:|---:|---:|---:|
| `base_proxy` | 9 | 12.1% | 13.0% | 13.8% | 24.2% |
| `targeted_v1` | 16 | 9.4% | 9.9% | 13.1% | 20.0% |
| `source_absorber_compact` | 25 | 8.2% | 8.5% | 12.7% | 17.0% |
| `audit_shapelet_ceiling` | 73 | 5.3% | 5.3% | 11.8% | 10.2% |

The compact source absorber reduces live catch underfit by **13.9%** relative to the previous targeted fit, and reduces total live packet underfit by **13.3%**.

## Interpretation

The compact absorber helps, but it is not enough for a strong source-side finish-line claim. It leaves a meaningful live catch residual, so the missing physics is still more structured than this basis captures.

The audit shapelet ceiling shows how much fit quality is available if we allow many catch-local shapelets. It is included as a ceiling check, not as the preferred source story.

## Dominant compact source-side components

| component | live catch allocation | share of live catch actual | total allocation |
|---|---:|---:|---:|
| `catch_rematch_transient` | 23.94 | 37.5% | 54.51 |
| `shift_packet_carrier` | 22.22 | 34.8% | 22.59 |
| `radial_support_edge_shell` | 8.218 | 12.9% | 94.5 |
| `source_inner_edge_shear_pair` | 4.255 | 6.7% | 4.829 |
| `catch_outer_packet_edge_transient` | 3.189 | 5.0% | 3.189 |
| `lapse_cushion_sector` | 1.139 | 1.8% | 61.25 |
| `source_inner_edge_lapse_absorber` | 0.8105 | 1.3% | 1.086 |
| `cold_core_substrate` | 0 | 0.0% | 29.53 |
| `outer_quarantine_jacket` | 0 | 0.0% | 22.74 |
| `release_shift_transient` | 0 | 0.0% | 15.5 |
| `reset_decompression_infra` | 0 | 0.0% | 3.147 |
| `source_inner_edge_infra_face` | 0 | 0.0% | 1.46 |

## Live catch packet-edge bins

| xi bin | actual | predicted | underfit | overfit |
|---|---:|---:|---:|---:|
| `(-0.351, -0.25]` | 10.79 | 11.71 | 0.5046 | 1.426 |
| `(-0.25, -0.15]` | 8.308 | 8.645 | 0.5944 | 0.932 |
| `(-0.15, -0.05]` | 8.311 | 8.269 | 0.7788 | 0.7367 |
| `(-0.05, 0.05]` | 8.989 | 8.595 | 0.9541 | 0.5593 |
| `(0.05, 0.15]` | 8.77 | 8.297 | 0.9156 | 0.4426 |
| `(0.15, 0.25]` | 8.757 | 8.284 | 0.8865 | 0.4142 |
| `(0.25, 0.35]` | 9.92 | 9.969 | 0.8176 | 0.8659 |

## Remaining top underfit points

The largest remaining residuals are mostly non-passenger core/support catch points, with smaller live packet-edge residuals. That means the passenger-facing source story is close, while the infrastructure-side catch source still has unresolved structure.

## Design consequence

The source-side shock absorber should be treated as a timed inner-edge catch absorber with two faces: a packet-facing face and an infrastructure-facing core/edge face. The geometry-side lapse bump was too blunt; the source-side component is the cleaner interpretation.

## Files

- `source_absorber_fit_summary.csv`
- `source_absorber_compact_allocations.csv`
- `source_absorber_stage_region.csv`
- `source_absorber_live_catch_xi_bins.csv`
- `source_absorber_top_underfit_points.csv`
- `source_absorber_point_residuals.csv`
- `source_absorber_fit.py`