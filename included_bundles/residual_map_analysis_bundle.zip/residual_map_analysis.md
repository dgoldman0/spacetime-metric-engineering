# Residual Map Analysis

## Scope

This is a residual-localization pass over the locked reduced model. It uses the source-decomposition and targeted Tkk residual reports currently available in the repository. It does not retune the model.

The exact point-level residual CSVs inside the archived bundles were not directly available as extracted repository files, so this report is a report-level residual map rather than a fresh point-cloud reconstruction. It is still enough to answer the main gate question: whether the residual looks localized and source-component-like, or whether it looks like a hidden live-packet failure.

## Executive verdict

The residual story is mostly good.

The dominant live residual is still the radial-null `Tkk` catch/rematch channel. It localizes near the inner packet edge, roughly `l - s ≈ -Rpass`, rather than spreading uniformly across the passenger packet or reset/decompression. The broad source decomposition does not reveal a new global failure. The radial pressure channel is comparatively well behaved in the proxy fit. The angular/current/density channels have ugly global underfit numbers, but their live packet burdens are tiny or zero.

The result supports moving from residual maps to the compact absorber/control-law step, with one caveat: later, when the exact final runner is restored, rerun the point-level residual map at multiple grids to check for resolution-growth spikes.

## Source-channel residual map

| channel        |   actual_total_burden |   actual_live_packet_burden |   live_packet_fraction_pct |   global_underfit_pct |   live_underfit_pct |
|:---------------|----------------------:|----------------------------:|---------------------------:|----------------------:|--------------------:|
| neg_Tkk_radial |             317.3     |                  72.379     |                       22.8 |                  13.8 |                12.1 |
| abs_p_l        |              51.124   |                  13.832     |                       27.1 |                   4.2 |                 3.8 |
| abs_pOmega     |               2.8847  |                   0.0072147 |                        0.3 |                  86.9 |                53.7 |
| abs_j_l        |               0.26111 |                   0.0021128 |                        0.8 |                  64.5 |                20.5 |
| neg_rho_euler  |               0.34431 |                   0         |                        0   |                  97.7 |                 0   |
| neg_rho_packet |               0.52804 |                   0         |                        0   |                  98   |                 0   |

Read:

- `neg_Tkk_radial` is the live hard channel.
- `abs_p_l` is acceptable at this stage; live underfit is low.
- `abs_pOmega` and `abs_j_l` are poor global proxy fits but tiny live packet burdens.
- live negative density burden is zero in both Eulerian and packet-comoving density channels.

![Source underfit by channel](source_underfit_by_channel.png)

## Tkk catch/rematch residual map

The targeted Tkk proxy improved the live catch/rematch underfit from 13.0% to 9.9%. The modal absorber result from the final freeze package pushes the live catch/rematch underfit below the 5% finish-line threshold.

| fit                       |   live_packet_underfit_pct |   live_catch_rematch_underfit_pct |   global_underfit_pct |
|:--------------------------|---------------------------:|----------------------------------:|----------------------:|
| original_proxy            |                       12.1 |                              13   |                  13.8 |
| targeted_tkk_proxy        |                        9.4 |                               9.9 |                  13.1 |
| modal_absorber_finishline |                      nan   |                               4.9 |                 nan   |

![Tkk catch underfit reduction](tkk_catch_underfit_reduction.png)

## Tkk live-catch packet-coordinate map

The strongest actual burden and strongest underfit bin are on the inner packet side. This is the expected location for a catch-edge absorber.

| xi_bin         |   xi_mid |   actual_burden |   underfit_burden |   underfit_fraction_pct |
|:---------------|---------:|----------------:|------------------:|------------------------:|
| (-0.351,-0.25] |  -0.3005 |          10.79  |            1.262  |                11.696   |
| (-0.25,-0.15]  |  -0.2    |           8.308 |            0.5737 |                 6.90539 |
| (-0.15,-0.05]  |  -0.1    |           8.311 |            0.7998 |                 9.62339 |
| (-0.05,0.05]   |   0      |           8.989 |            0.9679 |                10.7676  |
| (0.05,0.15]    |   0.1    |           8.77  |            0.936  |                10.6727  |
| (0.15,0.25]    |   0.2    |           8.757 |            0.933  |                10.6543  |
| (0.25,0.35]    |   0.3    |           9.92  |            0.8563 |                 8.63206 |

![Tkk live catch xi burden map](tkk_live_catch_xi_burden_map.png)

![Tkk residual fraction heatmap](tkk_live_catch_residual_fraction_heatmap.png)

## Live catch allocation map

| component                         |   live_catch_allocation |   share_live_catch_actual_pct |
|:----------------------------------|------------------------:|------------------------------:|
| shift_packet_carrier              |                  24     |                          37.6 |
| catch_rematch_transient           |                  21.55  |                          33.8 |
| radial_support_edge_shell         |                   8.318 |                          13   |
| catch_inner_edge_shift_coupled    |                   5.654 |                           8.9 |
| catch_outer_packet_edge_transient |                   3.312 |                           5.2 |
| lapse_cushion_sector              |                   1.133 |                           1.8 |
| outer_quarantine_jacket           |                   0     |                           0   |
| cold_core_substrate               |                   0     |                           0   |

Read: the live catch burden is mostly explained by shift-carrier and catch/rematch transient components, with a smaller radial support-edge role and a specific inner-edge shift-coupled term. Cold core and outer quarantine do not carry live catch allocation in the targeted Tkk residual fit.

## Stage/channel map

| stage_region                                | neg_Tkk_radial         | abs_p_l               | abs_pOmega                             | neg_rho                                |
|:--------------------------------------------|:-----------------------|:----------------------|:---------------------------------------|:---------------------------------------|
| live catch/rematch inner packet edge        | HIGH-localized         | LOW-underfit          | tiny live burden                       | zero live burden                       |
| live catch/rematch packet center/outer edge | MODERATE               | LOW-underfit          | tiny live burden                       | zero live burden                       |
| release/shift fade                          | secondary leftover     | secondary leftover    | infrastructure/fade component          | infrastructure-only                    |
| standing support / outer jacket             | support-edge component | core/jacket component | dominant global underfit/fitting issue | dominant global underfit/fitting issue |
| reset/decompression                         | not main live issue    | not main live issue   | infrastructure component               | infrastructure component               |

## Red flags checked

| test                                    | status                          | evidence                                                                                                                                 |
|:----------------------------------------|:--------------------------------|:-----------------------------------------------------------------------------------------------------------------------------------------|
| Residual smeared through live packet    | not seen in report-level maps   | Tkk residual concentrated near inner packet edge during catch/rematch; density live burden zero; p_l live underfit low.                  |
| Catch-edge localized residual           | seen                            | Targeted Tkk report says remaining live Tkk underfit concentrates near l-s ≈ -Rpass.                                                     |
| Modal absorber work location            | matches expected location       | Dominant live-catch allocations are shift carrier, catch/rematch transient, radial support edge, and inner-edge shift-coupled component. |
| Whole-rail/global exotic layer demanded | not indicated                   | No new global failure reported; source story remains support/catch/release structured.                                                   |
| Angular/radiation sector residual       | yellow flag only                | pOmega and j_l global fit is poor, but live packet burdens are tiny.                                                                     |
| Resolution/grid spike diagnostic        | not closed by these maps        | Needs exact point-level residual CSV at multiple grids.                                                                                  |
| Diagonal/grazing-path stripe            | not supported by available data | Prior time-dependent/off-axis pass did not reveal hidden packet-norm failure, but exact residual point maps are still needed.            |

## Decision

The residual maps support the source-side absorber story.

What we wanted to see:

- localized live catch/rematch residual,
- packet-edge concentration,
- small radial-pressure underfit,
- no live density burden,
- no evidence that reset/decompression is hiding the live problem.

That is what the available maps show.

What remains open:

- exact point-level residual maps at multiple grids,
- exact modal-absorber residual map after replacing fitted modes with a compact ansatz,
- trans-Planckian-risk localization once source amplitudes are assigned physical scales.

## Next step

Proceed to compacting the modal absorber into an ansatz/control law. The source-shape should target the inner packet edge during catch/rematch, coupled to shift handoff, with a narrow support-edge envelope and smooth timing window. It should not become a broad global layer.
