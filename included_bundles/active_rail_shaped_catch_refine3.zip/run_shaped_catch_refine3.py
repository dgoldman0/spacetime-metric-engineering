#!/usr/bin/env python3
from pathlib import Path
import sys, json, zipfile
import pandas as pd
sys.path.insert(0, '/mnt/data/active_rail_bifurcation')
import run_shaped_catch_design as sd
import run_bifurcation_probe as rb
ar=rb.ar
OUT=Path('/mnt/data/active_rail_shaped_catch_refine3')
OUT.mkdir(parents=True, exist_ok=True)

def C(name,note,**kw): return ar.CaseDef(name, rb.ns_from_base(**kw), note)
cases=[
 C('base_R1p75','baseline R1.75 quarantine candidate'),
 C('shape_xm05_mj_w28','pure shaped catch fallback: center -0.05, width 0.28, minjerk', x_catch=-0.05,w_catch=0.28,catch_profile='minjerk'),
 C('locked_lead005_mj_w32','provisional shaped-lead branch: beta center -0.05, packet center 0.00, both minjerk width 0.32', beta_x_catch=-0.05,beta_w_catch=0.32,beta_profile='minjerk', packet_x_catch=0.00,packet_w_catch=0.32,packet_profile='minjerk'),
]
frames=[]
for c in cases:
 print('RUN',c.name,flush=True)
 frames.append(ar.compute_case(c,ns=25,nl=41,s_min=-0.55,s_max=1.35,l_min=-2.80,l_max=2.80,h_s=3.0e-3,h_l=3.0e-3,progress=False))
points=pd.concat(frames,ignore_index=True)
summary,compact,stage,top=ar.summarize_long(points)
decision=sd.build_decision(points,compact,stage)
radial_stage=stage[(stage['channel'].isin(['neg_Tkk_radial','abs_p_l'])) & (stage['weight']=='volume')]
points.to_csv(OUT/'refine3_point_ledger.csv',index=False)
summary.to_csv(OUT/'refine3_summary_long.csv',index=False)
compact.to_csv(OUT/'refine3_global_compact.csv',index=False)
stage.to_csv(OUT/'refine3_stage_summary.csv',index=False)
top.to_csv(OUT/'refine3_top_bad_points.csv',index=False)
decision.to_csv(OUT/'refine3_decision_table.csv',index=False)
radial_stage.to_csv(OUT/'refine3_radial_stage.csv',index=False)
md=sd.build_report(decision, radial_stage)
md=md.replace('# Shaped Catch Branch Design Probe','# Shaped Catch Branch Refine-3 Probe')
md += '\n## Refine-3 note\n\nThis is a higher-grid check of only the baseline, pure shaped fallback, and provisional locked-lead branch. Use it to decide the next candidate to promote.\n'
(OUT/'SHAPED_CATCH_REFINE3.md').write_text(md,encoding='utf-8')
(OUT/'refine3_metadata.json').write_text(json.dumps({'grid':{'ns':25,'nl':41},'cases':[{'name':c.name,'note':c.note,'params':vars(c.params)} for c in cases]},indent=2),encoding='utf-8')
zip_path=OUT.with_suffix('.zip')
if zip_path.exists(): zip_path.unlink()
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as zf:
 for p in sorted(OUT.iterdir()): zf.write(p,arcname=p.name)
 zf.write('/mnt/data/active_rail_bifurcation/run_shaped_catch_design.py',arcname='run_shaped_catch_design.py')
 zf.write('/mnt/data/active_rail_bifurcation/run_bifurcation_probe.py',arcname='run_bifurcation_probe.py')
 zf.write('/mnt/data/active_rail_point_ledger/active_rail_point_lifecycle_ledger.py',arcname='active_rail_point_lifecycle_ledger.py')
print(json.dumps({'ok':True,'outdir':str(OUT),'zip':str(zip_path),'rows':len(points),'best':decision.iloc[0]['case']},indent=2))
