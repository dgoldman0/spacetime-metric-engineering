# Shaped Catch Branch Refine-3 Probe

This probe keeps the previous bifurcation bundle frozen and starts the next branch design. It tests one-component shaped catch variants and tightly constrained beta/packet lead variants.

## Design read

Best scored case: `locked_lead005_mj_w32`.

The working design should be a shaped one-component catch unless a constrained lead case beats it while staying packet-safe. The key safety criterion is zero positive live packet-norm points.

## Decision table

| case                  |   decision_score |   radial_live_burden_score_ratio |   peak_score_ratio | live_packet_fraction__neg_Tkk_radial   | live_packet_fraction__abs_p_l   |   live_packet_burden__neg_Tkk_radial_ratio_vs_base |   live_packet_burden__abs_p_l_ratio_vs_base |   point_peak__neg_Tkk_radial_ratio_vs_base |   max_packet_norm_live |   positive_packet_norm_live |
|:----------------------|-----------------:|---------------------------------:|-------------------:|:---------------------------------------|:--------------------------------|---------------------------------------------------:|--------------------------------------------:|-------------------------------------------:|-----------------------:|----------------------------:|
| locked_lead005_mj_w32 |           0.8959 |                           0.8959 |             0.9851 | 26.14%                                 | 25.10%                          |                                             0.8399 |                                           1 |                                     0.9771 |                 -637.1 |                           0 |
| shape_xm05_mj_w28     |           0.8985 |                           0.8985 |             0.9966 | 26.22%                                 | 25.10%                          |                                             0.8439 |                                           1 |                                     0.9948 |                 -637.1 |                           0 |
| base_R1p75            |           1      |                           1      |             1      | 29.26%                                 | 25.10%                          |                                             1      |                                           1 |                                     1      |                 -637.1 |                           0 |

## Radial stage burden

### neg_Tkk_radial
| case                  |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:----------------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| locked_lead005_mj_w32 |            71.05 |           46.94 |            0 |                18.48 |                     0 |                     0 |
| shape_xm05_mj_w28     |             0    |          121.7  |            0 |                15.38 |                     0 |                     0 |
| base_R1p75            |            74.29 |           69.73 |            0 |                18.47 |                     0 |                     0 |

### abs_p_l
| case                  |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:----------------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| locked_lead005_mj_w32 |            8.344 |           10.51 |            0 |                2.853 |                     0 |                     0 |
| shape_xm05_mj_w28     |            0     |           19.57 |            0 |                2.136 |                     0 |                     0 |
| base_R1p75            |            8.344 |           10.51 |            0 |                2.853 |                     0 |                     0 |

## Branch recommendation

Promote a shaped catch branch with minimum-jerk catch, earlier center, and wider transition. Keep beta and packet rematch locked unless a constrained lead variant survives refinement with lower burden and no packet-norm failure.

## Refine-3 note

This is a higher-grid check of only the baseline, pure shaped fallback, and provisional locked-lead branch. Use it to decide the next candidate to promote.
