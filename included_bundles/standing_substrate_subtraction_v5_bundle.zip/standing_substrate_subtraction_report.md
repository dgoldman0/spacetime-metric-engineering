# Standing Substrate Subtraction at V=5

## Scope

This pass uses the exact field definitions from the uploaded `radial_softening_probe.py` artifact and the frozen tuned parameters at `V = 5`, `w_th = 0.569`, `eta_N = 2.0`.

Two subtraction baselines were tested:

1. **Time-matched beta-off substrate**: same lapse, spatial geometry, support shell, angular jacket, and decompression schedule, but with the transport shift set to `beta = 0`. This isolates the direct shift/handoff increment against the same standing geometry.
2. **Static-ready substrate**: ready support geometry with `q = 1`, angular jacket ready, `beta = 0`, and no time variation. This subtracts a static plant and therefore includes decompression/preparation differences in the delta.

## Main finding

The earlier high live-packet `rho` fraction is mostly standing substrate curvature. The live ADM `rho` ledger has `27.06%` of absolute `rho` in the live packet, but the time-matched beta-off subtraction changes total `rho` by only `0.000093%` of the live global `rho` burden. Its packet-local part is only `0.000295%` of the original live packet `rho` burden.

That is the good result: the absolute `rho` packet burden largely subtracts away as standing geometry. The bad-looking number is fractional: `86.13%` of the tiny shift-induced `delta rho` lies in the live packet. That fraction is high because the total shift-induced `delta rho` is extremely small, not because there is a large packet-filling energy-density demand.

## Momentum result

For `j_l`, the time-matched beta-off subtraction is more meaningful because the shift directly drives momentum flow. The shift-induced `delta j_l` is about `0.98%` of the live global `j_l` burden, and about `11.75%` of the live packet `j_l` burden. Most of that shift-induced packet momentum appears during catch/rematch, which is consistent with the handoff story.

## Focus table

| variant                       | field   |   global_abs_burden |   live_packet_abs_burden |   live_packet_abs_fraction |   packet_edge_abs_fraction |   packet_core_abs_fraction |   catch_live_packet_abs_fraction |   release_live_packet_abs_fraction |   global_neg_burden |   live_packet_neg_burden |   live_packet_neg_fraction_of_neg |   live_packet_peak_abs |   global_peak_abs |   global_abs_fraction_of_live_global |   live_packet_abs_fraction_of_live_packet_live |
|:------------------------------|:--------|--------------------:|-------------------------:|---------------------------:|---------------------------:|---------------------------:|---------------------------------:|-----------------------------------:|--------------------:|-------------------------:|----------------------------------:|-----------------------:|------------------:|-------------------------------------:|-----------------------------------------------:|
| delta_vs_betaoff_time_matched | rho     |         4.63484e-05 |              3.99195e-05 |                  0.861292  |                  0.441873  |                  0.419419  |                        0.443427  |                          0.669019  |         4.56493e-05 |              3.92411e-05 |                       0.859621    |            2.01274e-07 |       2.01274e-07 |                          9.28306e-07 |                                    2.95467e-06 |
| delta_vs_betaoff_time_matched | j_l     |         0.0214467   |              0.0201281   |                  0.938516  |                  0.433323  |                  0.505193  |                        0.903966  |                          0.115788  |         1.59806e-18 |              0           |                       0           |            2.58064e-05 |       2.58064e-05 |                          0.00982965  |                                    0.117526    |
| delta_vs_static_ready         | rho     |         0.235095    |              0.0135004   |                  0.0574254 |                  0.0281985 |                  0.0292268 |                        0.0358662 |                          0.0385862 |         0.11268     |              0           |                       0           |            9.62062e-05 |       0.00716307  |                          0.00470868  |                                    0.000999243 |
| delta_vs_static_ready         | j_l     |         2.18184     |              0.171264    |                  0.0784954 |                  0.0383577 |                  0.0401378 |                        0.0282771 |                          0.0668603 |         1.0802      |              0.000154402 |                       0.000142939 |            0.00377891  |       0.0204849   |                          1           |                                    1           |

## Top time-matched stage/region burdens

| variant                       | field   | stage               | region        |   abs_burden |   fraction_of_global_abs |    peak_abs |   points |
|:------------------------------|:--------|:--------------------|:--------------|-------------:|-------------------------:|------------:|---------:|
| delta_vs_betaoff_time_matched | j_l     | catch_rematch       | core_throat   |  0.0206114   |              0.961053    | 2.58064e-05 |     5820 |
| delta_vs_betaoff_time_matched | j_l     | catch_rematch       | live_packet   |  0.0193871   |              0.903966    | 2.58064e-05 |     1802 |
| delta_vs_betaoff_time_matched | rho     | release_shift_fade  | live_packet   |  3.1008e-05  |              0.669019    | 2.01274e-07 |     1293 |
| delta_vs_betaoff_time_matched | rho     | release_shift_fade  | core_throat   |  3.08751e-05 |              0.666153    | 2.01274e-07 |     4171 |
| delta_vs_betaoff_time_matched | rho     | catch_rematch       | core_throat   |  2.30258e-05 |              0.496797    | 1.32964e-07 |     5820 |
| delta_vs_betaoff_time_matched | rho     | catch_rematch       | live_packet   |  2.05522e-05 |              0.443427    | 1.32964e-07 |     1802 |
| delta_vs_betaoff_time_matched | j_l     | release_shift_fade  | core_throat   |  0.00258365  |              0.120468    | 1.01499e-05 |     4171 |
| delta_vs_betaoff_time_matched | j_l     | release_shift_fade  | live_packet   |  0.00248327  |              0.115788    | 1.01499e-05 |     1293 |
| delta_vs_betaoff_time_matched | rho     | release_shift_fade  | support_shell |  1.82531e-06 |              0.0393824   | 2.01199e-07 |     3612 |
| delta_vs_betaoff_time_matched | rho     | post_release_buffer | support_shell |  1.39159e-06 |              0.0300245   | 1.70984e-07 |     1848 |
| delta_vs_betaoff_time_matched | rho     | post_release_buffer | core_throat   |  1.31231e-06 |              0.028314    | 1.42588e-07 |     2134 |
| delta_vs_betaoff_time_matched | j_l     | release_shift_fade  | support_shell |  7.54471e-05 |              0.00351789  | 8.87766e-06 |     3612 |
| delta_vs_betaoff_time_matched | rho     | reset_decompression | support_shell |  1.10616e-07 |              0.00238662  | 5.3757e-08  |     1176 |
| delta_vs_betaoff_time_matched | j_l     | post_release_buffer | support_shell |  1.8171e-05  |              0.000847265 | 3.34858e-06 |     1848 |
| delta_vs_betaoff_time_matched | j_l     | post_release_buffer | core_throat   |  9.59341e-06 |              0.000447314 | 2.25549e-06 |     2134 |
| delta_vs_betaoff_time_matched | rho     | reset_decompression | core_throat   |  1.42488e-08 |              0.000307427 | 5.61884e-08 |     1358 |

## Top static-ready stage/region burdens

| variant               | field   | stage               | region        |   abs_burden |   fraction_of_global_abs |    peak_abs |   points |
|:----------------------|:--------|:--------------------|:--------------|-------------:|-------------------------:|------------:|---------:|
| delta_vs_static_ready | j_l     | release_shift_fade  | support_shell |    0.515394  |                0.23622   | 0.00840929  |     3612 |
| delta_vs_static_ready | j_l     | release_shift_fade  | core_throat   |    0.365062  |                0.167319  | 0.00259001  |     4171 |
| delta_vs_static_ready | j_l     | post_release_buffer | support_shell |    0.332435  |                0.152365  | 0.0137768   |     1848 |
| delta_vs_static_ready | j_l     | catch_rematch       | support_shell |    0.297711  |                0.13645   | 0.0046509   |     5040 |
| delta_vs_static_ready | rho     | release_shift_fade  | core_throat   |    0.0315536 |                0.134216  | 0.000118714 |     4171 |
| delta_vs_static_ready | rho     | release_shift_fade  | support_shell |    0.0292427 |                0.124387  | 0.00396913  |     3612 |
| delta_vs_static_ready | j_l     | post_release_buffer | core_throat   |    0.268348  |                0.122992  | 0.0098652   |     2134 |
| delta_vs_static_ready | rho     | release_shift_fade  | outer_shell   |    0.0277684 |                0.118116  | 0.00465164  |     2580 |
| delta_vs_static_ready | rho     | post_release_buffer | support_shell |    0.0264182 |                0.112372  | 0.00662915  |     1848 |
| delta_vs_static_ready | rho     | post_release_buffer | outer_shell   |    0.0253101 |                0.107659  | 0.00681319  |     1320 |
| delta_vs_static_ready | rho     | catch_rematch       | core_throat   |    0.0245833 |                0.104567  | 3.0298e-05  |     5820 |
| delta_vs_static_ready | j_l     | catch_rematch       | core_throat   |    0.205118  |                0.0940117 | 0.000480853 |     5820 |
| delta_vs_static_ready | rho     | reset_decompression | core_throat   |    0.0200739 |                0.0853863 | 0.00247201  |     1358 |
| delta_vs_static_ready | j_l     | reset_decompression | support_shell |    0.185719  |                0.0851205 | 0.0204849   |     1176 |
| delta_vs_static_ready | rho     | reset_decompression | support_shell |    0.0186949 |                0.0795209 | 0.00716307  |     1176 |
| delta_vs_static_ready | rho     | post_release_buffer | core_throat   |    0.018011  |                0.0766118 | 0.000604526 |     2134 |

## Verdict

The ADM scaffold survives standing-substrate subtraction at V=5.

The key correction is interpretive: **absolute `rho` in the live packet is mostly standing support/throat curvature**, while the service-induced `delta rho` is tiny. The actual live-service signal is more visible in `delta j_l`, and it concentrates in the packet/catch handoff region rather than appearing as a broad source failure. This supports moving forward, with one caution: the ADM service ledger should distinguish absolute source burden from incremental service burden every time.

## Next step

Run the same subtraction at the V=10 edge and compare whether the catch/rematch `delta j_l` and any packet-edge `delta rho` scale gently or sharply.
