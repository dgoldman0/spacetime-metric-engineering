# Preserved Catch/Rematch Bifurcation Note

This bundle freezes the bifurcation finding before moving into shaped-catch design.

Key note preserved:

```text
The system wants the support-side catch earlier, but the packet rematch cannot lag freely behind it.
```

Operational meaning:

- Early support-side catch is attractive because it lowers live negative radial-null burden.
- A freely lagging packet rematch can break packet safety.
- Spatial broadening alone tends to relocate burden and can raise peaks.
- The next branch should use a shaped catch or a tightly constrained lead, not an unconstrained two-component split.

The previous full point-level ledger bundle is intentionally not modified here.
