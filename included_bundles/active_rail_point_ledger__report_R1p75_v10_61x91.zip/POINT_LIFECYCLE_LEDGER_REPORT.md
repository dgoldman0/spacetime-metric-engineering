# Point-Level Active Rail Lifecycle Ledger

This report recomputes a raw `(s,l)` demanded-source ledger and then applies lifecycle masks.
It is a prescribed-geometry Einstein-source diagnostic, not a matter model or physical-source proof.

Grid: `61 x 91` points per case.

## Cases

| case             |   V |   Rth |   ROmega |   w_th |   wOmega |   aOmega | note                                         |
|:-----------------|----:|------:|---------:|-------:|---------:|---------:|:---------------------------------------------|
| R1p75_quarantine |  10 |  1.75 |     1.75 |   0.35 |      1.4 |      0.2 | default quarantined active rail v2 candidate |

## Compact global volume-weighted summary

| case             | channel        | description                      |   total_burden |   live_packet_burden | live_packet_fraction   |   point_peak |   live_packet_point_peak |
|:-----------------|:---------------|:---------------------------------|---------------:|---------------------:|:-----------------------|-------------:|-------------------------:|
| R1p75_quarantine | neg_rho_euler  | negative Eulerian density        |         0.3831 |             0        | 0.0%                   |      0.01621 |                0         |
| R1p75_quarantine | neg_rho_packet | negative packet-comoving density |         0.6289 |             0        | 0.0%                   |      0.7239  |                0         |
| R1p75_quarantine | neg_Tkk_radial | negative radial null contraction |       454.1    |           122.6      | 27.0%                  |      0.1682  |                0.1484    |
| R1p75_quarantine | abs_p_l        | radial pressure magnitude        |        68.42   |            17.1      | 25.0%                  |      0.01565 |                0.009532  |
| R1p75_quarantine | abs_pOmega     | angular pressure magnitude       |         4.049  |             0.007479 | 0.2%                   |      0.1682  |                9.428e-05 |
| R1p75_quarantine | abs_j_l        | radial current magnitude         |         0.1969 |             0.001785 | 0.9%                   |      0.00802 |                8.086e-05 |

## Stage reading: live packet burden by stage

### neg_Tkk_radial

| case             |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:-----------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| R1p75_quarantine |            40.34 |           65.06 |            0 |                17.16 |                     0 |                     0 |

### abs_p_l

| case             |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:-----------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| R1p75_quarantine |            4.326 |            10.2 |            0 |                2.572 |                     0 |                     0 |

### abs_pOmega

| case             |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:-----------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| R1p75_quarantine |        0.0009298 |        0.002395 |            0 |             0.004154 |                     0 |                     0 |

### abs_j_l

| case             |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:-----------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| R1p75_quarantine |        2.532e-05 |       9.941e-05 |            0 |             0.001661 |                     0 |                     0 |

## Top live-packet bad points

| case             | channel        |   rank |       s |        l | stage          | region            |   badness |   volume_burden |
|:-----------------|:---------------|-------:|--------:|---------:|:---------------|:------------------|----------:|----------------:|
| R1p75_quarantine | abs_p_l        |      1 | -0.35   |  0       | entry_precatch | packet_in_support |  0.009522 |         0.06363 |
| R1p75_quarantine | abs_p_l        |      2 | -0.35   | -0.06222 | entry_precatch | packet_in_support |  0.009511 |         0.06361 |
| R1p75_quarantine | abs_p_l        |      4 | -0.3167 |  0       | entry_precatch | packet_in_support |  0.009522 |         0.06357 |
| R1p75_quarantine | abs_p_l        |      5 | -0.35   | -0.1244  | entry_precatch | packet_in_support |  0.009478 |         0.06357 |
| R1p75_quarantine | abs_p_l        |      7 | -0.3167 | -0.06222 | entry_precatch | packet_in_support |  0.009511 |         0.06356 |
| R1p75_quarantine | neg_Tkk_radial |      3 | -0.35   | -0.6844  | entry_precatch | packet_in_support |  0.1484   |         1.082   |
| R1p75_quarantine | neg_Tkk_radial |      4 | -0.2833 | -0.6222  | entry_precatch | packet_in_support |  0.1451   |         1.043   |
| R1p75_quarantine | neg_Tkk_radial |      5 | -0.2167 | -0.56    | entry_precatch | packet_in_support |  0.1397   |         0.9845  |
| R1p75_quarantine | neg_Tkk_radial |      7 | -0.15   | -0.4978  | catch_rematch  | packet_in_support |  0.1324   |         0.9069  |
| R1p75_quarantine | neg_Tkk_radial |      8 | -0.3167 | -0.6222  | entry_precatch | packet_in_support |  0.1165   |         0.839   |

## Outputs

- `point_lifecycle_ledger.csv`
- `point_lifecycle_summary_long.csv`
- `point_lifecycle_global_compact.csv`
- `point_lifecycle_stage_summary.csv`
- `point_lifecycle_top_bad_points.csv`
