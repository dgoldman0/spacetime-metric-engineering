# Catch/Rematch Bifurcation Probe

This is a point-level demanded-source diagnostic for deciding whether the catch/rematch problem behaves like a one-component shaping problem or a two-component split problem.

Grid: `21 x 33` per case.  Run kind: `refine`.

## Cases

| case                       | note                                             |
|:---------------------------|:-------------------------------------------------|
| base_R1p75                 | baseline R1.75 quarantine candidate              |
| shape_minjerk_w40          | best one-component shaping candidate from screen |
| split_spatial_broad75_R120 | spatial split with wider broad component         |
| split_broad75_minjerk_w32  | strong spatial split plus wider minjerk catch    |

## Decision table

| case                       |   decision_score |   radial_live_burden_score_ratio | live_packet_fraction__neg_Tkk_radial   | live_packet_fraction__abs_p_l   |   live_packet_burden__neg_Tkk_radial_ratio_vs_base |   live_packet_burden__abs_p_l_ratio_vs_base |   point_peak__neg_Tkk_radial_ratio_vs_base |   point_peak__abs_p_l_ratio_vs_base |   max_packet_norm_live |   positive_packet_norm_live |
|:---------------------------|-----------------:|---------------------------------:|:---------------------------------------|:--------------------------------|---------------------------------------------------:|--------------------------------------------:|-------------------------------------------:|------------------------------------:|-----------------------:|----------------------------:|
| split_broad75_minjerk_w32  |           0.9651 |                           0.9651 | 22.14%                                 | 25.05%                          |                                             0.9303 |                                           1 |                                     1.07   |                                   1 |                 -713.3 |                           0 |
| split_spatial_broad75_R120 |           0.9691 |                           0.9691 | 21.26%                                 | 25.05%                          |                                             0.9381 |                                           1 |                                     1.169  |                                   1 |                 -713.3 |                           0 |
| shape_minjerk_w40          |           0.9931 |                           0.9931 | 28.92%                                 | 25.05%                          |                                             0.9862 |                                           1 |                                     0.9959 |                                   1 |                 -713.3 |                           0 |
| base_R1p75                 |           1      |                           1      | 29.12%                                 | 25.05%                          |                                             1      |                                           1 |                                     1      |                                   1 |                 -713.3 |                           0 |

## Radial stage burden

### neg_Tkk_radial
| case                       |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:---------------------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| split_broad75_minjerk_w32  |             0    |          134.1  |            0 |                4.848 |                     0 |                     0 |
| split_spatial_broad75_R120 |            68.42 |           52.91 |            0 |               18.79  |                     0 |                     0 |
| shape_minjerk_w40          |             0    |          146.2  |            0 |                1.127 |                     0 |                     0 |
| base_R1p75                 |            73.91 |           56.62 |            0 |               18.83  |                     0 |                     0 |

### abs_p_l
| case                       |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:---------------------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| split_broad75_minjerk_w32  |            0     |           19.17 |            0 |               0.5934 |                     0 |                     0 |
| split_spatial_broad75_R120 |            7.802 |            8.99 |            0 |               2.97   |                     0 |                     0 |
| shape_minjerk_w40          |            0     |           19.63 |            0 |               0.134  |                     0 |                     0 |
| base_R1p75                 |            7.802 |            8.99 |            0 |               2.97   |                     0 |                     0 |

## Initial reading

Best score in this run: `split_broad75_minjerk_w32`.

A shaping diagnosis is supported when widened/smoothed one-component cases improve continuously and remain competitive with split cases. A split diagnosis is supported when split cases produce a discontinuous improvement in live radial burden or peak burden without packet-norm failure.
