# Point-Level Active Rail Lifecycle Ledger

This report recomputes a raw `(s,l)` demanded-source ledger and then applies lifecycle masks.
It is a prescribed-geometry Einstein-source diagnostic, not a matter model or physical-source proof.

Grid: `25 x 41` points per case.

## Cases

| case                |   V |   Rth |   ROmega |   w_th |   wOmega |   aOmega | note                                                   |
|:--------------------|----:|------:|---------:|-------:|---------:|---------:|:-------------------------------------------------------|
| freeze_like_minjerk |  10 |  1.25 |     1.25 |   0.12 |      0.7 |     0.35 | v1 freeze-like soft angular jacket with minimum-jerk q |
| R1p75_quarantine    |  10 |  1.75 |     1.75 |   0.35 |      1.4 |     0.2  | default quarantined active rail v2 candidate           |
| R2p0_quarantine     |  10 |  2    |     2    |   0.35 |      1.6 |     0.2  | higher-quarantine stress branch                        |

## Compact global volume-weighted summary

| case                | channel        | description                      |   total_burden |   live_packet_burden | live_packet_fraction   |   point_peak |   live_packet_point_peak |
|:--------------------|:---------------|:---------------------------------|---------------:|---------------------:|:-----------------------|-------------:|-------------------------:|
| R1p75_quarantine    | neg_rho_euler  | negative Eulerian density        |        0.3985  |             0        | 0.0%                   |     0.01621  |                0         |
| R1p75_quarantine    | neg_rho_packet | negative packet-comoving density |        0.4797  |             0        | 0.0%                   |     0.1021   |                0         |
| R1p75_quarantine    | neg_Tkk_radial | negative radial null contraction |      466.6     |           123.5      | 26.5%                  |     0.1682   |                0.1037    |
| R1p75_quarantine    | abs_p_l        | radial pressure magnitude        |       70.5     |            17.51     | 24.8%                  |     0.01565  |                0.009531  |
| R1p75_quarantine    | abs_pOmega     | angular pressure magnitude       |        4.184   |             0.007169 | 0.2%                   |     0.1682   |                6.937e-05 |
| R1p75_quarantine    | abs_j_l        | radial current magnitude         |        0.208   |             0.001427 | 0.7%                   |     0.007957 |                3.737e-05 |
| R2p0_quarantine     | neg_rho_euler  | negative Eulerian density        |        0.3806  |             0        | 0.0%                   |     0.01398  |                0         |
| R2p0_quarantine     | neg_rho_packet | negative packet-comoving density |        0.4613  |             0        | 0.0%                   |     0.08951  |                0         |
| R2p0_quarantine     | neg_Tkk_radial | negative radial null contraction |      568.4     |           127        | 22.4%                  |     0.1332   |                0.08025   |
| R2p0_quarantine     | abs_p_l        | radial pressure magnitude        |       84.7     |            17.94     | 21.2%                  |     0.01277  |                0.007297  |
| R2p0_quarantine     | abs_pOmega     | angular pressure magnitude       |        5.115   |             0.009514 | 0.2%                   |     0.163    |                6.871e-05 |
| R2p0_quarantine     | abs_j_l        | radial current magnitude         |        0.2429  |             0.001375 | 0.6%                   |     0.006529 |                2.325e-05 |
| freeze_like_minjerk | neg_rho_euler  | negative Eulerian density        |        0.4924  |             0        | 0.0%                   |     0.02432  |                0         |
| freeze_like_minjerk | neg_rho_packet | negative packet-comoving density |        0.5475  |             0        | 0.0%                   |     0.1514   |                0         |
| freeze_like_minjerk | neg_Tkk_radial | negative radial null contraction |      350       |           142.3      | 40.6%                  |     0.2449   |                0.1663    |
| freeze_like_minjerk | abs_p_l        | radial pressure magnitude        |       60.2     |            18.23     | 30.3%                  |     0.02929  |                0.01401   |
| freeze_like_minjerk | abs_pOmega     | angular pressure magnitude       |        5.882   |             0.01398  | 0.2%                   |     1.003    |                0.004779  |
| freeze_like_minjerk | abs_j_l        | radial current magnitude         |        0.07349 |             0.001179 | 1.6%                   |     0.01055  |                0.000115  |

## Stage reading: live packet burden by stage

### neg_Tkk_radial

| case                |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:--------------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| R1p75_quarantine    |            46.43 |           59.5  |            0 |                17.52 |                     0 |                     0 |
| R2p0_quarantine     |            47.73 |           61.24 |            0 |                18.07 |                     0 |                     0 |
| freeze_like_minjerk |            53.13 |           72.77 |            0 |                16.36 |                     0 |                     0 |

### abs_p_l

| case                |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:--------------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| R1p75_quarantine    |            5.292 |           9.441 |            0 |                2.775 |                     0 |                     0 |
| R2p0_quarantine     |            5.413 |           9.642 |            0 |                2.886 |                     0 |                     0 |
| freeze_like_minjerk |            5.525 |           9.83  |            0 |                2.872 |                     0 |                     0 |

### abs_pOmega

| case                |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:--------------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| R1p75_quarantine    |         0.001106 |        0.002119 |            0 |             0.003945 |                     0 |                     0 |
| R2p0_quarantine     |         0.001411 |        0.002676 |            0 |             0.005427 |                     0 |                     0 |
| freeze_like_minjerk |         0.00072  |        0.001433 |            0 |             0.01182  |                     0 |                     0 |

### abs_j_l

| case                |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:--------------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| R1p75_quarantine    |        3.161e-05 |       8.815e-05 |            0 |             0.001307 |                     0 |                     0 |
| R2p0_quarantine     |        3.071e-05 |       8.644e-05 |            0 |             0.001258 |                     0 |                     0 |
| freeze_like_minjerk |        3.255e-05 |       9.659e-05 |            0 |             0.00105  |                     0 |                     0 |

## Top live-packet bad points

| case                | channel        |   rank |        s |     l | stage          | region            |   badness |   volume_burden |
|:--------------------|:---------------|-------:|---------:|------:|:---------------|:------------------|----------:|----------------:|
| R1p75_quarantine    | abs_p_l        |      1 | -0.35    |  0    | entry_precatch | packet_in_support |  0.009522 |          0.3579 |
| R1p75_quarantine    | abs_p_l        |      2 | -0.35    | -0.14 | entry_precatch | packet_in_support |  0.009466 |          0.3575 |
| R1p75_quarantine    | abs_p_l        |      4 | -0.2667  |  0    | entry_precatch | packet_in_support |  0.009522 |          0.3564 |
| R1p75_quarantine    | abs_p_l        |      5 | -0.35    | -0.28 | entry_precatch | packet_in_support |  0.009305 |          0.3561 |
| R1p75_quarantine    | abs_p_l        |      7 | -0.2667  | -0.14 | entry_precatch | packet_in_support |  0.009467 |          0.356  |
| R1p75_quarantine    | neg_Tkk_radial |      3 | -0.2667  | -0.56 | entry_precatch | packet_in_support |  0.1037   |          4.139  |
| R1p75_quarantine    | neg_Tkk_radial |      5 | -0.1     | -0.42 | catch_rematch  | packet_in_support |  0.0999   |          3.726  |
| R1p75_quarantine    | neg_Tkk_radial |      7 | -0.01667 |  0.28 | catch_rematch  | packet_in_support |  0.09535  |          3.325  |
| R1p75_quarantine    | neg_Tkk_radial |      8 | -0.2667  | -0.14 | entry_precatch | packet_in_support |  0.08816  |          3.315  |
| R1p75_quarantine    | neg_Tkk_radial |      9 | -0.35    | -0.28 | entry_precatch | packet_in_support |  0.08648  |          3.31   |
| R2p0_quarantine     | abs_p_l        |      1 | -0.35    |  0    | entry_precatch | packet_in_support |  0.00729  |          0.3646 |
| R2p0_quarantine     | abs_p_l        |      2 | -0.35    | -0.14 | entry_precatch | packet_in_support |  0.007258 |          0.3645 |
| R2p0_quarantine     | abs_p_l        |      4 | -0.35    | -0.28 | entry_precatch | packet_in_support |  0.007162 |          0.3639 |
| R2p0_quarantine     | abs_p_l        |      6 | -0.2667  |  0    | entry_precatch | packet_in_support |  0.00729  |          0.3631 |
| R2p0_quarantine     | abs_p_l        |      7 | -0.2667  | -0.14 | entry_precatch | packet_in_support |  0.007258 |          0.3629 |
| R2p0_quarantine     | neg_Tkk_radial |      3 | -0.2667  | -0.56 | entry_precatch | packet_in_support |  0.08025  |          4.237  |
| R2p0_quarantine     | neg_Tkk_radial |      6 | -0.1     | -0.42 | catch_rematch  | packet_in_support |  0.07568  |          3.738  |
| R2p0_quarantine     | neg_Tkk_radial |      7 | -0.2667  | -0.14 | entry_precatch | packet_in_support |  0.06865  |          3.433  |
| R2p0_quarantine     | neg_Tkk_radial |      8 | -0.35    | -0.28 | entry_precatch | packet_in_support |  0.06752  |          3.431  |
| R2p0_quarantine     | neg_Tkk_radial |      9 | -0.01667 |  0.28 | catch_rematch  | packet_in_support |  0.07377  |          3.414  |
| freeze_like_minjerk | abs_p_l        |      1 | -0.35    |  0    | entry_precatch | packet_in_support |  0.01399  |          0.3712 |
| freeze_like_minjerk | abs_p_l        |      2 | -0.35    | -0.14 | entry_precatch | packet_in_support |  0.01384  |          0.3712 |
| freeze_like_minjerk | abs_p_l        |      4 | -0.35    | -0.28 | entry_precatch | packet_in_support |  0.01342  |          0.3712 |
| freeze_like_minjerk | abs_p_l        |      6 | -0.35    | -0.42 | entry_precatch | packet_in_support |  0.0128   |          0.3711 |
| freeze_like_minjerk | abs_p_l        |      8 | -0.35    | -0.56 | entry_precatch | packet_in_support |  0.01206  |          0.3708 |
| freeze_like_minjerk | neg_Tkk_radial |      4 | -0.1     | -0.42 | catch_rematch  | packet_in_support |  0.1569   |          4.338  |
| freeze_like_minjerk | neg_Tkk_radial |      5 | -0.1833  |  0    | entry_precatch | packet_in_support |  0.1663   |          4.333  |
| freeze_like_minjerk | neg_Tkk_radial |      6 | -0.2667  | -0.14 | entry_precatch | packet_in_support |  0.16     |          4.274  |
| freeze_like_minjerk | neg_Tkk_radial |      7 | -0.35    | -0.14 | entry_precatch | packet_in_support |  0.1563   |          4.192  |
| freeze_like_minjerk | neg_Tkk_radial |      8 | -0.1     |  0.14 | catch_rematch  | packet_in_support |  0.1633   |          4.179  |

## Outputs

- `point_lifecycle_ledger.csv`
- `point_lifecycle_summary_long.csv`
- `point_lifecycle_global_compact.csv`
- `point_lifecycle_stage_summary.csv`
- `point_lifecycle_top_bad_points.csv`
