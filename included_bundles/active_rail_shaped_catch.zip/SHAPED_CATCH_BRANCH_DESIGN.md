# Shaped Catch Branch Design Probe

This probe keeps the previous bifurcation bundle frozen and starts the next branch design. It tests one-component shaped catch variants and tightly constrained beta/packet lead variants.

## Design read

Best scored case: `locked_lead005_mj_w32`.

The working design should be a shaped one-component catch unless a constrained lead case beats it while staying packet-safe. The key safety criterion is zero positive live packet-norm points.

## Decision table

| case                  |   decision_score |   radial_live_burden_score_ratio |   peak_score_ratio | live_packet_fraction__neg_Tkk_radial   | live_packet_fraction__abs_p_l   |   live_packet_burden__neg_Tkk_radial_ratio_vs_base |   live_packet_burden__abs_p_l_ratio_vs_base |   point_peak__neg_Tkk_radial_ratio_vs_base |   max_packet_norm_live |   positive_packet_norm_live |
|:----------------------|-----------------:|---------------------------------:|-------------------:|:---------------------------------------|:--------------------------------|---------------------------------------------------:|--------------------------------------------:|-------------------------------------------:|-----------------------:|----------------------------:|
| locked_lead005_mj_w32 |           0.9001 |                           0.9001 |             0.9726 | 24.97%                                 | 24.84%                          |                                             0.8463 |                                           1 |                                     0.9579 |                 -996.6 |                           0 |
| shape_xm05_mj_w28     |           0.9029 |                           0.9029 |             0.9891 | 25.05%                                 | 24.84%                          |                                             0.8507 |                                           1 |                                     0.9832 |                 -996.6 |                           0 |
| shape_x000_tanh_w32   |           0.921  |                           0.921  |             0.9653 | 25.60%                                 | 24.84%                          |                                             0.8784 |                                           1 |                                     0.9466 |                 -994.2 |                           0 |
| shape_x000_mj_w32     |           0.9239 |                           0.9239 |             0.9868 | 25.68%                                 | 24.84%                          |                                             0.8829 |                                           1 |                                     0.9796 |                 -996.6 |                           0 |
| shape_x000_mj_w28     |           0.9262 |                           0.9262 |             0.9977 | 25.74%                                 | 24.84%                          |                                             0.8865 |                                           1 |                                     0.9964 |                 -996.6 |                           0 |
| shape_x005_mj_w32     |           0.9479 |                           0.9479 |             0.9955 | 26.36%                                 | 24.84%                          |                                             0.9199 |                                           1 |                                     0.9931 |                 -996.6 |                           0 |
| base_R1p75            |           1      |                           1      |             1      | 27.76%                                 | 24.84%                          |                                             1      |                                           1 |                                     1      |                 -996.6 |                           0 |

## Radial stage burden

### neg_Tkk_radial
| case                  |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:----------------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| locked_lead005_mj_w32 |            76.17 |           39.19 |            0 |               17.02  |                     0 |                     0 |
| shape_xm05_mj_w28     |             0    |          116    |            0 |               17.09  |                     0 |                     0 |
| shape_x000_tanh_w32   |             0    |          129.8  |            0 |                7.646 |                     0 |                     0 |
| shape_x000_mj_w32     |             0    |          130.4  |            0 |                7.662 |                     0 |                     0 |
| shape_x000_mj_w28     |             0    |          127.4  |            0 |               11.3   |                     0 |                     0 |
| shape_x005_mj_w32     |             0    |          136.2  |            0 |                7.662 |                     0 |                     0 |
| base_R1p75            |            81.95 |           57.47 |            0 |               17.01  |                     0 |                     0 |

### abs_p_l
| case                  |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:----------------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| locked_lead005_mj_w32 |            10.02 |           9.262 |            0 |               2.619  |                     0 |                     0 |
| shape_xm05_mj_w28     |             0    |          19.28  |            0 |               2.619  |                     0 |                     0 |
| shape_x000_tanh_w32   |             0    |          20.98  |            0 |               0.9162 |                     0 |                     0 |
| shape_x000_mj_w32     |             0    |          20.98  |            0 |               0.9162 |                     0 |                     0 |
| shape_x000_mj_w28     |             0    |          20.38  |            0 |               1.513  |                     0 |                     0 |
| shape_x005_mj_w32     |             0    |          20.98  |            0 |               0.9162 |                     0 |                     0 |
| base_R1p75            |            10.02 |           9.262 |            0 |               2.619  |                     0 |                     0 |

## Branch recommendation

Promote a shaped catch branch with minimum-jerk catch, earlier center, and wider transition. Keep beta and packet rematch locked unless a constrained lead variant survives refinement with lower burden and no packet-norm failure.
