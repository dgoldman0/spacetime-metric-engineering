#!/usr/bin/env python3
from pathlib import Path
import sys, json, zipfile
import pandas as pd
sys.path.insert(0, '/mnt/data/active_rail_bifurcation')
import run_bifurcation_probe as rb
ar = rb.ar
OUT = Path('/mnt/data/active_rail_shaped_catch')
OUT.mkdir(parents=True, exist_ok=True)

def C(name, note, **kw):
    return ar.CaseDef(name, rb.ns_from_base(**kw), note)

cases = [
    C('base_R1p75', 'baseline R1.75 quarantine candidate'),
    C('shape_xm05_mj_w28', 'one-component minjerk catch, center -0.05, width 0.28', x_catch=-0.05, w_catch=0.28, catch_profile='minjerk'),
    C('shape_x000_mj_w28', 'one-component minjerk catch, center 0.00, width 0.28', x_catch=0.00, w_catch=0.28, catch_profile='minjerk'),
    C('shape_x000_mj_w32', 'one-component minjerk catch, center 0.00, width 0.32', x_catch=0.00, w_catch=0.32, catch_profile='minjerk'),
    C('shape_x005_mj_w32', 'one-component minjerk catch, center 0.05, width 0.32', x_catch=0.05, w_catch=0.32, catch_profile='minjerk'),
    C('shape_x000_tanh_w32', 'one-component tanh catch, center 0.00, width 0.32', x_catch=0.00, w_catch=0.32, catch_profile='tanh'),
    C('locked_lead005_mj_w32', 'constrained split: beta leads packet by 0.05, both minjerk width 0.32', beta_x_catch=-0.05, beta_w_catch=0.32, beta_profile='minjerk', packet_x_catch=0.00, packet_w_catch=0.32, packet_profile='minjerk'),
]

def build_decision(points, compact, stage):
    focus = compact[compact['channel'].isin(['neg_Tkk_radial','abs_p_l','abs_pOmega','abs_j_l'])].copy()
    piv = focus.pivot(index='case', columns='channel', values=['live_packet_fraction','live_packet_burden','total_burden','point_peak','live_packet_point_peak'])
    piv.columns = [f'{a}__{b}' for a,b in piv.columns]
    piv = piv.reset_index()
    ok = points[points.get('error', pd.Series(index=points.index, dtype=object)).isna()].copy() if 'error' in points.columns else points.copy()
    live = ok[ok['inside_packet_live'].astype(bool)].copy()
    safety = live.groupby('case').agg(
        live_points=('case','size'),
        max_packet_norm_live=('packet_norm','max'),
        positive_packet_norm_live=('packet_norm', lambda x:int((x.astype(float)>0).sum())),
        min_packet_norm_live=('packet_norm','min'),
    ).reset_index()
    decision = piv.merge(safety, on='case', how='left')
    base = decision[decision['case']=='base_R1p75'].iloc[0]
    metrics = ['live_packet_fraction__neg_Tkk_radial','live_packet_fraction__abs_p_l','live_packet_burden__neg_Tkk_radial','live_packet_burden__abs_p_l','point_peak__neg_Tkk_radial','point_peak__abs_p_l','live_packet_point_peak__neg_Tkk_radial','live_packet_point_peak__abs_p_l']
    for metric in metrics:
        if metric in decision.columns:
            decision[f'{metric}_ratio_vs_base'] = decision[metric]/base[metric]
    decision['radial_live_burden_score_ratio'] = 0.65*decision['live_packet_burden__neg_Tkk_radial_ratio_vs_base'] + 0.35*decision['live_packet_burden__abs_p_l_ratio_vs_base']
    decision['peak_score_ratio'] = 0.65*decision['point_peak__neg_Tkk_radial_ratio_vs_base'] + 0.35*decision['point_peak__abs_p_l_ratio_vs_base']
    decision['unsafe_penalty'] = (decision['positive_packet_norm_live'].fillna(0)>0).astype(float)*100.0
    # Slight peak penalty so we don't pick burden relocation with ugly peaks.
    decision['decision_score'] = decision['radial_live_burden_score_ratio'] + 0.10*(decision['peak_score_ratio']-1.0).clip(lower=0) + decision['unsafe_penalty']
    return decision.sort_values('decision_score')

def fmt(x, pct=False):
    try:
        z=float(x)
        return f'{100*z:.2f}%' if pct else f'{z:.4g}'
    except Exception:
        return 'nan'

def build_report(decision, radial_stage):
    lines=[]
    lines.append('# Shaped Catch Branch Design Probe')
    lines.append('')
    lines.append('This probe keeps the previous bifurcation bundle frozen and starts the next branch design. It tests one-component shaped catch variants and tightly constrained beta/packet lead variants.')
    lines.append('')
    lines.append('## Design read')
    lines.append('')
    best = decision.iloc[0]
    lines.append(f"Best scored case: `{best['case']}`.")
    lines.append('')
    lines.append('The working design should be a shaped one-component catch unless a constrained lead case beats it while staying packet-safe. The key safety criterion is zero positive live packet-norm points.')
    lines.append('')
    lines.append('## Decision table')
    lines.append('')
    cols=['case','decision_score','radial_live_burden_score_ratio','peak_score_ratio','live_packet_fraction__neg_Tkk_radial','live_packet_fraction__abs_p_l','live_packet_burden__neg_Tkk_radial_ratio_vs_base','live_packet_burden__abs_p_l_ratio_vs_base','point_peak__neg_Tkk_radial_ratio_vs_base','max_packet_norm_live','positive_packet_norm_live']
    show=decision[[c for c in cols if c in decision.columns]].copy()
    for c in show.columns:
        if c=='case': continue
        if 'fraction' in c:
            show[c]=show[c].map(lambda x: fmt(x, True))
        else:
            show[c]=show[c].map(fmt)
    lines.append(show.to_markdown(index=False))
    lines.append('')
    lines.append('## Radial stage burden')
    lines.append('')
    for ch in ['neg_Tkk_radial','abs_p_l']:
        lines.append(f'### {ch}')
        sub=radial_stage[radial_stage['channel']==ch]
        tab=sub.pivot_table(index='case', columns='stage', values='live_packet_burden', aggfunc='sum')
        tab=tab.reindex(index=decision['case']).fillna(0.0)
        lines.append(tab.map(lambda x: f'{float(x):.4g}').to_markdown())
        lines.append('')
    lines.append('## Branch recommendation')
    lines.append('')
    lines.append('Promote a shaped catch branch with minimum-jerk catch, earlier center, and wider transition. Keep beta and packet rematch locked unless a constrained lead variant survives refinement with lower burden and no packet-norm failure.')
    lines.append('')
    return '\n'.join(lines)

frames=[]
for c in cases:
    print('RUN', c.name, flush=True)
    frames.append(ar.compute_case(c, ns=17, nl=29, s_min=-0.55, s_max=1.35, l_min=-2.80, l_max=2.80, h_s=3.5e-3, h_l=3.5e-3, progress=False))
points=pd.concat(frames, ignore_index=True)
summary,compact,stage,top=ar.summarize_long(points)
decision=build_decision(points, compact, stage)
radial_stage=stage[(stage['channel'].isin(['neg_Tkk_radial','abs_p_l'])) & (stage['weight']=='volume')]

points.to_csv(OUT/'shaped_catch_point_ledger.csv', index=False)
summary.to_csv(OUT/'shaped_catch_summary_long.csv', index=False)
compact.to_csv(OUT/'shaped_catch_global_compact.csv', index=False)
stage.to_csv(OUT/'shaped_catch_stage_summary.csv', index=False)
top.to_csv(OUT/'shaped_catch_top_bad_points.csv', index=False)
decision.to_csv(OUT/'shaped_catch_decision_table.csv', index=False)
radial_stage.to_csv(OUT/'shaped_catch_radial_stage.csv', index=False)
(OUT/'SHAPED_CATCH_BRANCH_DESIGN.md').write_text(build_report(decision, radial_stage), encoding='utf-8')
(OUT/'shaped_catch_metadata.json').write_text(json.dumps({'grid':{'ns':17,'nl':29}, 'cases':[{'name':c.name,'note':c.note,'params':vars(c.params)} for c in cases]}, indent=2), encoding='utf-8')
zip_path=OUT.with_suffix('.zip')
if zip_path.exists(): zip_path.unlink()
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    for p in sorted(OUT.iterdir()):
        if p.is_file(): zf.write(p, arcname=p.name)
    zf.write('/mnt/data/active_rail_bifurcation/run_bifurcation_probe.py', arcname='run_bifurcation_probe.py')
    zf.write(__file__, arcname='run_shaped_catch_design.py')
    zf.write('/mnt/data/active_rail_point_ledger/active_rail_point_lifecycle_ledger.py', arcname='active_rail_point_lifecycle_ledger.py')
print(json.dumps({'ok': True, 'outdir': str(OUT), 'zip': str(zip_path), 'rows': len(points), 'best': decision.iloc[0]['case']}, indent=2))
