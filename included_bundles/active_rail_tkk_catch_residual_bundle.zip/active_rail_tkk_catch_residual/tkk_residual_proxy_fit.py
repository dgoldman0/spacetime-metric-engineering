#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, math, zipfile, shutil
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import nnls

R_PASS_DEFAULT=0.35

BASE_COMPONENTS = [
    'cold_core_substrate',
    'radial_support_edge_shell',
    'outer_quarantine_jacket',
    'lapse_cushion_sector',
    'shift_packet_carrier',
    'catch_rematch_transient',
    'release_shift_transient',
    'packet_local_residual',
    'reset_decompression_infra',
]

NEW_COMPONENTS = [
    'catch_inner_packet_edge_transient',
    'catch_outer_packet_edge_transient',
    'catch_live_packet_boundary_transient',
    'catch_inner_edge_lapse_coupled',
    'catch_inner_edge_shift_coupled',
    'catch_core_bridge_transient',
    'catch_support_edge_bridge_transient',
]


def norm_col(s: pd.Series) -> pd.Series:
    arr=s.astype(float).replace([np.inf,-np.inf],np.nan).fillna(0.0)
    mx=float(arr.max()) if len(arr) else 0.0
    if mx>0: return arr/mx
    return arr*0.0


def add_base_basis(df: pd.DataFrame) -> pd.DataFrame:
    p=df.copy().reset_index(drop=True)
    N=(p['alpha']/p['T'].replace(0,np.nan)).replace([np.inf,-np.inf],np.nan).fillna(0.0)
    p['N_lapse_cushion']=(N-1.0).clip(lower=0)
    p['COmega_excess']=(p['COmega']-1.0).clip(lower=0).fillna(0.0)
    p['beta_abs_norm']=p['beta'].abs()
    stage=p['stage'].astype(str); region=p['region'].astype(str)
    mask_live=p['inside_packet_live'].astype(float)
    mask_geom=p['inside_packet_geom'].astype(float)
    mask_catch=(stage=='catch_rematch').astype(float)
    mask_release=(stage=='release_shift_fade').astype(float)
    mask_post=(stage=='post_release_buffer').astype(float)
    mask_reset=(stage=='reset_decompression').astype(float)
    mask_core=(region=='core_throat').astype(float)
    mask_support=(region=='support_edge').astype(float)
    mask_outer=(region=='outer_quarantine_shell').astype(float)
    W=p['W'].clip(0,1).fillna(0.0)
    Wedge=(W*(1-W)).fillna(0.0)
    bases=pd.DataFrame(index=p.index)
    bases['cold_core_substrate']=p['q'].clip(0)*p['W'].clip(0)*(mask_core+0.35*mask_support)
    bases['radial_support_edge_shell']=p['q'].clip(0)*(Wedge+0.15*mask_support)
    bases['outer_quarantine_jacket']=p['COmega_excess']*(0.35*mask_support+mask_outer+0.15*mask_core)
    bases['lapse_cushion_sector']=p['N_lapse_cushion']*(0.5*mask_support+mask_outer+0.2*mask_core+0.2*mask_geom)
    bases['shift_packet_carrier']=p['E'].clip(0)*p['S'].clip(0)*p['beta_abs_norm']
    bases['catch_rematch_transient']=mask_catch*(0.25+p['S'].clip(0)+0.5*p['W'].clip(0))
    bases['release_shift_transient']=mask_release*(0.25+p['S'].clip(0)+0.5*p['E'].clip(0))
    bases['packet_local_residual']=mask_live*(0.25+p['S'].clip(0))
    bases['reset_decompression_infra']=(mask_reset+0.5*mask_post)*(0.25+p['q'].clip(0)+p['W'].clip(0))*(1-mask_live)
    return bases.apply(norm_col)


def add_tkk_residual_basis(df: pd.DataFrame, rpass: float=R_PASS_DEFAULT) -> pd.DataFrame:
    p=df.copy().reset_index(drop=True)
    bases=pd.DataFrame(index=p.index)
    stage=p['stage'].astype(str)
    region=p['region'].astype(str)
    catch=(stage=='catch_rematch').astype(float)
    live=p['inside_packet_live'].astype(float)
    geom=p['inside_packet_geom'].astype(float)
    support=(region=='support_edge').astype(float)
    core=(region=='core_throat').astype(float)
    packet_support=(region=='packet_in_support').astype(float)
    xi=(p['l']-p['s']).astype(float)
    # inner boundary means the negative l-s edge of the packet corridor.
    sigma=max(0.045, rpass/4.5)
    inner=np.exp(-((xi + rpass)/sigma)**2)
    outer=np.exp(-((xi - rpass)/sigma)**2)
    boundary=np.exp(-((np.abs(xi)-rpass)/sigma)**2)
    center=np.exp(-(xi/(rpass*0.55))**2)
    W=p['W'].clip(0,1).fillna(0.0)
    S=p['S'].clip(0,1).fillna(0.0)
    Wedge=(W*(1-W)).fillna(0.0)
    Sedge=(S*(1-S)).fillna(0.0)
    N=((p['alpha']/p['T'].replace(0,np.nan))-1.0).replace([np.inf,-np.inf],np.nan).fillna(0.0).clip(lower=0)
    beta_abs=p['beta'].abs().fillna(0.0)
    beta_norm=beta_abs/(float(beta_abs.max()) if float(beta_abs.max())>0 else 1.0)
    # Time localization inside catch: fit early and middle separately using s.
    s=p['s'].astype(float)
    early=np.exp(-((s+0.25)/0.18)**2)
    mid=np.exp(-((s-0.00)/0.22)**2)
    # Candidate missing components.
    bases['catch_inner_packet_edge_transient']=catch*live*inner*(0.25+S+0.25*W)
    bases['catch_outer_packet_edge_transient']=catch*live*outer*(0.25+S+0.25*W)
    bases['catch_live_packet_boundary_transient']=catch*live*boundary*(0.25+Sedge+0.25*W)
    bases['catch_inner_edge_lapse_coupled']=catch*live*inner*(0.25+N)*(0.25+S)
    bases['catch_inner_edge_shift_coupled']=catch*live*inner*(0.25+beta_norm)*(0.25+Sedge+S)
    bases['catch_core_bridge_transient']=catch*(core+packet_support)*center*(0.25+W)*(0.6*early+0.4*mid)
    bases['catch_support_edge_bridge_transient']=catch*(support+0.5*packet_support)*Wedge*(0.4+0.6*boundary)
    return bases.apply(norm_col)


def fit_nnls(df: pd.DataFrame, basis: pd.DataFrame, ycol='bad_neg_Tkk_radial'):
    y=df[ycol].to_numpy(dtype=float)
    y=np.where(np.isfinite(y),y,0.0)
    vol=df.get('volume_weight',df.get('cell_area',pd.Series(1.0,index=df.index))).to_numpy(dtype=float)
    vol=np.where(np.isfinite(vol)&(vol>0),vol,1.0)
    X=basis.to_numpy(dtype=float)
    w=np.sqrt(vol)
    coeff,rnorm=nnls(X*w[:,None], y*w, maxiter=20000)
    yhat=np.clip(X@coeff,0,None)
    actual=y*vol; pred=yhat*vol
    resid=y-yhat; under=np.maximum(resid,0)*vol; over=np.maximum(-resid,0)*vol; absres=np.abs(resid)*vol
    live=df['inside_packet_live'].to_numpy(dtype=bool)
    catch=(df['stage'].astype(str)=='catch_rematch').to_numpy(dtype=bool)
    live_catch=live & catch
    total=float(actual.sum()); live_total=float(actual[live].sum()); catch_total=float(actual[catch].sum()); live_catch_total=float(actual[live_catch].sum())
    metrics={
        'actual_total_burden':total,
        'actual_live_packet_burden':live_total,
        'actual_catch_burden':catch_total,
        'actual_live_catch_burden':live_catch_total,
        'predicted_total_burden':float(pred.sum()),
        'predicted_live_packet_burden':float(pred[live].sum()),
        'predicted_catch_burden':float(pred[catch].sum()),
        'predicted_live_catch_burden':float(pred[live_catch].sum()),
        'underfit_total_fraction':float(under.sum()/total) if total else np.nan,
        'underfit_live_fraction':float(under[live].sum()/live_total) if live_total else np.nan,
        'underfit_catch_fraction':float(under[catch].sum()/catch_total) if catch_total else np.nan,
        'underfit_live_catch_fraction':float(under[live_catch].sum()/live_catch_total) if live_catch_total else np.nan,
        'l1_total_fraction':float(absres.sum()/total) if total else np.nan,
        'l1_live_fraction':float(absres[live].sum()/live_total) if live_total else np.nan,
        'l1_live_catch_fraction':float(absres[live_catch].sum()/live_catch_total) if live_catch_total else np.nan,
        'overfit_total_fraction':float(over.sum()/total) if total else np.nan,
        'rnorm_weighted_l2':float(rnorm),
    }
    alloc=[]
    comp_pred=X*coeff[None,:]*vol[:,None]
    for j,name in enumerate(basis.columns):
        ctot=float(comp_pred[:,j].sum()); clive=float(comp_pred[live,j].sum()); ccatch=float(comp_pred[catch,j].sum()); clivecatch=float(comp_pred[live_catch,j].sum())
        alloc.append({
            'component':name,'coefficient':float(coeff[j]),
            'allocated_total_burden':ctot,'share_total_actual':ctot/total if total else np.nan,
            'allocated_live_packet_burden':clive,'share_live_actual':clive/live_total if live_total else np.nan,
            'allocated_catch_burden':ccatch,'share_catch_actual':ccatch/catch_total if catch_total else np.nan,
            'allocated_live_catch_burden':clivecatch,'share_live_catch_actual':clivecatch/live_catch_total if live_catch_total else np.nan,
        })
    point=df[['case','s','l','stage','region','inside_packet_live','packet_norm','bad_neg_Tkk_radial','volume_weight']].copy()
    point['predicted_badness']=yhat; point['residual_badness']=resid; point['underfit_burden']=under; point['absres_burden']=absres
    return metrics, pd.DataFrame(alloc), point


def summarize_stage(point: pd.DataFrame):
    vol=point['volume_weight'].to_numpy(float)
    point=point.copy()
    point['actual_burden']=point['bad_neg_Tkk_radial']*point['volume_weight']
    point['predicted_burden']=point['predicted_badness']*point['volume_weight']
    return point.groupby(['stage','region','inside_packet_live'],dropna=False).agg(
        points=('s','size'), actual_burden=('actual_burden','sum'), predicted_burden=('predicted_burden','sum'),
        underfit_burden=('underfit_burden','sum'), absres_burden=('absres_burden','sum'), max_actual=('bad_neg_Tkk_radial','max'), max_pred=('predicted_badness','max'), max_underfit=('underfit_burden','max')
    ).reset_index()


def xi_bins(point: pd.DataFrame, rpass=R_PASS_DEFAULT):
    p=point[(point['stage']=='catch_rematch') & (point['inside_packet_live'])].copy()
    p['xi']=p['l']-p['s']
    p['xi_bin']=pd.cut(p['xi'], bins=[-rpass-1e-6,-0.25,-0.15,-0.05,0.05,0.15,0.25,rpass+1e-6], include_lowest=True)
    p['actual_burden']=p['bad_neg_Tkk_radial']*p['volume_weight']
    p['predicted_burden']=p['predicted_badness']*p['volume_weight']
    return p.groupby('xi_bin',observed=False).agg(points=('s','size'), actual=('actual_burden','sum'), pred=('predicted_burden','sum'), underfit=('underfit_burden','sum'), absres=('absres_burden','sum'), max_actual=('bad_neg_Tkk_radial','max')).reset_index()


def write_report(outdir: Path, orig_metrics, refined_metrics, orig_alloc, refined_alloc, top_under, xi_summary):
    def pct(x): return f"{100*x:.1f}%" if pd.notna(x) and math.isfinite(float(x)) else 'nan'
    improvement = 1 - refined_metrics['underfit_live_catch_fraction']/orig_metrics['underfit_live_catch_fraction']
    live_imp = 1 - refined_metrics['underfit_live_fraction']/orig_metrics['underfit_live_fraction']
    lines=[]
    lines.append('# Targeted Tkk Catch/Rematch Residual Fit')
    lines.append('')
    lines.append('## Scope')
    lines.append('')
    lines.append('This is a source-proxy refinement for the new freeze candidate. It isolates the negative radial null channel, `neg_Tkk_radial`, and asks whether the catch/rematch residual has a specific missing transient shape.')
    lines.append('')
    lines.append('It is still a proxy fit. It does not prove a matter model. It tests whether the demanded source burden can be represented by a cleaner component story.')
    lines.append('')
    lines.append('## Result')
    lines.append('')
    lines.append('The old generic catch/rematch component was too blunt. The remaining live `Tkk` underfit concentrates on the inner packet edge during catch/rematch, roughly where `l - s` lies near `-Rpass`. Adding packet-edge catch transients cuts the live catch underfit substantially.')
    lines.append('')
    lines.append('| fit | live packet underfit | live catch/rematch underfit | global underfit |')
    lines.append('|---|---:|---:|---:|')
    lines.append(f"| original proxy | {pct(orig_metrics['underfit_live_fraction'])} | {pct(orig_metrics['underfit_live_catch_fraction'])} | {pct(orig_metrics['underfit_total_fraction'])} |")
    lines.append(f"| targeted Tkk proxy | {pct(refined_metrics['underfit_live_fraction'])} | {pct(refined_metrics['underfit_live_catch_fraction'])} | {pct(refined_metrics['underfit_total_fraction'])} |")
    lines.append('')
    lines.append(f"Targeted basis improvement: live catch underfit reduced by about **{100*improvement:.1f}%**; total live packet underfit reduced by about **{100*live_imp:.1f}%**.")
    lines.append('')
    lines.append('## Dominant new transient components')
    lines.append('')
    top=refined_alloc.sort_values('allocated_live_catch_burden',ascending=False).head(8)
    lines.append('| component | live catch allocation | share of live catch actual |')
    lines.append('|---|---:|---:|')
    for _,r in top.iterrows():
        lines.append(f"| `{r['component']}` | {r['allocated_live_catch_burden']:.4g} | {100*r['share_live_catch_actual']:.1f}% |")
    lines.append('')
    lines.append('## Inner-edge structure')
    lines.append('')
    lines.append('The residual is not a whole-packet catch demand. It is strongest near the inner radial packet boundary. The binned live-catch diagnostic is written to `tkk_live_catch_xi_bins.csv`.')
    lines.append('')
    lines.append('| xi bin | actual burden | underfit burden |')
    lines.append('|---|---:|---:|')
    for _,r in xi_summary.iterrows():
        lines.append(f"| `{r['xi_bin']}` | {r['actual']:.4g} | {r['underfit']:.4g} |")
    lines.append('')
    lines.append('## Interpretation')
    lines.append('')
    lines.append('This supports a more precise source story: the freeze candidate needs a **localized inner-edge catch/rematch transient** in the radial null channel. The transient should live on the packet-facing catch boundary, not across the whole rail and not in reset/decompression.')
    lines.append('')
    lines.append('Design implication: do not solve this by adding a broad global exotic layer. The better target is a narrow catch-edge source or geometry modifier tied to the locked-lead handoff.')
    lines.append('')
    lines.append('## Geometry-side implication')
    lines.append('')
    lines.append('Because the residual is edge-localized, the next geometry poke should test a small inner-edge catch smoothing/guard layer: soften the negative `l-s` packet boundary during catch/rematch without widening the whole packet or moving the radial support edge further. This is different from uniform `w_th` pushing, which already hit the packet-safety cliff.')
    lines.append('')
    lines.append('## Files')
    lines.append('')
    for f in ['tkk_residual_fit_summary.csv','tkk_original_allocations.csv','tkk_targeted_allocations.csv','tkk_residual_stage_region.csv','tkk_top_underfit_points.csv','tkk_live_catch_xi_bins.csv','tkk_point_residuals.csv','tkk_residual_proxy_fit.py']:
        lines.append(f'- `{f}`')
    (outdir/'TKK_CATCH_RESIDUAL_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input',type=Path,default=Path('/mnt/data/active_rail_source_decomposition_proxy/input_freeze_candidate_point_ledger_41x73.csv'))
    ap.add_argument('--outdir',type=Path,default=Path('/mnt/data/active_rail_tkk_catch_residual'))
    ap.add_argument('--rpass',type=float,default=R_PASS_DEFAULT)
    args=ap.parse_args()
    out=args.outdir; out.mkdir(parents=True,exist_ok=True)
    df=pd.read_csv(args.input).reset_index(drop=True)
    base=add_base_basis(df)
    tkk=add_tkk_residual_basis(df,args.rpass)
    metrics0, alloc0, point0=fit_nnls(df,base)
    metrics1, alloc1, point1=fit_nnls(df,pd.concat([base,tkk],axis=1))
    fit_df=pd.DataFrame([
        {'fit':'original_proxy',**metrics0},
        {'fit':'targeted_tkk_proxy',**metrics1},
    ])
    fit_df.to_csv(out/'tkk_residual_fit_summary.csv',index=False)
    alloc0.to_csv(out/'tkk_original_allocations.csv',index=False)
    alloc1.to_csv(out/'tkk_targeted_allocations.csv',index=False)
    summarize_stage(point1).to_csv(out/'tkk_residual_stage_region.csv',index=False)
    point1.sort_values('underfit_burden',ascending=False).head(80).to_csv(out/'tkk_top_underfit_points.csv',index=False)
    xi=xi_bins(point1,args.rpass); xi.to_csv(out/'tkk_live_catch_xi_bins.csv',index=False)
    point1.to_csv(out/'tkk_point_residuals.csv',index=False)
    # Save basis diagnostics.
    basis=pd.concat([base.add_prefix('base__'),tkk.add_prefix('new__')],axis=1)
    diag=[]
    live=df['inside_packet_live'].astype(bool); catch=df['stage'].astype(str)=='catch_rematch'
    for col in basis.columns:
        arr=basis[col].to_numpy(float)
        diag.append({'basis':col,'nonzero_points':int((arr>1e-8).sum()),'live_nonzero_points':int(((arr>1e-8)&live).sum()),'catch_nonzero_points':int(((arr>1e-8)&catch).sum()),'live_catch_nonzero_points':int(((arr>1e-8)&live&catch).sum()),'max':float(arr.max()) if len(arr) else 0})
    pd.DataFrame(diag).to_csv(out/'tkk_basis_diagnostics.csv',index=False)
    write_report(out,metrics0,metrics1,alloc0,alloc1,point1.sort_values('underfit_burden',ascending=False).head(80),xi)
    # Copy script.
    shutil.copyfile(__file__,out/'tkk_residual_proxy_fit.py')
    # metadata
    meta={'input':str(args.input),'rpass':args.rpass,'rows':len(df),'case':df['case'].unique().tolist(),'metrics_original':metrics0,'metrics_targeted':metrics1}
    (out/'tkk_residual_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    # zip
    zip_path=out.parent/'active_rail_tkk_catch_residual_bundle.zip'
    if zip_path.exists(): zip_path.unlink()
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
        for p in out.rglob('*'):
            if p.is_file(): z.write(p,p.relative_to(out.parent))
    print(json.dumps({'outdir':str(out),'zip':str(zip_path),'orig':metrics0,'targeted':metrics1},indent=2))

if __name__=='__main__':
    main()
