#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, math, zipfile, sys
from dataclasses import dataclass, asdict
from pathlib import Path
import numpy as np
import pandas as pd

SRC = Path('/mnt/data/active_rail_radial_softening/radial_softening_probe.py')
spec = importlib.util.spec_from_file_location('radial', SRC)
radial = importlib.util.module_from_spec(spec)
sys.modules['radial'] = radial
spec.loader.exec_module(radial)

@dataclass(frozen=True)
class ShockParams(radial.Params):
    # catch-edge guard / shock absorber fields
    edge_guard_kind: str = 'none'   # none, alpha, beta_boost, beta_taper, alpha_beta
    edge_guard_amp: float = 0.0
    edge_guard_sigma: float = 0.075
    edge_guard_side: str = 'inner'  # inner, outer, both
    edge_guard_x: float = 0.0      # follows packet rematch center by default
    edge_guard_w: float = 0.32


def catch_env(s, x, w):
    # derivative-like envelope over the minjerk catch interval, normalized to 1 at middle
    u = (np.asarray(s, dtype=float) - (x - 2*w)) / max(4*w, 1e-12)
    u = np.clip(u, 0.0, 1.0)
    env = 30*u*u*(1-u)*(1-u) / 1.875
    return env


def edge_guard(s, l, p: ShockParams):
    if p.edge_guard_kind == 'none' or p.edge_guard_amp == 0:
        return 0.0
    xi = np.asarray(l, dtype=float) - np.asarray(s, dtype=float)
    sig = max(p.edge_guard_sigma, 1e-6)
    inner = np.exp(-((xi + p.Rpass)/sig)**2)
    outer = np.exp(-((xi - p.Rpass)/sig)**2)
    if p.edge_guard_side == 'inner': spatial = inner
    elif p.edge_guard_side == 'outer': spatial = outer
    elif p.edge_guard_side == 'both': spatial = np.maximum(inner, outer)
    else: raise ValueError(p.edge_guard_side)
    return float(catch_env(s, p.edge_guard_x, p.edge_guard_w) * spatial)


def scalars_shock(s: float, l: float, p: ShockParams):
    # Copy of radial.scalars with local guard applied to alpha and/or beta.
    s_arr = np.asarray(s, dtype=float); l_arr=np.asarray(l, dtype=float)
    Cb = radial.catch_factor(s_arr, p.x_catch_beta, p.w_catch_beta, p.catch_profile)
    Cp = radial.catch_factor(s_arr, p.x_catch_packet, p.w_catch_packet, p.catch_profile)
    U_beta = p.v_exit + (p.V - p.v_exit) * Cb
    U_packet = p.v_exit + (p.V - p.v_exit) * Cp
    E = radial.falloff(s_arr - p.x_beta, p.w_beta)
    q = radial.minjerk_down(s_arr, p.q_t0, p.q_Tr)
    W = radial.support_bump(l_arr, p)
    S = radial.bump_sq((l_arr - s_arr)**2 + p.eps*p.eps, p.Rpass, p.w_pass)
    A = np.exp(q * W * math.log(p.C0))
    T = np.exp(q * W * math.log(p.lam * p.C0))
    B = 1.0 + (p.B0 - 1.0) * W * q
    shoulder = np.exp(-((np.abs(l_arr) - 1.05) / 0.35) ** 2)
    N = np.exp(p.eta_N * 0.18 * q * shoulder)
    Wpower = W ** p.p_beta
    beta = -U_beta * E * Wpower * S / B
    alpha = N * T
    G = edge_guard(s, l, p)
    amp = p.edge_guard_amp
    if p.edge_guard_kind == 'alpha':
        alpha = alpha * np.exp(amp * G)
    elif p.edge_guard_kind == 'beta_boost':
        beta = beta * np.exp(amp * G)   # beta is negative: increases cancellation magnitude
    elif p.edge_guard_kind == 'beta_taper':
        beta = beta * np.exp(-amp * G)
    elif p.edge_guard_kind == 'alpha_beta':
        alpha = alpha * np.exp(amp * G)
        beta = beta * np.exp(0.5 * amp * G)
    elif p.edge_guard_kind == 'none':
        pass
    else:
        raise ValueError(p.edge_guard_kind)
    sqrt_gamma_ll = B * A
    gamma_ll = sqrt_gamma_ll * sqrt_gamma_ll
    vcoord = U_packet / B
    gtt = -alpha*alpha + gamma_ll * beta*beta
    packet_norm = -alpha*alpha + gamma_ll * (vcoord + beta)**2
    WOmega = radial.bump_sq(l_arr*l_arr, p.ROmega, p.wOmega)
    QOmega = radial.falloff(s_arr - p.xOmega, p.wtOmega)
    COmega = np.exp(p.aOmega * QOmega * WOmega)
    gamma_omega = (l_arr*l_arr + p.Rth*p.Rth) * COmega*COmega
    return {'U_beta':float(U_beta),'U_packet':float(U_packet),'E':float(E),'q':float(q),'W':float(W),'S':float(S),'A':float(A),'T':float(T),'B':float(B),'N':float(N),'beta':float(beta),'alpha':float(alpha),'sqrt_gamma_ll':float(sqrt_gamma_ll),'gamma_ll':float(gamma_ll),'vcoord':float(vcoord),'gtt':float(gtt),'packet_norm':float(packet_norm),'WOmega':float(WOmega),'QOmega':float(QOmega),'COmega':float(COmega),'gamma_omega':float(gamma_omega),'edge_guard':float(G)}

# patch radial evaluator to use shock scalars
radial.scalars = scalars_shock


def run_cases(outdir: Path, cases, ns=25, nl=45, s_min=-0.35, s_max=1.65, l_min=-2.8, l_max=2.8, h_s=2.5e-3, h_l=2.5e-3, quiet=False):
    outdir.mkdir(parents=True, exist_ok=True)
    frames=[]
    for c in cases:
        print('Running', c.name, flush=True)
        df = radial.compute_case(c, ns,nl,s_min,s_max,l_min,l_max,h_s,h_l, progress=not quiet)
        frames.append(df)
        # checkpoint each case
        df.to_csv(outdir/f'{c.name}.csv', index=False)
        with open(outdir/f'{c.name}.json','w') as f:
            json.dump({'name':c.name,'note':c.note,'params':asdict(c.params)}, f, indent=2)
    points=pd.concat(frames, ignore_index=True)
    points.to_csv(outdir/'shock_point_ledger.csv', index=False)
    summary, compact, stage, safety, decision = radial.summarize(points)
    summary.to_csv(outdir/'shock_summary_long.csv', index=False)
    compact.to_csv(outdir/'shock_global_compact.csv', index=False)
    stage.to_csv(outdir/'shock_stage_summary.csv', index=False)
    safety.to_csv(outdir/'shock_safety.csv', index=False)
    decision.to_csv(outdir/'shock_decision_table.csv', index=False)
    extra = build_shock_tables(points, compact, stage, safety, decision)
    extra['catch'].to_csv(outdir/'shock_live_catch_table.csv', index=False)
    extra['top_norm'].to_csv(outdir/'shock_top_packet_norm_points.csv', index=False)
    extra['top_tkk'].to_csv(outdir/'shock_top_live_catch_tkk_points.csv', index=False)
    report = write_report(cases, decision, extra['catch'], safety, ns, nl)
    (outdir/'SHOCK_ABSORBER_REPORT.md').write_text(report)
    with zipfile.ZipFile(outdir.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(outdir.iterdir()): zf.write(p, arcname=p.name)
        zf.write(__file__, arcname=Path(__file__).name)
    return points, summary, compact, stage, safety, decision, extra


def build_shock_tables(points, compact, stage, safety, decision):
    ok=points[points.get('error',pd.Series(index=points.index,dtype=object)).isna()].copy() if 'error' in points.columns else points.copy()
    catch=[]
    for case,g in ok.groupby('case'):
        live=g[g['inside_packet_live'].astype(bool)]
        live_catch=live[live['stage'].eq('catch_rematch')]
        for label,sub in [('live',live),('live_catch',live_catch)]:
            row={'case':case,'scope':label,'points':len(sub)}
            for ch in ['neg_Tkk_radial','abs_p_l','abs_pOmega','abs_j_l']:
                row[f'{ch}_burden']=float(sub[f'volume_burden_{ch}'].sum()) if len(sub) else 0
                row[f'{ch}_peak']=float(sub[f'bad_{ch}'].max()) if len(sub) else 0
            row['max_packet_norm']=float(sub['packet_norm'].max()) if len(sub) else np.nan
            row['positive_packet_norm_points']=int((sub['packet_norm']>0).sum()) if len(sub) else 0
            catch.append(row)
    catch=pd.DataFrame(catch)
    base=catch[(catch.case=='freeze_candidate')&(catch.scope=='live_catch')]
    if not len(base): base=catch[catch.scope=='live_catch'].iloc[[0]]
    for ch in ['neg_Tkk_radial','abs_p_l','abs_pOmega','abs_j_l']:
        den=float(base.iloc[0][f'{ch}_burden'])
        catch[f'{ch}_ratio_vs_freeze_live_catch']=catch[f'{ch}_burden']/den if den else np.nan
    top_norm=ok[ok['inside_packet_live'].astype(bool)].sort_values('packet_norm', ascending=False).groupby('case').head(10)
    top_tkk=ok[(ok['inside_packet_live'].astype(bool))&(ok['stage'].eq('catch_rematch'))].sort_values('volume_burden_neg_Tkk_radial', ascending=False).groupby('case').head(10)
    return {'catch':catch, 'top_norm':top_norm, 'top_tkk':top_tkk}


def fmt(x):
    try:
        return f'{float(x):.4g}'
    except Exception:
        return str(x)


def write_report(cases, decision, catch, safety, ns, nl):
    lines=['# Catch-Edge Shock Absorber Probe','', 'Diagnostic test of localized catch/rematch packet-edge guard layers on the new V=10 freeze candidate. This is a prescribed-geometry source ledger, not a matter model or constraint solve.','',f'Grid: `{ns} x {nl}` per case.','']
    lines.append('## Candidate guard interpretation')
    lines.append('')
    lines.append('The guard is a smooth layer active only during catch/rematch and localized near the packet radial boundary. `alpha` guards add a local lapse cushion; `beta_boost` guards increase local shift cancellation at the inner packet edge; `alpha_beta` combines both.')
    lines.append('')
    lines.append('## Cases')
    rows=[]
    for c in cases:
        p=c.params
        rows.append({'case':c.name,'kind':p.edge_guard_kind,'amp':p.edge_guard_amp,'sigma':p.edge_guard_sigma,'side':p.edge_guard_side,'w_th':p.w_th,'eta_N':p.eta_N,'note':c.note})
    lines.append(pd.DataFrame(rows).to_markdown(index=False)); lines.append('')
    lines.append('## Live catch/rematch table')
    lines.append('')
    show=catch[catch.scope=='live_catch'].copy()
    cols=['case','neg_Tkk_radial_burden','neg_Tkk_radial_ratio_vs_freeze_live_catch','abs_p_l_burden','abs_p_l_ratio_vs_freeze_live_catch','max_packet_norm','positive_packet_norm_points']
    show=show[cols]
    for col in show.columns:
        if col!='case': show[col]=show[col].map(fmt)
    lines.append(show.to_markdown(index=False)); lines.append('')
    lines.append('## Safety')
    lines.append(safety.to_markdown(index=False)); lines.append('')
    lines.append('## Decision table')
    s=decision[['case','score','pl_live_ratio','tkk_live_ratio','max_packet_norm_live','positive_packet_norm_live']].copy()
    for col in s.columns:
        if col!='case': s[col]=s[col].map(fmt)
    lines.append(s.to_markdown(index=False)); lines.append('')
    return '\n'.join(lines)


def make_screen_cases():
    base = ShockParams(w_th=0.569, eta_N=2.0, edge_guard_kind='none', edge_guard_amp=0.0)
    cases=[radial.CaseDef('freeze_candidate', base, 'current tuned freeze candidate, no packet-edge guard')]
    for kind in ['alpha','beta_boost','alpha_beta']:
        for amp in [0.03,0.06,0.10,0.15]:
            p=ShockParams(w_th=0.569, eta_N=2.0, edge_guard_kind=kind, edge_guard_amp=amp, edge_guard_sigma=0.075, edge_guard_side='inner')
            cases.append(radial.CaseDef(f'{kind}_{amp:.2f}', p, f'{kind} catch-edge inner guard amp {amp:.2f}'))
    for sig in [0.05,0.10,0.13]:
        p=ShockParams(w_th=0.569, eta_N=2.0, edge_guard_kind='alpha_beta', edge_guard_amp=0.06, edge_guard_sigma=sig, edge_guard_side='inner')
        cases.append(radial.CaseDef(f'alpha_beta_006_sig{sig:.2f}', p, f'combined guard amp 0.06 sigma {sig:.2f}'))
    return cases


def make_high_cases():
    base = ShockParams(w_th=0.569, eta_N=2.0, edge_guard_kind='none', edge_guard_amp=0.0)
    cases=[radial.CaseDef('freeze_candidate', base, 'current tuned freeze candidate, no packet-edge guard')]
    # fill after screen, but provide useful default cases
    cases += [
        radial.CaseDef('alpha_006', ShockParams(w_th=0.569, eta_N=2.0, edge_guard_kind='alpha', edge_guard_amp=0.06, edge_guard_sigma=0.075), 'alpha guard amp 0.06'),
        radial.CaseDef('alpha_010', ShockParams(w_th=0.569, eta_N=2.0, edge_guard_kind='alpha', edge_guard_amp=0.10, edge_guard_sigma=0.075), 'alpha guard amp 0.10'),
        radial.CaseDef('alpha_beta_006', ShockParams(w_th=0.569, eta_N=2.0, edge_guard_kind='alpha_beta', edge_guard_amp=0.06, edge_guard_sigma=0.075), 'combined alpha/beta guard amp 0.06'),
        radial.CaseDef('beta_boost_006', ShockParams(w_th=0.569, eta_N=2.0, edge_guard_kind='beta_boost', edge_guard_amp=0.06, edge_guard_sigma=0.075), 'beta boost guard amp 0.06'),
    ]
    return cases

if __name__ == '__main__':
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument('--mode', choices=['screen','high'], default='screen')
    ap.add_argument('--outdir', type=Path, required=True)
    ap.add_argument('--ns', type=int, default=25)
    ap.add_argument('--nl', type=int, default=45)
    ap.add_argument('--quiet', action='store_true')
    args=ap.parse_args()
    cases=make_screen_cases() if args.mode=='screen' else make_high_cases()
    run_cases(args.outdir, cases, ns=args.ns, nl=args.nl, quiet=args.quiet)
