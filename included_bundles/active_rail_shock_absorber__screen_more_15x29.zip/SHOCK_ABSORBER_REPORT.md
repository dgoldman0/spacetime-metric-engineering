# Catch-Edge Shock Absorber Probe

Diagnostic test of localized catch/rematch packet-edge guard layers on the new V=10 freeze candidate. This is a prescribed-geometry source ledger, not a matter model or constraint solve.

Grid: `15 x 29` per case.

## Candidate guard interpretation

The guard is a smooth layer active only during catch/rematch and localized near the packet radial boundary. `alpha` guards add a local lapse cushion; `beta_boost` guards increase local shift cancellation at the inner packet edge; `alpha_beta` combines both.

## Cases
| case              | kind       |   amp |   sigma | side   |   w_th |   eta_N | note              |
|:------------------|:-----------|------:|--------:|:-------|-------:|--------:|:------------------|
| freeze_candidate  | none       |  0    |   0.075 | inner  |  0.569 |       2 | base              |
| beta_taper_0.10   | beta_taper |  0.1  |   0.075 | inner  |  0.569 |       2 | beta_taper 0.1    |
| beta_taper_0.25   | beta_taper |  0.25 |   0.075 | inner  |  0.569 |       2 | beta_taper 0.25   |
| beta_taper_0.40   | beta_taper |  0.4  |   0.075 | inner  |  0.569 |       2 | beta_taper 0.4    |
| beta_taper_0.60   | beta_taper |  0.6  |   0.075 | inner  |  0.569 |       2 | beta_taper 0.6    |
| alpha_0.80        | alpha      |  0.8  |   0.075 | inner  |  0.569 |       2 | alpha 0.8         |
| alpha_1.00        | alpha      |  1    |   0.075 | inner  |  0.569 |       2 | alpha 1.0         |
| alpha_beta_0.80   | alpha_beta |  0.8  |   0.075 | inner  |  0.569 |       2 | alpha_beta 0.8    |
| alpha_beta_1.00   | alpha_beta |  1    |   0.075 | inner  |  0.569 |       2 | alpha_beta 1.0    |
| alpha_040_sig0.12 | alpha      |  0.4  |   0.12  | inner  |  0.569 |       2 | alpha .4 sig 0.12 |
| alpha_040_sig0.18 | alpha      |  0.4  |   0.18  | inner  |  0.569 |       2 | alpha .4 sig 0.18 |
| alpha_040_sig0.25 | alpha      |  0.4  |   0.25  | inner  |  0.569 |       2 | alpha .4 sig 0.25 |

## Live catch/rematch table

| case              |   neg_Tkk_radial_burden |   neg_Tkk_radial_ratio_vs_freeze_live_catch |   abs_p_l_burden |   abs_p_l_ratio_vs_freeze_live_catch |   max_packet_norm |   positive_packet_norm_points |
|:------------------|------------------------:|--------------------------------------------:|-----------------:|-------------------------------------:|------------------:|------------------------------:|
| alpha_0.80        |                   64.64 |                                      0.9461 |             13.6 |                                    1 |            -198.9 |                             0 |
| alpha_040_sig0.12 |                   65.8  |                                      0.9632 |             13.6 |                                    1 |            -198.9 |                             0 |
| alpha_040_sig0.18 |                   68.11 |                                      0.9969 |             13.6 |                                    1 |            -198.9 |                             0 |
| alpha_040_sig0.25 |                   71.26 |                                      1.043  |             13.6 |                                    1 |            -230.6 |                             0 |
| alpha_1.00        |                   62.01 |                                      0.9077 |             13.6 |                                    1 |            -198.9 |                             0 |
| alpha_beta_0.80   |                   65.45 |                                      0.9581 |             13.6 |                                    1 |            -198.9 |                             0 |
| alpha_beta_1.00   |                   64.38 |                                      0.9424 |             13.6 |                                    1 |            -198.9 |                             0 |
| beta_taper_0.10   |                   68.34 |                                      1      |             13.6 |                                    1 |            -198.9 |                             0 |
| beta_taper_0.25   |                   68.35 |                                      1      |             13.6 |                                    1 |            -198.9 |                             0 |
| beta_taper_0.40   |                   68.35 |                                      1      |             13.6 |                                    1 |            -198.9 |                             0 |
| beta_taper_0.60   |                   68.35 |                                      1.001  |             13.6 |                                    1 |            -198.9 |                             0 |
| freeze_candidate  |                   68.32 |                                      1      |             13.6 |                                    1 |            -198.9 |                             0 |

## Safety
| case              |   live_points |   max_packet_norm_live |   min_packet_norm_live |   positive_packet_norm_live |
|:------------------|--------------:|-----------------------:|-----------------------:|----------------------------:|
| alpha_0.80        |            36 |               -198.925 |      -683939           |                           0 |
| alpha_040_sig0.12 |            36 |               -198.925 |      -292109           |                           0 |
| alpha_040_sig0.18 |            36 |               -198.947 |      -294304           |                           0 |
| alpha_040_sig0.25 |            36 |               -230.586 |      -295158           |                           0 |
| alpha_1.00        |            36 |               -198.925 |           -1.02845e+06 |                           0 |
| alpha_beta_0.80   |            36 |               -198.925 |      -723197           |                           0 |
| alpha_beta_1.00   |            36 |               -198.925 |           -1.07646e+06 |                           0 |
| beta_taper_0.10   |            36 |               -198.925 |      -175324           |                           0 |
| beta_taper_0.25   |            36 |               -198.925 |      -175324           |                           0 |
| beta_taper_0.40   |            36 |               -198.925 |      -175324           |                           0 |
| beta_taper_0.60   |            36 |               -198.925 |      -175324           |                           0 |
| freeze_candidate  |            36 |               -198.925 |      -175324           |                           0 |

## Decision table
| case              |   score |   pl_live_ratio |   tkk_live_ratio |   max_packet_norm_live |   positive_packet_norm_live |
|:------------------|--------:|----------------:|-----------------:|-----------------------:|----------------------------:|
| alpha_beta_1.00   |   1     |               1 |           0.9966 |                 -198.9 |                           0 |
| alpha_1.00        |   1     |               1 |           0.9649 |                 -198.9 |                           0 |
| alpha_0.80        |   1     |               1 |           1      |                 -198.9 |                           0 |
| alpha_beta_0.80   |   1.003 |               1 |           1.011  |                 -198.9 |                           0 |
| alpha_040_sig0.12 |   1.005 |               1 |           1.016  |                 -198.9 |                           0 |
| alpha_040_sig0.18 |   1.014 |               1 |           1.046  |                 -198.9 |                           0 |
| freeze_candidate  |   1.015 |               1 |           1.049  |                 -198.9 |                           0 |
| beta_taper_0.10   |   1.015 |               1 |           1.049  |                 -198.9 |                           0 |
| beta_taper_0.40   |   1.015 |               1 |           1.05   |                 -198.9 |                           0 |
| beta_taper_0.25   |   1.015 |               1 |           1.05   |                 -198.9 |                           0 |
| beta_taper_0.60   |   1.015 |               1 |           1.05   |                 -198.9 |                           0 |
| alpha_040_sig0.25 |   1.027 |               1 |           1.089  |                 -230.6 |                           0 |
