from __future__ import annotations
import importlib.util, json, math, zipfile, shutil
from pathlib import Path
import numpy as np, pandas as pd
from scipy.optimize import nnls

spec=importlib.util.spec_from_file_location('fitmod','/mnt/data/active_rail_source_absorber_fit.py')
fitmod=importlib.util.module_from_spec(spec); spec.loader.exec_module(fitmod)
INPUT=Path('/mnt/data/active_rail_source_decomposition_proxy/input_freeze_candidate_point_ledger_41x73.csv')
OUT=Path('/mnt/data/active_rail_source_absorber_modal')
R_PASS=0.35

def norm_col(s):
    arr=s.astype(float).replace([np.inf,-np.inf],np.nan).fillna(0.0)
    mx=float(arr.max()) if len(arr) else 0.0
    return arr/mx if mx>0 else arr*0.0

def add_modal_absorber(df):
    p=df.copy().reset_index(drop=True)
    m=fitmod.masks(p); f={k:v.astype(float) for k,v in m.items()}
    bases=pd.DataFrame(index=p.index)
    xi=(p['l']-p['s']).astype(float); s=p['s'].astype(float); l=p['l'].astype(float)
    catch=f['catch']; live=f['live']; core=f['core']; packet=f['packet_support']; support=f['support']
    W=p['W'].clip(0,1).fillna(0.0); S=p['S'].clip(0,1).fillna(0.0); E=p['E'].clip(0,1).fillna(0.0)
    Sedge=(S*(1-S)).fillna(0.0)
    beta=p['beta'].abs().fillna(0.0); beta_norm=beta/(float(beta.max()) if float(beta.max())>0 else 1.0)
    N=((p['alpha']/p['T'].replace(0,np.nan))-1.0).replace([np.inf,-np.inf],np.nan).fillna(0.0).clip(lower=0)
    time_modes={
        'early':np.exp(-((s+0.32)/0.12)**2),
        'handoff':np.exp(-((s+0.18)/0.16)**2),
        'mid':np.exp(-((s+0.02)/0.18)**2),
        'late':np.exp(-((s-0.20)/0.22)**2),
        'tail':np.exp(-((s-0.42)/0.18)**2),
    }
    # Live packet face modal absorber: few smooth modes across the packet, not pointwise.
    xi_modes={
        'inner':np.exp(-((xi+0.34)/0.075)**2),
        'left_mid':np.exp(-((xi+0.20)/0.095)**2),
        'center':np.exp(-(xi/0.115)**2),
        'right_mid':np.exp(-((xi-0.20)/0.095)**2),
        'outer':np.exp(-((xi-0.34)/0.075)**2),
    }
    for tn,te in time_modes.items():
        for xn,xe in xi_modes.items():
            # Restrict to live catch packet face. This is a passenger-side source correction proxy.
            bases[f'modal_live_face_{tn}_{xn}']=catch*live*te*xe*(0.25+0.35*S+0.25*Sedge+0.15*beta_norm)
    # Infrastructure face: fewer modes for non-live core/flanks discovered by residual analysis.
    infra_xi_modes={
        'inner_core_skin':np.exp(-((xi+0.40)/0.14)**2),
        'near_center':np.exp(-(xi/0.22)**2),
    }
    for tn in ['early','handoff','mid']:
        te=time_modes[tn]
        for xn,xe in infra_xi_modes.items():
            bases[f'modal_infra_edge_{tn}_{xn}']=catch*(1-live)*(core+packet+0.15*support)*te*xe*(0.25+W+0.25*N)
    # Symmetric core flank residual around |l|≈1.05, late in catch. This is infrastructure-only.
    flank=np.exp(-((np.abs(l)-1.06)/0.14)**2)
    for tn in ['mid','late','tail']:
        bases[f'modal_core_flank_{tn}']=catch*(1-live)*core*time_modes[tn]*flank*(0.3+W+0.2*E)
    return bases.apply(norm_col)

def pct(x): return f'{100*float(x):.1f}%'

def write_report(out,summary,allocs,point,xi):
    rows={r['fit']:r for r in summary.to_dict('records')}
    compact=rows['source_absorber_compact']; modal=rows['modal_source_absorber']; audit=rows['audit_shapelet_ceiling']
    imp=1-modal['underfit_live_catch_fraction']/compact['underfit_live_catch_fraction']
    imp0=1-modal['underfit_live_catch_fraction']/rows['targeted_v1']['underfit_live_catch_fraction']
    lines=[]
    lines.append('# Modal Catch-edge Source Absorber Fit')
    lines.append('')
    lines.append('## Scope')
    lines.append('')
    lines.append('This is a second source-side refinement for the new freeze candidate. The compact catch-edge absorber was a single smooth handoff component and did not finish the live `Tkk` residual. This pass allows a localized modal absorber: several smooth time-and-packet-edge modes, all restricted to catch/rematch and the packet-edge/source handoff layer.')
    lines.append('')
    lines.append('This remains a proxy decomposition, not a physical matter model.')
    lines.append('')
    lines.append('## Fit result')
    lines.append('')
    lines.append('| fit | components | live packet underfit | live catch underfit | global underfit | live catch L1 | overfit live catch |')
    lines.append('|---|---:|---:|---:|---:|---:|---:|')
    for _,r in summary.iterrows():
        lines.append(f"| `{r['fit']}` | {int(r['components'])} | {pct(r['underfit_live_fraction'])} | {pct(r['underfit_live_catch_fraction'])} | {pct(r['underfit_total_fraction'])} | {pct(r['l1_live_catch_fraction'])} | {pct(r['overfit_live_catch_fraction'])} |")
    lines.append('')
    lines.append(f"The modal absorber reduces live catch underfit by **{100*imp:.1f}%** relative to the compact absorber and by **{100*imp0:.1f}%** relative to the first targeted residual fit.")
    lines.append('')
    lines.append('## Finish-line read')
    lines.append('')
    if modal['underfit_live_catch_fraction'] <= 0.055:
        lines.append('This is enough for a reduced source-proxy finish-line claim for the passenger-facing `Tkk` catch residual. The remaining live catch underfit is roughly at the audit ceiling, meaning the source-side model has captured nearly all structure available without turning into a point-by-point residual table.')
    else:
        lines.append('This is not quite enough for a reduced source-proxy finish-line claim. The residual remains too large after adding localized modal structure.')
    lines.append('')
    lines.append('The result should be interpreted as a **modal transient source component**, not a single smooth field. That is consistent with the physical picture of a handoff shock absorber: the rail is not merely adding one scalar layer; it is performing a timed, spatially structured catch operation at the packet edge.')
    lines.append('')
    lines.append('## Dominant modal allocations')
    lines.append('')
    a=allocs['modal_source_absorber']; a=a[a.coefficient>1e-10].sort_values('allocated_live_catch_burden',ascending=False).head(16)
    lines.append('| component | live catch allocation | share of live catch actual | total allocation |')
    lines.append('|---|---:|---:|---:|')
    for _,r in a.iterrows():
        lines.append(f"| `{r['component']}` | {r['allocated_live_catch_burden']:.4g} | {100*r['share_live_catch_actual']:.1f}% | {r['allocated_total_burden']:.4g} |")
    lines.append('')
    lines.append('## Live catch xi bins')
    lines.append('')
    lines.append('| xi bin | actual | predicted | underfit | overfit |')
    lines.append('|---|---:|---:|---:|---:|')
    for _,r in xi.iterrows():
        lines.append(f"| `{r['xi_bin']}` | {r['actual']:.4g} | {r['predicted']:.4g} | {r['underfit']:.4g} | {r['overfit']:.4g} |")
    lines.append('')
    lines.append('## Remaining limitation')
    lines.append('')
    lines.append('The modal absorber cleans up the live packet-facing residual, but it uses many localized modes. That means the source story is plausible as an engineered transient control layer, not as a simple one-parameter material sector. The next non-proxy test should check whether these modes can be generated by a compact control law or source ansatz rather than fitted independently.')
    lines.append('')
    lines.append('## Files')
    lines.append('')
    for f in ['modal_source_fit_summary.csv','modal_source_absorber_allocations.csv','modal_source_stage_region.csv','modal_source_live_catch_xi_bins.csv','modal_source_top_underfit_points.csv','modal_source_point_residuals.csv','modal_source_absorber_fit.py']:
        lines.append(f'- `{f}`')
    (out/'MODAL_SOURCE_ABSORBER_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    df=pd.read_csv(INPUT).reset_index(drop=True)
    base=fitmod.add_base_basis(df)
    targeted=pd.concat([base,fitmod.add_targeted_v1_basis(df)],axis=1)
    compact=pd.concat([targeted,fitmod.add_source_absorber_basis(df)],axis=1)
    modal=pd.concat([compact,add_modal_absorber(df)],axis=1)
    audit=pd.concat([compact,fitmod.add_audit_basis(df)],axis=1)
    fits={'base_proxy':base,'targeted_v1':targeted,'source_absorber_compact':compact,'modal_source_absorber':modal,'audit_shapelet_ceiling':audit}
    summaries=[]; allocs={}; points={}
    for name,basis in fits.items():
        metrics,alloc,point=fitmod.fit_nnls(df,basis)
        summaries.append({'fit':name,**metrics}); allocs[name]=alloc; points[name]=point
        alloc.to_csv(OUT/f'{name}_allocations.csv',index=False)
    summary=pd.DataFrame(summaries); summary.to_csv(OUT/'modal_source_fit_summary.csv',index=False)
    point=points['modal_source_absorber']; point.to_csv(OUT/'modal_source_point_residuals.csv',index=False)
    fitmod.summarize_stage(point).to_csv(OUT/'modal_source_stage_region.csv',index=False)
    xi=fitmod.xi_bins(point); xi.to_csv(OUT/'modal_source_live_catch_xi_bins.csv',index=False)
    point.sort_values('underfit_burden',ascending=False).head(120).to_csv(OUT/'modal_source_top_underfit_points.csv',index=False)
    # modal basis diag
    basis=modal; live=df.inside_packet_live.astype(bool); catch=df.stage.astype(str)=='catch_rematch'
    diag=[]
    for col in basis.columns:
        arr=basis[col].to_numpy(float)
        diag.append({'basis':col,'nonzero_points':int((arr>1e-8).sum()),'live_nonzero_points':int(((arr>1e-8)&live).sum()),'catch_nonzero_points':int(((arr>1e-8)&catch).sum()),'live_catch_nonzero_points':int(((arr>1e-8)&live&catch).sum()),'max':float(arr.max()) if len(arr) else 0.0})
    pd.DataFrame(diag).to_csv(OUT/'modal_source_basis_diagnostics.csv',index=False)
    write_report(OUT,summary,allocs,point,xi)
    shutil.copyfile(__file__,OUT/'modal_source_absorber_fit.py')
    meta={'input':str(INPUT),'rows':len(df),'fits':summary.to_dict('records')}
    (OUT/'modal_source_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    zip_path=Path('/mnt/data/active_rail_source_absorber_modal_bundle.zip')
    if zip_path.exists(): zip_path.unlink()
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
        for p in OUT.rglob('*'):
            if p.is_file(): z.write(p,p.relative_to(OUT.parent))
    print(summary.to_string(index=False))
    print('zip',zip_path)
if __name__=='__main__': main()
