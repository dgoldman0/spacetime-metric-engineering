# Standing Substrate Subtraction at V=10

## Scope

This repeats the exact-builder standing-substrate subtraction at the V=10 edge case. The comparison uses the same time-matched beta-off substrate used for V=5. That makes this a service-shift subtraction, not a solved standing-source construction.

## Headline

V=10 passes the same qualitative subtraction check, but the shift/momentum service increment is stronger than at V=5.

## Time-matched beta-off subtraction

| field | global delta / live global | live packet delta / live packet live | live packet abs burden | catch share of live-packet delta | peak abs delta |
|---|---:|---:|---:|---:|---:|
| rho | 1.35208e-06 | 4.15799e-06 | 5.61771e-05 | 0.655244 | 2.73143e-07 |
| j_l | 0.0174194 | 0.192504 | 0.0359678 | 0.979399 | 5.12635e-05 |

## V10 compared with V5

| field | global delta ratio V10/V5 | live-packet delta ratio V10/V5 | V5 packet-delta/live-packet-live | V10 packet-delta/live-packet-live |
|---|---:|---:|---:|---:|
| rho | 1.4565 | 1.40726 | 2.95467e-06 | 4.15799e-06 |
| j_l | 1.78515 | 1.78695 | 0.117526 | 0.192504 |

## V10 minus V5 live increment

| field | global increment / V10 live global | live-packet increment / V10 live packet live | catch share of live-packet increment | peak abs increment |
|---|---:|---:|---:|---:|
| rho | 4.27243e-07 | 1.21595e-06 | 1 | 2.03935e-07 |
| j_l | 0.00766145 | 0.084776 | 1 | 2.5457e-05 |

## Interpretation

The V=10 subtraction does not turn the ADM `rho` channel into a live packet-filling failure. The service-induced `rho` increment remains tiny compared with the live absolute `rho` ledger, supporting the earlier read that most packet `rho` is standing substrate/throat curvature.

The service signal remains `j_l`. Its beta-off delta grows relative to V=5 and is mostly a catch/rematch packet-edge signal. That fits the V=10 edge interpretation: the design does not fail this ADM subtraction screen, but the handoff momentum channel becomes the stress channel to watch.

## Decision

```text
standing-substrate subtraction at V=10: PASS WITH EDGE WARNING
rho service increment: tiny
j_l service increment: stronger than V=5, catch/rematch localized
next gate: source-family/constraint prototype should start at V=5 and repeat at V=10 after the V=5 scaffold behaves
```
