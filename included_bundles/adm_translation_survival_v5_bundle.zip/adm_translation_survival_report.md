# ADM Translation Survival Check

## Scope

This is the first computational ADM scaffold check for the active-rail reduced design. It implements the algebraic ADM quantities derived from

```text
ds^2 = -alpha(l,sigma)^2 d sigma^2
     + A(l,sigma) (dl + beta(l,sigma) d sigma)^2
     + B(l,sigma) dOmega^2.
```

It uses the frozen design parameters but a reconstructed field builder. The original archived reduced-model field builder was not imported exactly. This is therefore a survival/prototype test of the ADM translation, not a certification that the original solver has been reproduced byte-for-byte.

Primary target: **V=5**.  
Edge comparison: **V=10**.

## Survival result

| Check | V=5 result | V=10 edge comparison |
|---|---:|---:|
| All ADM fields finite | True | True |
| min alpha | 1.00013 | 1.00013 |
| min A | 1.00065 | 1.00065 |
| min B | 0.461456 | 0.461456 |
| live-packet positive norm-proxy points | 0 | 0 |
| max live-packet norm proxy | -1.00025 | -1.00025 |
| live-packet abs rho fraction | 15.05% | 13.06% |
| live-packet abs j_l fraction | 1.34% | 3.39% |
| live-packet-core abs rho fraction | 10.16% | 6.89% |
| live-packet-core abs j_l fraction | 0.15% | 0.13% |
| live packet-boundary-strip abs rho fraction | 4.89% | 6.17% |
| live packet-boundary-strip abs j_l fraction | 1.19% | 3.26% |
| catch inner-edge abs rho fraction | 1.95% | 2.77% |
| catch inner-edge abs j_l fraction | 1.73% | 2.54% |
| live support-shell abs rho fraction | 20.28% | 22.43% |
| live support-shell abs j_l fraction | 46.05% | 48.01% |

## Read

The V=5 scaffold survives the ADM translation in the narrow diagnostic sense: the ADM fields remain finite, the spatial metric is positive, the slicing norm proxy remains nonpositive in the live packet, and the radial momentum constraint burden is not packet-filling.

The strongest caution is energy density. The reconstructed scaffold carries nontrivial ADM rho burden in the live packet because the throat/angular geometry contributes baseline spatial curvature, and the largest rho hot spots sit on the packet boundary strip rather than deep packet interior. This is not an immediate failure, but it means the next ADM version needs an exact field-builder import and a cleaner separation between standing throat curvature and live service-induced source demand.

The radial momentum constraint, which is the better first test of the active shift handoff, looks much better: at V=5 the live packet carries only 1.34% of the absolute j_l burden, while the live support shell carries 46.05%. That supports the reduced-model source-placement story.

The V=10 comparison remains sharper. It still survives this reconstructed ADM scaffold, but the absolute momentum/curvature maps are more intense and the edge/catch bands are more prominent. That agrees with the earlier interpretation: V=10 is the recognized edge case; V=5 is the better primary target for the first ADM/source-family prototype.

## Decision

Proceed to a more faithful ADM prototype, but do not claim exact reduced-solver reproduction from this run.

Recommended next step: **restore/import the exact original frozen field builder and rerun these same ADM maps**. After that, add pressure/null projections on top of the ADM scaffold.
