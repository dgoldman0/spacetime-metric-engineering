# Time-Dependent Off-Axis Null Exposure Screen

## Scope

This is a targeted reduced null-ray screen for the locked active-rail freeze. It uses the frozen parameter set and the reduced metric form

```text
ds^2 = -alpha(l,t)^2 dt^2 + gamma_ll(l,t) (dl + beta(l,t) dt)^2 + gamma_pp(l,t) dphi^2
```

The harness was rebuilt for this validation pass because the repository exposes the final reports and archived artifacts, but not a clean importable final-freeze runner. No design tuning was performed.

## Frozen parameters used

```json
{
  "V": 10.0,
  "Rpass": 0.35,
  "Rth": 1.75,
  "ROmega": 1.75,
  "w_th": 0.569,
  "w_pass": 0.06,
  "wOmega": 1.4,
  "aOmega": 0.2,
  "eta_N": 2.0,
  "support_catch_x": -0.05,
  "support_catch_w": 0.32,
  "packet_rematch_x": 0.0,
  "packet_rematch_w": 0.32
}
```

## Ray families

- Launch times: [-0.16, 0.0, 0.16]
- Packet-edge radial offsets: [-0.38, -0.35, 0.35, 0.38]
- Off-axis angles: [0, 15, 45, 75, 85] degrees
- Angular signs: both signs for non-radial rays
- Propagation duration per ray: 0.42 reduced-time units
- Total rays: 108

## Gate result

| Check | Result |
|---|---:|
| Total rays | 108 |
| Max energy ratio | 8.54209 |
| 99th percentile max energy ratio | 8.48601 |
| Max packet-edge energy ratio | 6.58199 |
| Positive packet gtt samples | 0 |
| Max packet gtt | -1 |
| Max bundle focusing proxy | 10.624 |
| 99th percentile bundle focusing proxy | 10.624 |
| Max Hamiltonian residual | 1.686e-03 |

## By angle

|   theta_deg |   rays |   max_Eratio |   p99_Eratio |   median_max_Eratio |   max_edge_Eratio |   max_edge_beta_impulse |   positive_packet_gtt_count |   max_packet_gtt |   max_abs_H |
|------------:|-------:|-------------:|-------------:|--------------------:|------------------:|------------------------:|----------------------------:|-----------------:|------------:|
|           0 |     12 |      2.40324 |      2.37211 |             1       |           1.63015 |                 50.9194 |                           0 |               -1 | 0.00168581  |
|          15 |     24 |      8.54209 |      8.54209 |             1       |           6.58199 |                 50.188  |                           0 |               -1 | 0.00150183  |
|          45 |     24 |      7.74085 |      7.74085 |             1.01827 |           5.90081 |                 50.3325 |                           0 |               -1 | 0.00115895  |
|          75 |     24 |      5.83434 |      5.83434 |             1.40299 |           4.45468 |                 41.4115 |                           0 |               -1 | 4.32426e-07 |
|          85 |     24 |      5.15561 |      5.15561 |             1.55664 |           3.95395 |                 38.9522 |                           0 |               -1 | 3.65286e-07 |

## By launch time

|    t0 |   rays |   max_Eratio |   p99_Eratio |   max_edge_Eratio |   max_edge_beta_impulse |   positive_packet_gtt_count |   max_packet_gtt |   max_abs_H |
|------:|-------:|-------------:|-------------:|------------------:|------------------------:|----------------------------:|-----------------:|------------:|
| -0.16 |     36 |      8.54209 |      8.54209 |           6.58199 |            42.0539      |                           0 |         -8.09888 | 0.00168581  |
|  0    |     36 |      2.17734 |      2.17734 |           2.17711 |            50.9194      |                           0 |         -1       | 0.000376206 |
|  0.16 |     36 |      1       |      1       |           1       |             7.62583e-06 |                           0 |         -1       | 8.41285e-06 |

## Highest energy-shift rays

|   ray_id |    t0 |   l0 |   theta_deg |   ang_sign |   max_Eratio |   edge_Eratio_max |   edge_beta_impulse_max |   max_gtt_packet |   positive_packet_gtt_count |   max_abs_H |   final_l |   final_phi |
|---------:|------:|-----:|------------:|-----------:|-------------:|------------------:|------------------------:|-----------------:|----------------------------:|------------:|----------:|------------:|
|       21 | -0.16 | 0.35 |          15 |          1 |      8.54209 |           6.58199 |                 26.5138 |         -19.1359 |                           0 | 0.00150183  |  0.802515 |     3.30652 |
|       20 | -0.16 | 0.35 |          15 |         -1 |      8.54209 |           6.58199 |                 26.5138 |         -19.1359 |                           0 | 0.00150183  |  0.802515 |    -3.30652 |
|       23 | -0.16 | 0.35 |          45 |          1 |      7.74085 |           5.90081 |                 21.955  |         -22.111  |                           0 | 0.00115895  |  0.834229 |     2.10742 |
|       22 | -0.16 | 0.35 |          45 |         -1 |      7.74085 |           5.90081 |                 21.955  |         -22.111  |                           0 | 0.00115895  |  0.834229 |    -2.10742 |
|       29 | -0.16 | 0.38 |          15 |         -1 |      7.50019 |           5.81879 |                 26.8411 |         -18.4676 |                           0 | 0.00139898  |  0.800566 |    -3.19602 |
|       30 | -0.16 | 0.38 |          15 |          1 |      7.50019 |           5.81879 |                 26.8411 |         -18.4676 |                           0 | 0.00139898  |  0.800566 |     3.19602 |
|       31 | -0.16 | 0.38 |          45 |         -1 |      6.75117 |           5.09854 |                 21.1435 |         -23.9936 |                           0 | 1.18366e-06 |  0.844742 |    -1.80564 |
|       32 | -0.16 | 0.38 |          45 |          1 |      6.75117 |           5.09854 |                 21.1435 |         -23.9936 |                           0 | 1.18366e-06 |  0.844742 |     1.80564 |
|       25 | -0.16 | 0.35 |          75 |          1 |      5.83434 |           4.45468 |                 18.5382 |         -27.6435 |                           0 | 4.32426e-07 |  0.882939 |     1.19493 |
|       24 | -0.16 | 0.35 |          75 |         -1 |      5.83434 |           4.45468 |                 18.5382 |         -27.6435 |                           0 | 4.32426e-07 |  0.882939 |    -1.19493 |

## Read

This targeted time-dependent pass does not find a hidden off-axis/null failure in the reduced harness. The worst energy ratio remains modest, no packet sample crosses into positive gtt, and the simple bundle-compression proxy does not show a caustic-like blow-up.

The strongest caveat is implementation lineage: this is a reconstructed reduced harness using the locked parameters and metric form, not the original archived solver. The result is strong enough to proceed to residual maps, while preserving a later gate for an exact-code rerun if the original notebook/script runner is restored.
