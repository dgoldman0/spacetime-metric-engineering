# Point-Level Active Rail Lifecycle Ledger

This report recomputes a raw `(s,l)` demanded-source ledger and then applies lifecycle masks.
It is a prescribed-geometry Einstein-source diagnostic, not a matter model or physical-source proof.

Grid: `41 x 61` points per case.

## Cases

| case                |   V |   Rth |   ROmega |   w_th |   wOmega |   aOmega | note                                                   |
|:--------------------|----:|------:|---------:|-------:|---------:|---------:|:-------------------------------------------------------|
| freeze_like_minjerk |  10 |  1.25 |     1.25 |   0.12 |      0.7 |     0.35 | v1 freeze-like soft angular jacket with minimum-jerk q |
| R1p75_quarantine    |  10 |  1.75 |     1.75 |   0.35 |      1.4 |     0.2  | default quarantined active rail v2 candidate           |
| R2p0_quarantine     |  10 |  2    |     2    |   0.35 |      1.6 |     0.2  | higher-quarantine stress branch                        |

## Compact global volume-weighted summary

| case                | channel        | description                      |   total_burden |   live_packet_burden | live_packet_fraction   |   point_peak |   live_packet_point_peak |
|:--------------------|:---------------|:---------------------------------|---------------:|---------------------:|:-----------------------|-------------:|-------------------------:|
| R1p75_quarantine    | neg_rho_euler  | negative Eulerian density        |        0.39    |            0         | 0.0%                   |     0.01621  |                0         |
| R1p75_quarantine    | neg_rho_packet | negative packet-comoving density |        0.6095  |            0         | 0.0%                   |     0.7239   |                0         |
| R1p75_quarantine    | neg_Tkk_radial | negative radial null contraction |      458       |          122.5       | 26.7%                  |     0.1647   |                0.1164    |
| R1p75_quarantine    | abs_p_l        | radial pressure magnitude        |       69.12    |           17.21      | 24.9%                  |     0.01565  |                0.009531  |
| R1p75_quarantine    | abs_pOmega     | angular pressure magnitude       |        4.092   |            0.007595  | 0.2%                   |     0.1682   |                9.428e-05 |
| R1p75_quarantine    | abs_j_l        | radial current magnitude         |        0.2006  |            0.001936  | 1.0%                   |     0.007957 |                8.9e-05   |
| R2p0_quarantine     | neg_rho_euler  | negative Eulerian density        |        0.3732  |            0         | 0.0%                   |     0.01398  |                0         |
| R2p0_quarantine     | neg_rho_packet | negative packet-comoving density |        0.4375  |            0         | 0.0%                   |     0.08951  |                0         |
| R2p0_quarantine     | neg_Tkk_radial | negative radial null contraction |      558.9     |          126         | 22.5%                  |     0.1313   |                0.08918   |
| R2p0_quarantine     | abs_p_l        | radial pressure magnitude        |       83.04    |           17.65      | 21.3%                  |     0.01303  |                0.007297  |
| R2p0_quarantine     | abs_pOmega     | angular pressure magnitude       |        4.972   |            0.01039   | 0.2%                   |     0.163    |                9.479e-05 |
| R2p0_quarantine     | abs_j_l        | radial current magnitude         |        0.2337  |            0.001851  | 0.8%                   |     0.006664 |                4.673e-05 |
| freeze_like_minjerk | neg_rho_euler  | negative Eulerian density        |        0.475   |            0.0008782 | 0.2%                   |     0.02405  |                0.02381   |
| freeze_like_minjerk | neg_rho_packet | negative packet-comoving density |        0.5004  |            0.001762  | 0.4%                   |     0.1502   |                0.03802   |
| freeze_like_minjerk | neg_Tkk_radial | negative radial null contraction |      342.6     |          140.6       | 41.0%                  |     0.2619   |                0.1757    |
| freeze_like_minjerk | abs_p_l        | radial pressure magnitude        |       58.98    |           17.9       | 30.3%                  |     0.02928  |                0.02723   |
| freeze_like_minjerk | abs_pOmega     | angular pressure magnitude       |        5.865   |            0.07499   | 1.3%                   |     1.003    |                0.9807    |
| freeze_like_minjerk | abs_j_l        | radial current magnitude         |        0.07086 |            0.00146   | 2.1%                   |     0.01036  |                0.001019  |

## Stage reading: live packet burden by stage

### neg_Tkk_radial

| case                |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:--------------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| R1p75_quarantine    |            38.21 |           67.1  |            0 |                17.21 |                     0 |                     0 |
| R2p0_quarantine     |            39.31 |           68.92 |            0 |                17.8  |                     0 |                     0 |
| freeze_like_minjerk |            43.01 |           82.11 |            0 |                15.51 |                     0 |                     0 |

### abs_p_l

| case                |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:--------------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| R1p75_quarantine    |            4.238 |           10.43 |            0 |                2.542 |                     0 |                     0 |
| R2p0_quarantine     |            4.338 |           10.65 |            0 |                2.656 |                     0 |                     0 |
| freeze_like_minjerk |            4.429 |           10.86 |            0 |                2.607 |                     0 |                     0 |

### abs_pOmega

| case                |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:--------------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| R1p75_quarantine    |        0.0007551 |        0.002467 |            0 |             0.004373 |                     0 |                     0 |
| R2p0_quarantine     |        0.0009551 |        0.003119 |            0 |             0.006314 |                     0 |                     0 |
| freeze_like_minjerk |        0.0004917 |        0.001659 |            0 |             0.07283  |                     0 |                     0 |

### abs_j_l

| case                |   entry_precatch |   catch_rematch |   held_carry |   release_shift_fade |   post_release_buffer |   reset_decompression |
|:--------------------|-----------------:|----------------:|-------------:|---------------------:|----------------------:|----------------------:|
| R1p75_quarantine    |        2.534e-05 |       0.0001032 |            0 |             0.001808 |                     0 |                     0 |
| R2p0_quarantine     |        2.458e-05 |       0.0001009 |            0 |             0.001726 |                     0 |                     0 |
| freeze_like_minjerk |        2.559e-05 |       0.0001126 |            0 |             0.001322 |                     0 |                     0 |

## Top live-packet bad points

| case                | channel        |   rank |     s |        l | stage          | region            |   badness |   volume_burden |
|:--------------------|:---------------|-------:|------:|---------:|:---------------|:------------------|----------:|----------------:|
| R1p75_quarantine    | abs_p_l        |      1 | -0.35 |  0       | entry_precatch | packet_in_support |  0.009522 |          0.1432 |
| R1p75_quarantine    | abs_p_l        |      2 | -0.35 | -0.09333 | entry_precatch | packet_in_support |  0.009497 |          0.1431 |
| R1p75_quarantine    | abs_p_l        |      4 | -0.3  |  0       | entry_precatch | packet_in_support |  0.009522 |          0.1429 |
| R1p75_quarantine    | abs_p_l        |      5 | -0.35 | -0.1867  | entry_precatch | packet_in_support |  0.009424 |          0.1429 |
| R1p75_quarantine    | abs_p_l        |      7 | -0.3  | -0.09333 | entry_precatch | packet_in_support |  0.009497 |          0.1428 |
| R1p75_quarantine    | neg_Tkk_radial |      4 | -0.35 | -0.6533  | entry_precatch | packet_in_support |  0.1164   |          1.899  |
| R1p75_quarantine    | neg_Tkk_radial |      5 | -0.25 | -0.56    | entry_precatch | packet_in_support |  0.1144   |          1.823  |
| R1p75_quarantine    | neg_Tkk_radial |      7 | -0.15 | -0.4667  | catch_rematch  | packet_in_support |  0.106    |          1.625  |
| R1p75_quarantine    | neg_Tkk_radial |     10 | -0.05 |  0.28    | catch_rematch  | packet_in_support |  0.09791  |          1.395  |
| R1p75_quarantine    | neg_Tkk_radial |     13 | -0.3  | -0.56    | entry_precatch | packet_in_support |  0.08629  |          1.381  |
| R2p0_quarantine     | abs_p_l        |      1 | -0.35 |  0       | entry_precatch | packet_in_support |  0.00729  |          0.1459 |
| R2p0_quarantine     | abs_p_l        |      2 | -0.35 | -0.09333 | entry_precatch | packet_in_support |  0.007276 |          0.1458 |
| R2p0_quarantine     | abs_p_l        |      4 | -0.35 | -0.1867  | entry_precatch | packet_in_support |  0.007233 |          0.1457 |
| R2p0_quarantine     | abs_p_l        |      6 | -0.3  |  0       | entry_precatch | packet_in_support |  0.00729  |          0.1456 |
| R2p0_quarantine     | abs_p_l        |      7 | -0.3  | -0.09333 | entry_precatch | packet_in_support |  0.007276 |          0.1456 |
| R2p0_quarantine     | neg_Tkk_radial |      4 | -0.35 | -0.6533  | entry_precatch | packet_in_support |  0.08918  |          1.927  |
| R2p0_quarantine     | neg_Tkk_radial |      5 | -0.25 | -0.56    | entry_precatch | packet_in_support |  0.08788  |          1.853  |
| R2p0_quarantine     | neg_Tkk_radial |      8 | -0.15 | -0.4667  | catch_rematch  | packet_in_support |  0.08074  |          1.638  |
| R2p0_quarantine     | neg_Tkk_radial |     12 | -0.3  | -0.56    | entry_precatch | packet_in_support |  0.06659  |          1.41   |
| R2p0_quarantine     | neg_Tkk_radial |     14 | -0.05 |  0.28    | catch_rematch  | packet_in_support |  0.07324  |          1.384  |
| freeze_like_minjerk | abs_p_l        |      1 | -0.35 |  0       | entry_precatch | packet_in_support |  0.01399  |          0.1485 |
| freeze_like_minjerk | abs_p_l        |      2 | -0.35 | -0.09333 | entry_precatch | packet_in_support |  0.01392  |          0.1485 |
| freeze_like_minjerk | abs_p_l        |      4 | -0.35 | -0.1867  | entry_precatch | packet_in_support |  0.01373  |          0.1485 |
| freeze_like_minjerk | abs_p_l        |      6 | -0.35 | -0.28    | entry_precatch | packet_in_support |  0.01342  |          0.1485 |
| freeze_like_minjerk | abs_p_l        |      8 | -0.35 | -0.3733  | entry_precatch | packet_in_support |  0.01303  |          0.1484 |
| freeze_like_minjerk | neg_Tkk_radial |      5 | -0.05 |  0.28    | catch_rematch  | packet_in_support |  0.1757   |          1.807  |
| freeze_like_minjerk | neg_Tkk_radial |      6 | -0.15 | -0.4667  | catch_rematch  | packet_in_support |  0.1566   |          1.799  |
| freeze_like_minjerk | neg_Tkk_radial |      7 | -0.25 | -0.56    | entry_precatch | packet_in_support |  0.145    |          1.772  |
| freeze_like_minjerk | neg_Tkk_radial |      8 | -0.2  |  0       | entry_precatch | packet_in_support |  0.1658   |          1.735  |
| freeze_like_minjerk | neg_Tkk_radial |      9 | -0.25 | -0.09333 | entry_precatch | packet_in_support |  0.1633   |          1.731  |

## Outputs

- `point_lifecycle_ledger.csv`
- `point_lifecycle_summary_long.csv`
- `point_lifecycle_global_compact.csv`
- `point_lifecycle_stage_summary.csv`
- `point_lifecycle_top_bad_points.csv`
