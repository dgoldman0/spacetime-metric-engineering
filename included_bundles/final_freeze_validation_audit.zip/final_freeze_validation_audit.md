# Final Freeze Validation Audit

## Scope

This validates the locked reduced model using existing frozen-run artifacts. No tuning was performed.

Locked model: **R1.75 shaped catch radial-soft lapse-cushion v1**.

This audit is a prescribed-geometry reduced-model validation pass. It is not a physical matter construction, not an RSET calculation, and not a 3+1 constraint solve.

## Gate result

| Gate | Result | Read |
|---|---|---|
| Grid convergence | PASS WITH WARNING | The 25x45, 33x59, and 41x73 source-ledger runs keep zero positive live packet-norm points. Live p_l and radial Tkk burdens vary modestly across grids. This is enough for a reduced-model validation pass, but not enough for formal Richardson convergence. |
| V=10 packet safety | PASS AT THE LOCKED POINT | The tuned branch remains packet-safe at V=10 in the existing checks. |
| V headroom | WARNING | The fine packet-norm scan places the tuned branch's first unsafe point around V=10.01, so the V=10 freeze is a knife-edge, not a broad plateau. |
| Off-axis/null exposure | PARTIAL PASS, NOT CLOSED | Existing frozen-frame off-axis impact-parameter checks do not show the radial focusing spike as a general angled-ray catastrophe. Full time-dependent off-axis/null propagation through prepare/carry/catch/fade remains open. |

## Convergence table

| grid   |   ns |   nl |   max_packet_norm_live |   positive_packet_norm_live |   live_packet_burden__abs_p_l |   live_packet_burden__neg_Tkk_radial |   live_packet_fraction__abs_p_l |   live_packet_fraction__neg_Tkk_radial |
|:-------|-----:|-----:|-----------------------:|----------------------------:|------------------------------:|-------------------------------------:|--------------------------------:|---------------------------------------:|
| 25x45  |   25 |   45 |               -198.925 |                           0 |                       13.8019 |                              71.4351 |                        0.264783 |                               0.221226 |
| 33x59  |   33 |   59 |               -198.925 |                           0 |                       13.988  |                              72.5353 |                        0.271614 |                               0.227126 |
| 41x73  |   41 |   73 |               -198.925 |                           0 |                       13.8318 |                              72.3794 |                        0.270556 |                               0.228108 |

## Convergence audit stats

| metric                               |   coarsest_25x45 |   mid_33x59 |   finest_41x73 |       min |       max |      mean |   relative_range_pct |   finest_vs_coarsest_pct |   finest_vs_mid_pct |
|:-------------------------------------|-----------------:|------------:|---------------:|----------:|----------:|----------:|---------------------:|-------------------------:|--------------------:|
| live_packet_burden__abs_p_l          |        13.8019   |   13.988    |      13.8318   | 13.8019   | 13.988    | 13.8739   |              1.34137 |                 0.216637 |           -1.11667  |
| live_packet_burden__neg_Tkk_radial   |        71.4351   |   72.5353   |      72.3794   | 71.4351   | 72.5353   | 72.1166   |              1.52558 |                 1.3219   |           -0.21493  |
| live_packet_fraction__abs_p_l        |         0.264783 |    0.271614 |       0.270556 |  0.264783 |  0.271614 |  0.268984 |              2.53955 |                 2.18028  |           -0.389523 |
| live_packet_fraction__neg_Tkk_radial |         0.221226 |    0.227126 |       0.228108 |  0.221226 |  0.228108 |  0.225487 |              3.05207 |                 3.11085  |            0.432359 |

## Fine V-headroom scan

| variant                   |   last_safe_V |   first_unsafe_V |   max_norm_at_10 |
|:--------------------------|--------------:|-----------------:|-----------------:|
| conservative_w0565_eta200 |         10.04 |            10.05 |         -209.127 |
| safe_w0520_eta100         |         10.21 |           nan    |         -216.839 |
| shaped_base               |         10.21 |           nan    |         -396.474 |
| tuned_eta220              |         10    |            10.01 |         -200.743 |
| tuned_w0569_eta200        |         10    |            10.01 |         -198.925 |

## Existing off-axis/null-adjacent artifacts

| screen                                             | description                                                                                                |   energy_shift_max |   energy_shift_p99 |   focusing_proxy_max |   focusing_proxy_p99 |   focusing_proxy_p99_offaxis_theta_ge_20 |   risk_proxy_max |   risk_proxy_p99 |   packet_positive_points | status_read                                                                                                                   |
|:---------------------------------------------------|:-----------------------------------------------------------------------------------------------------------|-------------------:|-------------------:|---------------------:|---------------------:|-----------------------------------------:|-----------------:|-----------------:|-------------------------:|:------------------------------------------------------------------------------------------------------------------------------|
| A2 frozen-frame equatorial impact-parameter screen | rays launched with impact angles 5 to 85 degrees away from radial, sampled at packet offsets               |               0.83 |              0.829 |                23.47 |                21.53 |                                    17.65 |             3.71 |             3.05 |                      nan | No high blueshift in this frozen-frame approximation; radial focusing spike largely relaxes once rays carry impact parameter. |
| A3 targeted optical stress set                     | targeted higher nominal shift-demand and sharper transition-width optical/radiation-adjacent stress screen |             nan    |            nan     |               nan    |               nan    |                                   nan    |           nan    |           nan    |                        0 | Did not revive the simple optical catastrophe; still not a full time-dependent off-axis geodesic solve.                       |

## Decision

The locked reduced model passes the immediate validation audit at the frozen V=10 point.

The result should be carried forward with two warnings:

1. The safety margin above V=10 is extremely thin.
2. The off-axis result is only a reduced frozen-frame impact-parameter screen, not the full time-dependent null congruence test.

## Next validation action

Run the full time-dependent off-axis/null propagation through the service stages, seeded especially near the packet edge during catch/rematch and shift fade. Use this as a gate before treating the modal absorber ansatz as more than a source-proxy fit.
