# Source Plausibility Screen

## Scope

This is a first source plausibility screen for the locked reduced model. It classifies demanded-source roles by exposure class, sign/pathology risk, localization, and next physical gate.

This is **not** a physical matter construction, not a semiclassical stress tensor calculation, and not a 3+1 constraint solve. It is a screening ledger meant to decide whether the reduced model is mature enough for a serious technical write-up and a coarse constraint prototype.

## Executive verdict

**Result: mixed but encouraging.**

The model is ready for a serious technical write-up if the caveats are explicit. It is also ready for a coarse 3+1/constraint prototype. It is not ready for a physical-source claim.

The strongest positive result is source placement: most of the large or awkward channels remain infrastructure-side or packet-adjacent. The strongest warning is the same one we expected: the inner packet-edge catch/rematch absorber is compact and structured, but it carries the main null-stress risk.

## Component ledger

| component                                     | primary_channels                                           | source_role                                                      | exposure_class                                   | negative_or_null_stress                                                    | localization                                            | amplitude_gradient_risk                               | planck_risk_proxy   | plausibility_read                                                                 | writeup_status                                              | prototype_gate                                                                 |
|:----------------------------------------------|:-----------------------------------------------------------|:-----------------------------------------------------------------|:-------------------------------------------------|:---------------------------------------------------------------------------|:--------------------------------------------------------|:------------------------------------------------------|:--------------------|:----------------------------------------------------------------------------------|:------------------------------------------------------------|:-------------------------------------------------------------------------------|
| cold_core_substrate / standing support shell  | abs_p_l, baseline geometry support                         | broad standing infrastructure support                            | infrastructure-only                              | low/directly not the dominant null-negative channel                        | broad core/support envelope                             | medium                                                | amber               | plausible as an effective infrastructure sector, but not yet a matter model       | not a blocker                                               | constraint compatibility and support-shell source family                       |
| radial_support_edge_shell                     | abs_p_l, neg_Tkk_radial contribution                       | radial support-edge pressure relief and null-stress shaping      | infrastructure / packet-adjacent                 | medium-high because it participates in Tkk but mostly through support edge | support edge, not whole live packet                     | medium-high near edge; watch resolution growth        | amber               | promising because p_l is already well fit and shape-linked to support width       | not a blocker, but needs edge-gradient audit                | check no thin-wall sharpening under grid refinement                            |
| outer_quarantine_jacket / angular jacket      | abs_pOmega, density/current global proxy leftovers         | broad angular/effective jacket carried outside live packet       | infrastructure-only                              | low for live packet; global fit is crude                                   | outer shell/jacket                                      | medium globally, low live-packet risk                 | green-amber         | does not appear to threaten passenger exposure; source model cleanup remains      | not a passenger blocker                                     | improve angular basis and check global stress closure                          |
| lapse_cushion_sector                          | packet safety, contributes to neg_Tkk_radial allocation    | causal safety compensator enabling radial support-edge softening | infrastructure / packet-adjacent                 | medium because it affects causal margin rather than directly curing p_l    | cushion sector around packet/support interface          | medium; tied to safety cliff at V=10                  | amber               | engineering role is coherent; source realization is open                          | not a blocker at V=10; flag as compensator                  | constraint solve must test lapse-shaping source cost                           |
| shift_packet_carrier                          | neg_Tkk_radial during live handoff                         | packet-adjacent carried-shift sector                             | packet-adjacent                                  | high; directly participates in radial-null burden                          | live handoff region, not reset                          | high; depends on shift-handoff rate/mismatch          | red-amber           | main formal-risk sector after infrastructure channels                             | writeup can proceed if labeled as unproven effective source | bound local kinematic amplitude and integrated null exposure                   |
| catch_rematch_transient / inner-edge absorber | neg_Tkk_radial residual                                    | localized inner packet-edge null-stress absorber                 | packet-adjacent inner edge                       | high; main null-energy-risk component                                      | inner packet edge near xi = -Rpass during catch/rematch | highest; compactness can become thin-wall pathology   | red                 | best mathematical story and worst physical-risk story; must be bounded and smooth | principal caveat, not automatic blocker                     | test compact control law at multiple grids and enforce amplitude/gradient caps |
| release_shift_transient                       | release_shift_fade leftovers, small Tkk/p_l tail           | controlled fade correction after live handoff                    | packet-adjacent to infrastructure                | medium                                                                     | release/fade window                                     | medium-low relative to catch                          | amber-green         | secondary cleanup component, less concerning than catch/rematch                   | not a blocker                                               | confirm fade does not create grazing null exposure                             |
| packet_local_residual                         | abs_p_l local residual and minor live underfit             | remaining live packet correction after component split           | live-packet interior/watch zone                  | medium for pressure, lower for density in current ledger                   | small packet-local residual                             | medium-high because any live-packet residual matters  | red-amber           | small enough not to dominate, important enough to track                           | writeup caveat                                              | drive toward zero or demonstrate benign pressure-only character                |
| reset_decompression_infra                     | reset/decompression current/angular/density global cleanup | slow infrastructure reset outside passenger exposure             | infrastructure-only after live packet accounting | low live-risk; may be exotic globally                                      | post-release infrastructure stage                       | low-medium if decompression remains slow/minimum-jerk | green-amber         | least passenger-critical; can be deferred                                         | not a blocker                                               | ensure reset remains outside live exposure in full schedule                    |

## Channel screen

| channel        | live_status                               | fit_status                                     | screen_result   | next_check                                                  |
|:---------------|:------------------------------------------|:-----------------------------------------------|:----------------|:------------------------------------------------------------|
| neg_Tkk_radial | main live high-risk channel               | structured, reduced by targeted/modal absorber | red-amber       | compact absorber amplitude/gradient caps and grid scaling   |
| abs_p_l        | material but better controlled            | low live underfit in proxy                     | amber           | support-edge pressure source family and constraint closure  |
| abs_pOmega     | tiny live packet burden                   | global proxy underfit high                     | green-amber     | improve outer-jacket/global basis                           |
| abs_j_l        | tiny live packet burden                   | global proxy underfit high                     | green-amber     | current/flux closure in infrastructure                      |
| neg_rho_euler  | zero live packet burden in current ledger | global proxy underfit high                     | green-amber     | infrastructure density source model                         |
| neg_rho_packet | zero live packet burden in current ledger | global proxy underfit high                     | green-amber     | confirm under full off-axis/time-dependent packet observers |

## Summary gates

| screen                 | result                                    | notes                                                                                                                                               |
|:-----------------------|:------------------------------------------|:----------------------------------------------------------------------------------------------------------------------------------------------------|
| passenger exposure     | mostly clean                              | negative density live burden is zero in the existing source decomposition; live packet angular burden is tiny; live pressure/null residuals remain. |
| primary blocker search | one red component                         | inner-edge catch/rematch null-stress absorber is the principal physical-risk component.                                                             |
| infrastructure split   | encouraging                               | standing shell, radial edge, angular jacket, lapse cushion, and reset mostly remain infrastructure or packet-adjacent rather than packet-filling.   |
| trans-Planckian proxy  | unresolved                                | absolute Planck-scale risk cannot be decided without scale setting; compactness, null sign, and grid-sensitive gradients are the warning flags.     |
| write-up readiness     | ready with caveats                        | suitable for serious technical write-up if clearly framed as reduced prescribed-geometry source plausibility, not physical source proof.            |
| next prototype         | coarse 3+1/constraint prototype justified | especially for the catch-edge absorber, lapse sector, and radial support edge.                                                                      |

## Interpretation

The screen supports the reduced-model engineering story. The radial pressure channel is an edge-support problem rather than a whole-packet pressure flood. The angular/current/density channels need better infrastructure source modeling, but they are not currently the live passenger blocker. Negative density does not appear as a live packet burden in the available decomposition.

The main unresolved physical question is whether the catch-edge absorber remains a bounded, smooth, source-adjacent transient after scale-setting and refinement. A compact ansatz helps the engineering story, but compact null-negative support is exactly where known warp/wormhole source arguments usually become hard.

## Recommended next tests

1. Grid-repeat the compact catch absorber ansatz and record peak amplitude, gradient norm, integrated null exposure, and packet overlap.
2. Run a scale audit: choose physical throat/packet length scales and convert the dimensionless source ledger into curvature/stress scales.
3. Prototype a coarse 3+1 constraint version with the radial support edge, lapse cushion, and catch-edge absorber separated as explicit source sectors.
4. Keep the residual-responsive law only as a limiter/cap, not as the core source law.
5. Improve angular/current/density infrastructure bases, but do not let that distract from the catch-edge null-stress gate.

## Final decision

Proceed to technical write-up and coarse 3+1/constraint prototype planning.

Do not claim physical realizability yet.

Primary caveat for the paper:

> The active-rail reduced model localizes the dangerous source demand into a packet-adjacent catch/rematch null-stress absorber. This is a substantially cleaner engineering target than a global exotic layer, but it remains the principal physical plausibility gate until a scale-aware source family or constraint-compatible prototype is demonstrated.
