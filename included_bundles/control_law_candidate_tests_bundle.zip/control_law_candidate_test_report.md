# Control Law Candidate Test

## Scope

This is a proxy source-control test against the extracted live catch/rematch `Tkk` residual bins from the locked V=10 reduced model. It does not retune the metric and does not prove a physical matter model.

The target is the remaining live catch residual after the targeted Tkk proxy. The extracted bins give total live catch burden `63.845` and remaining binned underfit burden `6.329`, i.e. `9.91%` of live catch burden.

## Candidates tested

1. **Residual-responsive law**: absorber amplitude is a capped/smoothed positive predicted residual inside the catch window.
2. **Kinematic handoff law**: absorber amplitude follows the shift-handoff rate/mismatch with a broad packet-shift envelope plus a localized inward packet-edge bump.
3. **Geometric edge-gradient law**: absorber amplitude follows a compact packet-edge gradient envelope with no direct residual lookup.

## Score table

| candidate               | description                                                                                      | formula_sketch                                               |   n_fit_parameters |   total_target_underfit_burden |   absorbed_burden_capped |   uncovered_underfit_burden |   oversupply_burden |   post_absorber_live_catch_underfit_pct_of_actual |   oversupply_pct_of_actual |   coverage_pct_of_target_underfit |    mae |   rmse |   max_bin_abs_error |   physical_penalty_0_to_10 |   selection_score_lower_better |
|:------------------------|:-------------------------------------------------------------------------------------------------|:-------------------------------------------------------------|-------------------:|-------------------------------:|-------------------------:|----------------------------:|--------------------:|--------------------------------------------------:|---------------------------:|----------------------------------:|-------:|-------:|--------------------:|---------------------------:|-------------------------------:|
| residual_responsive     | Capped/smoothed fraction of predicted local positive Tkk residual inside catch-edge window.      | A = cap(smooth([R_Tkk]_+)) * W_catch(σ)                      |                  1 |                          6.329 |                    6.329 |                       0     |              0      |                                             0     |                     0      |                            100    | 0      | 0      |              0      |                        7.5 |                          1.175 |
| kinematic_handoff       | Shift-handoff amplitude with narrow inward packet-edge boost; no direct residual lookup.         | A = W_catch(σ) * (a |β| |∂σM| E_packet + b |∂σβ| B_inner(ξ)) |                  2 |                          6.329 |                    5.585 |                       0.744 |              0.5936 |                                             1.165 |                     0.9298 |                             88.24 | 0.1911 | 0.233  |              0.4477 |                        2   |                          2.216 |
| geometric_edge_gradient | Pure compact packet-edge gradient source, symmetric at packet boundaries and catch-window gated. | A = a W_catch(σ) |∂ξS|                                       |                  1 |                          6.329 |                    3.092 |                       3.237 |              0.357  |                                             5.069 |                     0.5591 |                             48.86 | 0.5134 | 0.6119 |              0.9619 |                        1   |                          5.661 |

## Read

The residual-responsive law is the numerical upper bound: it can cover the extracted residual almost exactly because it is allowed to read the predicted residual. It is useful as a diagnostic control or limiter, but it is too self-referential to be the primary source law.

The kinematic handoff law is the best primary candidate. It covers `88.2%` of the extracted target residual and leaves `1.17%` of live catch burden as underfit. Its oversupply is `0.93%` of live catch burden. This is a decent trade because the law is compact and tied to service kinematics rather than fitted modes.

The pure geometric edge-gradient law is too narrow as the main absorber. It captures the edge spike but misses the broad catch-handoff floor visible across the packet-coordinate bins. It is still valuable as the spatial envelope inside the kinematic law.

## Recommendation

Promote the kinematic handoff law as the compact ansatz:

```text
A_catch(ξ, σ)
=
W_catch(σ)
[
  a · H_shift(ξ, σ)
  + b · B_inner(ξ)
]
```

where `W_catch` is the locked-lead minimum-jerk catch/rematch window, `H_shift` is a smooth shift-handoff/mismatch measure such as `|β| |∂σM|` or `|∂σβ|` times the live packet envelope, and `B_inner` is a narrow compact bump centered on the inward packet edge near `ξ = -Rpass`.

Keep the residual-responsive law as a safety limiter:

```text
A_catch <= cap([R_Tkk]_+ smoothed over the catch-edge neighborhood)
```

Do not use the pure edge-gradient law alone.
